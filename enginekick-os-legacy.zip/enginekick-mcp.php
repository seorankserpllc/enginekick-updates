<?php
/**
 * EngineKick MCP module (bundled).  ── NOTE: intentionally NOT a WordPress plugin header. ──
 * This file is loaded via require_once by enginekick-connector.php, so the combined package is a
 * SINGLE activatable plugin (review v3 #2 — two plugin headers made WP list two plugins). To ship
 * the MCP module standalone, build a SEPARATE zip and re-add a "Plugin Name:" header there.
 *
 * Exposes your posts and media library to Claude over the Model Context Protocol: read posts, create
 * drafts, edit, surgical edits, internal links, media. Hardened: access modes (off / read-only /
 * draft-only / publish), a dedicated least-privilege service user, IP allowlisting, rate limiting,
 * SSRF-safe image import, payload size caps, and a per-write audit log. Deleting is NOT supported.
 * Module version 1.18.0 · Requires PHP 8.0 · EngineKick · GPL-2.0-or-later
 *
 * Bundled inside the "EngineKick OS" plugin (loaded by enginekick-connector.php). It can also run as a
 * standalone plugin. Generates its OWN secret (separate from the connector's crawl/changes secret).
 *
 * HOW IT WORKS / AUTH MODEL
 * -------------------------
 * The Claude web-app custom-connector UI can only talk to a server that is
 * "authless" (no Authorization header) or that implements full OAuth. Self-hosted
 * WordPress has no OAuth solution for this yet, so this plugin uses the practical
 * alternative: a long random secret embedded in the endpoint URL.
 *
 *   https://YOURSITE/wp-json/enginekick-mcp/v1/<SECRET>
 *
 * Claude treats that as an authless URL; your site validates the <SECRET> on every
 * request (constant-time). Anyone with the URL can write to your posts, so treat the
 * full URL like a password. Rotate it any time from the EngineKick MCP menu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'ENGINEKICK_MCP_VERSION' ) ) {
define( 'ENGINEKICK_MCP_VERSION', '1.18.0' );
define( 'ENGINEKICK_MCP_PROTOCOL', '2025-06-18' );      // fallback protocol version
// Anthropic's PUBLISHED outbound range for Claude's MCP tool calls (platform.claude.com/docs/en/api/ip-addresses,
// "Outbound IP addresses"). Until 1.16 this was 160.79.106.0/24 — one eighth of it, inferred from the handful of
// addresses Claude happened to use — so calls from the rest of the range got a 403, which Claude shows as
// "Reconnect". enginekick_mcp_upgrade_claude_range() repairs allowlists that carry the old entry.
define( 'ENGINEKICK_MCP_CLAUDE_IPS', '160.79.104.0/21' );
define( 'ENGINEKICK_MCP_OPTION_TOKEN', 'enginekick_mcp_token' );

/* ------------------------------------------------------------------------- *
 * Secret / activation
 * ------------------------------------------------------------------------- */

// Called from the connector's activation hook: WordPress fires activation hooks only for the MAIN plugin
// file, so a register_activation_hook() in this bundled module would never run.
function enginekick_mcp_activate() {
	if ( ! get_option( ENGINEKICK_MCP_OPTION_TOKEN ) ) {
		add_option( ENGINEKICK_MCP_OPTION_TOKEN, enginekick_mcp_generate_token(), '', false );   // not autoloaded: read only when needed
	}
	// New installs are explicitly OFF — activation must never open a reachable write endpoint.
	if ( false === get_option( 'enginekick_mcp_mode', false ) ) {
		update_option( 'enginekick_mcp_mode', 'off' );
	}
	// A REactivation restores the mode the administrator had chosen before the plugin was deactivated (the
	// connector URL was kept all along, so this changes nothing about who can reach the endpoint). The
	// memo exists only for a site that was configured and then deactivated; uninstall removes it.
	$remembered = (string) get_option( 'enginekick_mcp_mode_before_deactivation', '' );
	if ( '' !== $remembered ) {
		delete_option( 'enginekick_mcp_mode_before_deactivation' );
		if ( in_array( $remembered, array( 'read_only', 'draft_write', 'publish' ), true ) && 'off' === get_option( 'enginekick_mcp_mode', 'off' ) ) {
			update_option( 'enginekick_mcp_mode', $remembered );
		}
	}
	// Provision/heal the least-privilege service account NOW, while we run in wp-admin as the
	// administrator who is activating the plugin. This is the reliable moment: a WAF/security plugin
	// that blocks user creation on unauthenticated REST/bot requests (the reason lazy first-write
	// creation silently fails as 'no_service') does not block an admin action here. Safe even in OFF
	// mode: the account holds the dedicated EngineKick Service role, which never has unfiltered_html.
	enginekick_mcp_ensure_service_account( true );
}

// Deactivation: FAIL CLOSED (review V4 #3). Disable the write endpoint so a deactivated plugin leaves
// no reachable write path, and clear any USER-level unfiltered_html grant. A role-inherited grant
// cannot be removed per user — has_cap() followed by remove_cap() looks like it does that and does
// not (V5-ext #1) — so test the user's own caps array, which is the only thing remove_cap() touches.
// Called from the connector's deactivation hook (the bundled file's own hook can't fire).
function enginekick_mcp_deactivate() {
	// Remember the mode the administrator chose, so reactivating puts it back. Until 1.16 a deactivate /
	// reactivate cycle (routine host maintenance) left the MCP OFF until someone opened this page, and every
	// Claude call meanwhile got a 403 — "Reconnect". A fresh install still starts off; uninstall still wipes this.
	$mode = (string) get_option( 'enginekick_mcp_mode', 'off' );
	if ( 'off' !== $mode ) {
		update_option( 'enginekick_mcp_mode_before_deactivation', $mode, false );
	}
	update_option( 'enginekick_mcp_mode', 'off' );
	$u = get_user_by( 'login', enginekick_mcp_service_login() );
	if ( $u && isset( $u->caps['unfiltered_html'] ) ) {
		$u->remove_cap( 'unfiltered_html' );
	}
}
function enginekick_mcp_generate_token() {
	return bin2hex( random_bytes( 24 ) ); // 48 hex chars
}

function enginekick_mcp_get_token() {
	$t = get_option( ENGINEKICK_MCP_OPTION_TOKEN );
	if ( ! $t ) {
		$t = enginekick_mcp_generate_token();
		add_option( ENGINEKICK_MCP_OPTION_TOKEN, $t, '', false );
	}
	return $t;
}

function enginekick_mcp_endpoint_url() {
	// rest_url() respects the site's permalink settings (pretty or ?rest_route=).
	return rest_url( 'enginekick-mcp/v1/' . enginekick_mcp_get_token() );
}

function enginekick_mcp_service_login() {
	return 'enginekick-service';
}
function enginekick_mcp_service_role() {
	return 'enginekick_service';
}
/**
 * The EXACT capability set of the EngineKick Service role (V5-ext #1, V6 #10).
 *
 * An explicit allowlist, not "Editor minus a deny list": neither a plugin that extends the site's Editor
 * role nor drift on this role can widen what the connector's identity may do. It is what the 14 MCP
 * tools need and nothing more: read, create and edit posts and pages (including other authors',
 * published and private ones), upload files, manage categories and tags. No delete capability (there is
 * no delete tool), no unfiltered_html, nothing that manages the site, users, plugins or themes.
 *
 * Why a role of our own at all: WP_User::remove_cap() only edits the user's own capability array, which
 * for a role-based user holds array( 'editor' => true ). A role-inherited unfiltered_html cannot be
 * removed per user, so a stock Editor always kept it.
 */
function enginekick_mcp_service_caps() {
	return array(
		'read', 'upload_files', 'manage_categories',
		'edit_posts', 'edit_others_posts', 'edit_published_posts', 'edit_private_posts', 'read_private_posts', 'publish_posts',
		'edit_pages', 'edit_others_pages', 'edit_published_pages', 'edit_private_pages', 'read_private_pages', 'publish_pages',
	);
}
/**
 * True when the role is missing or holds any capability OUTSIDE the allowlist (roles are in memory: cheap).
 *
 * The allowlist is a ceiling, not a floor. An administrator may deliberately narrow the role (for example
 * remove term management); that is respected and never re-added. What can never happen is widening: any
 * capability beyond the allowlist is drift (V6 #10), refused in MCP requests and removed on the next admin
 * page load. Re-adding removed capabilities would silently undo exactly the least-privilege choices the
 * per-object and taxonomy checks exist to honour (V6 #2, #3).
 */
function enginekick_mcp_service_role_drifted() {
	$role = get_role( enginekick_mcp_service_role() );
	if ( ! $role ) {
		return true;
	}
	return (bool) array_diff( array_keys( array_filter( (array) $role->capabilities ) ), enginekick_mcp_service_caps(), enginekick_mcp_tolerated_caps() );
}
/**
 * Capabilities another plugin grants AUTOMATICALLY to every role that can edit posts, ours included, and
 * that only open that plugin's per-post panels — no site settings, users, plugins, themes or code.
 *
 * All in One SEO adds these seven to every role with edit_posts, on activation and on its own updates. Before
 * they were tolerated, that read as role drift and locked every connector write on any All in One SEO site,
 * permanently, because All in One SEO puts them back. Its site-wide aioseo_manage_seo is NOT here; neither
 * is any other cap — anything outside the allowlist plus this exact list is still drift.
 */
function enginekick_mcp_tolerated_caps() {
	return array(
		'aioseo_page_advanced_settings', 'aioseo_page_ai_content_settings', 'aioseo_page_analysis',
		'aioseo_page_general_settings', 'aioseo_page_schema_settings', 'aioseo_page_social_settings',
		'aioseo_page_writing_assistant_settings',
	);
}
/**
 * Create the role with the full allowlist, or reconcile an existing one by removing every capability
 * outside the allowlist (V6 #10 — reconciliation used to only ADD, so a widened role stayed wide).
 */
function enginekick_mcp_ensure_service_role() {
	$role_name = enginekick_mcp_service_role();
	$want      = enginekick_mcp_service_caps();
	$role      = get_role( $role_name );
	if ( ! $role ) {
		add_role( $role_name, 'EngineKick Service', array_fill_keys( $want, true ) );
		return get_role( $role_name );
	}
	foreach ( array_keys( (array) $role->capabilities ) as $cap ) {
		// Tolerated per-page caps are left alone: the plugin that grants them puts them straight back.
		if ( ! in_array( $cap, $want, true ) && ! in_array( $cap, enginekick_mcp_tolerated_caps(), true ) ) {
			$role->remove_cap( $cap );
		}
	}
	return get_role( $role_name );
}
/**
 * Capabilities the service identity must never hold, from any role or a user-level grant (V6 #10: the
 * previous test covered four). Includes the meta capabilities WordPress maps onto site management.
 */
function enginekick_mcp_forbidden_caps() {
	return array(
		'manage_options', 'activate_plugins', 'install_plugins', 'update_plugins', 'delete_plugins', 'edit_plugins',
		'resume_plugins', 'install_themes', 'update_themes', 'delete_themes', 'edit_themes', 'switch_themes',
		'resume_themes', 'edit_theme_options', 'customize', 'edit_users', 'create_users', 'delete_users',
		'promote_users', 'list_users', 'remove_users', 'add_users', 'update_core', 'update_languages',
		'install_languages', 'export', 'import', 'unfiltered_upload', 'edit_dashboard', 'manage_privacy_options',
		'export_others_personal_data', 'erase_others_personal_data', 'manage_network', 'manage_sites',
		'manage_network_users', 'manage_network_plugins', 'manage_network_themes', 'manage_network_options', 'setup_network',
	);
}
// True when a user may manage any part of the site — the hard line the service identity must never cross.
function enginekick_mcp_user_is_admin_class( $user ) {
	if ( in_array( 'administrator', (array) $user->roles, true ) || is_super_admin( $user->ID ) ) {
		return true;
	}
	foreach ( enginekick_mcp_forbidden_caps() as $cap ) {
		if ( user_can( $user, $cap ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Resolve (and, when $create, heal) the dedicated least-privilege service identity.
 *
 * Returns array( id, status, message ). status is one of:
 *   ready          — a marked, non-admin, editor-class user exists (id > 0)
 *   created        — we just created it (id > 0)
 *   unadopted      — a user named enginekick-service exists that this plugin did not create or mark; it
 *                    is never taken over silently — an administrator must confirm adoption (id 0)
 *   role_drift     — the EngineKick Service role holds capabilities beyond its allowlist and this is
 *                    not an administrator request that may reconcile it (id 0)
 *   admin_class    — a user named enginekick-service exists but can manage the site → refused (id 0)
 *   not_editor     — exists, not admin, but lacks editor publish caps → refused (id 0)
 *   create_blocked — the user is missing and wp_insert_user failed (usually a security plugin blocking
 *                    user creation during a REST/bot request) → id 0
 *   missing        — the user is missing and $create was false (read-only status check) → id 0
 *
 * CRITICAL: the create path only succeeds where the current request is allowed to create users.
 * Plugin activation and the admin "Repair" button run in wp-admin as a real administrator, so they
 * always can; a Claude MCP write runs unauthenticated from a bot IP, where a WAF (e.g. Wordfence)
 * commonly blocks user creation. That is why we heal at ACTIVATION, not only lazily on first write.
 */
function enginekick_mcp_ensure_service_account( $create = true ) {
	$login = enginekick_mcp_service_login();
	$user  = get_user_by( 'login', $login );
	$status = 'missing';

	// Role changes are an administrator action: reconcile a drifted role only in wp-admin as a user who
	// may manage roles, or while the role is being created. Everywhere else (MCP requests) fail closed.
	$may_reconcile = is_admin() && current_user_can( 'promote_users' );

	// A WIDENED EngineKick Service role is dealt with FIRST (V6 #10). Checked after the admin-class test,
	// a role given e.g. edit_theme_options made the account "admin-class" and returned before the role
	// could ever be repaired — so the escalation persisted. Repair it in an administrator request; refuse
	// everywhere else.
	if ( get_role( enginekick_mcp_service_role() ) && enginekick_mcp_service_role_drifted() ) {
		if ( ! $may_reconcile ) {
			return array( 'id' => 0, 'status' => 'role_drift', 'message' => 'The EngineKick Service role has been given capabilities beyond its allowed set. Writes are refused until an administrator opens any wp-admin page, which removes them.' );
		}
		enginekick_mcp_ensure_service_role();
		if ( $user ) {
			$user = get_user_by( 'id', $user->ID );
		}
	}

	if ( $user ) {
		$is_admin = enginekick_mcp_user_is_admin_class( $user );
		$marked   = ( '1' === get_user_meta( $user->ID, 'enginekick_service', true ) );

		if ( $is_admin ) {
			// A site-managing account must never be adopted as the execution identity, marker or not.
			return array( 'id' => 0, 'status' => 'admin_class', 'message' => 'A user named "' . $login . '" exists but can manage the site. Delete it (reassign its posts), then repair — a fresh account with the least-privilege EngineKick Service role will be created.' );
		}
		if ( ! $marked ) {
			// NO SILENT ADOPTION (V6 #10). An account with this login that the plugin neither created nor
			// was told to adopt may belong to the site owner. Taking it over — marking it, changing its role,
			// running writes as it — is an administrator's decision, made with the Adopt button.
			return array( 'id' => 0, 'status' => 'unadopted', 'message' => 'A user named "' . $login . '" already exists but was not created by this plugin, so it has not been used. If it is safe for Claude\'s edits to run as that account, click "Adopt this account" on the EngineKick MCP page. Otherwise delete or rename it (reassigning its posts) and click Repair.' );
		}
		$status = 'ready';
		// Migrate a marked account off the stock Editor role, which carries unfiltered_html.
		if ( in_array( 'editor', (array) $user->roles, true ) && ! in_array( enginekick_mcp_service_role(), (array) $user->roles, true ) ) {
			if ( ! get_role( enginekick_mcp_service_role() ) ) {
				enginekick_mcp_ensure_service_role();
			}
			// Remember what the account had before this plugin touched it (V7 #8), so uninstall can put it
			// back instead of inventing a stock Editor role it may never have held.
			if ( '' === get_user_meta( $user->ID, 'enginekick_prior_roles', true ) ) {
				update_user_meta( $user->ID, 'enginekick_prior_roles', implode( ',', array_values( (array) $user->roles ) ) );
			}
			$user->add_role( enginekick_mcp_service_role() );
			$user->remove_role( 'editor' );
			$user = get_user_by( 'id', $user->ID );
		}
		if ( ! ( user_can( $user, 'edit_others_posts' ) && user_can( $user, 'publish_posts' ) ) ) {
			return array( 'id' => 0, 'status' => 'not_editor', 'message' => 'The "' . $login . '" user cannot edit and publish posts written by other users. Set its role to "EngineKick Service" on the Users screen (never Editor or Administrator: both carry unfiltered_html), then click Repair.' );
		}
	} else {
		if ( ! $create ) {
			return array( 'id' => 0, 'status' => 'missing', 'message' => 'The service user does not exist yet. Click "Repair service account" to create it.' );
		}
		enginekick_mcp_ensure_service_role();
		$uid = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 64, true, true ),
				'user_email'   => 'service+' . wp_generate_password( 12, false, false ) . '@enginekick.invalid',
				'display_name' => 'EngineKick Service',
				'role'         => enginekick_mcp_service_role(),   // never 'editor' — see ensure_service_role()
			)
		);
		if ( is_wp_error( $uid ) ) {
			// FAIL CLOSED — no administrator fallback. Almost always a security plugin/WAF blocking
			// user creation during this request. Creating from wp-admin (activation/repair) avoids it.
			return array( 'id' => 0, 'status' => 'create_blocked', 'message' => 'Could not create the service user: ' . $uid->get_error_message() . ' — a security plugin may be blocking user creation. Create a user "' . $login . '" manually with the "EngineKick Service" role (click Repair once first so the role exists; do NOT use Editor, which carries unfiltered_html), then click Repair.' );
		}
		update_user_meta( $uid, 'enginekick_service', '1' );
		// Ownership is recorded ONLY here, at creation (V5-ext #11). The 'enginekick_service' marker
		// above is also stamped on accounts we merely ADOPT during a heal, so it cannot be treated as
		// proof that we made the account — and uninstall must never delete a user the site owner
		// created themselves.
		update_user_meta( $uid, 'enginekick_service_owned', '1' );
		$user   = get_user_by( 'id', $uid );
		$status = 'created';
	}

	if ( ! $user || enginekick_mcp_user_is_admin_class( $user ) ) {
		return array( 'id' => 0, 'status' => 'admin_class', 'message' => 'Service identity resolved to an admin-capable user — refused.' );
	}

	// SECURITY: the service identity must never hold unfiltered_html, or a leaked URL could store
	// active HTML (stored XSS). Every write path also sanitises explicitly (enginekick_mcp_kses_content).
	// EFFECTIVE-CAPABILITY CHECK (V5-ext #1): clear a user-level grant if one exists, then assert the
	// real merged capability. A role-inherited grant survives remove_cap(), so if it is still true the
	// identity is unsafe to write as — fail closed and tell the administrator exactly why.
	if ( isset( $user->caps['unfiltered_html'] ) ) {
		$user->remove_cap( 'unfiltered_html' );
	}
	if ( user_can( $user, 'unfiltered_html' ) ) {
		return array(
			'id'      => 0,
			'status'  => 'unfiltered_html',
			'message' => 'The "' . $login . '" account still resolves unfiltered_html (it is inherited from a role, which cannot be removed per-user). Writes are refused. Set its role to "EngineKick Service" on the Users screen, or delete the account and click Repair.',
		);
	}
	return array( 'id' => (int) $user->ID, 'status' => $status, 'message' => 'Service account ready (user #' . (int) $user->ID . ').' );
}
// Content sanitiser: the SAME validation for plain and base64-decoded content (review V4 #2). wp_kses_post
// preserves Gutenberg block delimiters and normal formatting but removes <script>, <iframe>, <object>,
// on* event-handler attributes and javascript:/data: URL schemes — so no MCP tool can store active HTML.
// It is applied to content this connector AUTHORS, never to content that was already on the site.
function enginekick_mcp_kses_content( $html ) {
	return wp_kses_post( (string) $html );
}

/**
 * Save a post without letting WordPress re-sanitise content this call did not author (V7 #1).
 *
 * The service identity has no unfiltered_html, so WordPress runs wp_filter_post_kses over post_content on
 * every save. wp_update_post() also merges the EXISTING body into the update, so a title-only edit re-saved
 * the old content through KSES — and an administrator's iframe embed, custom HTML block or form was removed
 * by an edit that never asked to touch it. Verified on WordPress 7.1: a title-only update emptied a
 * <!-- wp:html --> block.
 *
 * So: every field this connector supplies is sanitised explicitly before it gets here (see
 * enginekick_mcp_kses_content), and the save itself runs with the KSES save filters lifted, leaving
 * untouched markup byte-for-byte as the site owner wrote it. kses_init() restores exactly the filters this
 * user should have. Granting the account unfiltered_html would have had the same effect on this call and a
 * much worse one everywhere else, which is why it is not used.
 */
function enginekick_mcp_write_post( array $postarr, $insert = false ) {
	// wp_insert_post() / wp_update_post() expect SLASHED input and unslash it before storing (R8 F2). The
	// values here are plain decoded strings, so without wp_slash() every literal backslash — Windows paths,
	// regular expressions, Gutenberg's \u0022 escapes — was silently dropped.
	$postarr = wp_slash( $postarr );
	kses_remove_filters();
	try {
		$res = $insert ? wp_insert_post( $postarr, true ) : wp_update_post( $postarr, true );
	} finally {
		// A save hook that throws must not leave the content filters off for the rest of the request (R8 F4).
		kses_init();
	}
	return $res;
}

/**
 * Administrator-confirmed adoption of a pre-existing "enginekick-service" account (V6 #10). Marks it as
 * safe to run as — never as plugin-owned, so uninstall will not delete it — then resolves it normally,
 * which moves it off the Editor role.
 */
function enginekick_mcp_adopt_service_account() {
	$user = get_user_by( 'login', enginekick_mcp_service_login() );
	if ( ! $user ) {
		return array( 'id' => 0, 'status' => 'missing', 'message' => 'There is no account to adopt. Click "Repair service account" to create one.' );
	}
	if ( enginekick_mcp_user_is_admin_class( $user ) ) {
		return array( 'id' => 0, 'status' => 'admin_class', 'message' => 'That account can manage the site and cannot be adopted. Delete it (reassigning its posts), then click Repair.' );
	}
	update_user_meta( $user->ID, 'enginekick_service', '1' );
	return enginekick_mcp_ensure_service_account( false );
}

function enginekick_mcp_author_id() {
	// Writes are gated on a positive id; reads degrade to published-only. Lazy heal is kept as a
	// backstop, but the reliable heal happens at activation/repair (admin context).
	$r = enginekick_mcp_ensure_service_account( true );
	return (int) $r['id'];
}
/**
 * Notes returned with a tool result (V6 #4). A 'partial' note means part of the request was NOT applied;
 * any other note means the request was applied but something alongside it failed (e.g. its audit record).
 * The dispatcher resets them per tool call and returns them as `warnings` (+ `partial`: true).
 */
function enginekick_mcp_note( $message = null, $partial = false, $reset = false ) {
	static $notes = array();
	if ( $reset ) {
		$notes = array();
	} elseif ( null !== $message ) {
		$notes[] = array( 'message' => (string) $message, 'partial' => (bool) $partial );
	}
	return $notes;
}
function enginekick_mcp_notes_partial() {
	return in_array( true, array_column( enginekick_mcp_note(), 'partial' ), true );
}
/**
 * Request-scoped "published content only" flag (V5-ext #6). Set when the service identity could not
 * be resolved, so the request has no authenticated context to justify reading unpublished content.
 */
function enginekick_mcp_published_only( $set = null ) {
	static $on = false;
	if ( null !== $set ) { $on = (bool) $set; }
	return $on;
}

/* ------------------------------------------------------------------------- *
 * Operating mode + capability gates (review issues #1, #3 + design rec)
 * off | read_only | draft_write | publish. Default draft_write: can create and edit drafts but
 * never publish or alter live content. The operator raises the mode in the admin page.
 * ------------------------------------------------------------------------- */
function enginekick_mcp_mode() {
	// SECURE DEFAULT: a fresh install is OFF until an admin deliberately enables a mode (review v2 #3).
	$m     = (string) get_option( 'enginekick_mcp_mode', 'off' );
	$valid = array( 'off', 'read_only', 'draft_write', 'publish' );
	return in_array( $m, $valid, true ) ? $m : 'off';
}
function enginekick_mcp_read_tools() {
	return array( 'get_site_info', 'list_posts', 'get_post', 'list_terms', 'list_media', 'get_media', 'list_authors' );
}
function enginekick_mcp_is_write_tool( $name ) {
	return ! in_array( $name, enginekick_mcp_read_tools(), true );
}
// In draft_write mode, block any operation that would change LIVE (published/private/future) content.
function enginekick_mcp_guard_live_edit( $post_id ) {
	if ( 'publish' === enginekick_mcp_mode() ) {
		return true;
	}
	$p = get_post( $post_id );
	if ( $p && in_array( $p->post_status, array( 'publish', 'private', 'future' ), true ) ) {
		return new WP_Error( 'draft_only', 'Draft-only mode: this post is live (' . $p->post_status . '). Switch the EngineKick MCP to publish mode to edit live content.' );
	}
	return true;
}

/* ------------------------------------------------------------------------- *
 * Object-access guard (review V4 #1): the service Editor is an ATTRIBUTION identity, not an access
 * boundary — wp_insert_post()/wp_update_post() are low-level DB APIs that do NOT enforce per-object
 * edit/publish capabilities. So every read/write tool must (a) restrict to an allowlist of post types
 * and (b) check the WordPress capability for the exact object. This rejects revisions, menus,
 * templates, global styles and unsupported custom post types even when their ID is known.
 * ------------------------------------------------------------------------- */
function enginekick_mcp_allowed_post_types() {
	// Default to the editorial types only. Operators can widen it via the option (comma/space list);
	// unknown/registered types are still validated against post_type_exists().
	$raw = trim( (string) get_option( 'enginekick_mcp_post_types', '' ) );
	$types = $raw ? preg_split( '/[\s,]+/', $raw ) : array( 'post', 'page' );
	$out = array();
	foreach ( (array) $types as $t ) {
		$t = sanitize_key( $t );
		if ( '' !== $t && post_type_exists( $t ) && ! in_array( $t, $out, true ) ) {
			$out[] = $t;
		}
	}
	return $out ? $out : array( 'post', 'page' );
}
// Internal/system post types that must NEVER be touched through MCP, even if added to the allowlist.
function enginekick_mcp_blocked_post_types() {
	return array( 'revision', 'nav_menu_item', 'wp_template', 'wp_template_part', 'wp_global_styles',
		'wp_navigation', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_font_family',
		'wp_font_face', 'custom_css', 'attachment' ); // attachments have their own media handlers/caps
}
/**
 * Guard access to a post object. $need_cap is the capability primitive to require against THIS object:
 * 'read_post', 'edit_post' or 'publish_post'. Returns the WP_Post on success, or a WP_Error to return.
 */
/**
 * The capability that publishes this post type, falling back to the generic one. Kept as a function so the
 * lookup is an isset() on a property rather than on a function result (which PHP 5.6 cannot parse).
 */
function enginekick_mcp_publish_cap( $post_type ) {
	$obj = get_post_type_object( $post_type );
	return isset( $obj->cap->publish_posts ) ? $obj->cap->publish_posts : 'publish_posts';
}
function enginekick_mcp_object_guard( $post_id, $need_cap ) {
	$post_id = (int) $post_id;
	$p = $post_id ? get_post( $post_id ) : null;
	if ( ! $p ) {
		return new WP_Error( 'not_found', 'Post not found.' );
	}
	$pt = $p->post_type;
	if ( in_array( $pt, enginekick_mcp_blocked_post_types(), true ) ) {
		return new WP_Error( 'forbidden_object', 'That object type (' . $pt . ') cannot be accessed through the connector.' );
	}
	if ( ! in_array( $pt, enginekick_mcp_allowed_post_types(), true ) ) {
		return new WP_Error( 'forbidden_type', 'Post type "' . $pt . '" is not enabled for the connector (allowed: ' . implode( ', ', enginekick_mcp_allowed_post_types() ) . ').' );
	}
	// Per-object WordPress capability (the service user is set as current — review V4 #1). publish_post
	// takes the post type's publish cap; read/edit take the mapped meta caps for this specific object.
	// Published-only fallback (V7 #9): with no service identity the request runs as user 0, and WordPress maps
	// read_post on a PUBLIC post to the plain 'read' capability, which user 0 does not have — so get_post
	// refused posts list_posts was happy to list. One explicit rule for both: publicly viewable content of an
	// enabled type is readable, nothing else is, and writes are refused elsewhere.
	if ( 'read_post' === $need_cap && enginekick_mcp_published_only() ) {
		return is_post_publicly_viewable( $p ) ? $p : new WP_Error( 'forbidden_cap', 'Only published content can be read at the moment: the connector service account is unavailable. An administrator should open the EngineKick MCP page to repair it.' );
	}
	$cap = ( 'publish_post' === $need_cap ) ? enginekick_mcp_publish_cap( $pt ) : $need_cap;
	$allowed = ( 'publish_post' === $need_cap ) ? current_user_can( $cap ) : current_user_can( $cap, $post_id );
	if ( ! $allowed ) {
		return new WP_Error( 'forbidden_cap', 'The connector service account lacks the capability to ' . $need_cap . ' this object.' );
	}
	return $p;
}
// Create guard: validate the requested post type against the allowlist + the create capability.
function enginekick_mcp_create_guard( $post_type ) {
	$pt = sanitize_key( (string) $post_type );
	if ( '' === $pt ) { $pt = 'post'; }
	if ( in_array( $pt, enginekick_mcp_blocked_post_types(), true ) || ! in_array( $pt, enginekick_mcp_allowed_post_types(), true ) ) {
		return new WP_Error( 'forbidden_type', 'Cannot create post type "' . $pt . '" (allowed: ' . implode( ', ', enginekick_mcp_allowed_post_types() ) . ').' );
	}
	$obj = get_post_type_object( $pt );
	$cap = ( isset( $obj->cap->create_posts ) ? $obj->cap->create_posts : ( ( isset( $obj->cap->edit_posts ) ? $obj->cap->edit_posts : 'edit_posts' ) ) );
	if ( ! current_user_can( $cap ) ) {
		return new WP_Error( 'forbidden_cap', 'The connector service account cannot create ' . $pt . ' objects.' );
	}
	return $pt;
}

/**
 * Attachment access guard (V5 F3). Media tools cannot reuse enginekick_mcp_object_guard() — the
 * 'attachment' type is deliberately in the BLOCKED list there, because media has its own handlers.
 * The consequence was that get_media/update_media/upload_media_from_url ran with NO capability check
 * and NO draft-mode guard at all: in draft_write mode a caller could rewrite the alt text, caption
 * and title of every image on every published page, and alt text/captions render on the front end.
 *
 * $need_cap is 'read_post' or 'edit_post', checked against THIS attachment. In any non-publish mode
 * an edit is additionally refused when the item is part of the live library — attached to live
 * content, or unattached (an unattached item can still be used in live posts and has its own
 * attachment page). Bulk alt-text work is therefore a publish-mode operation, by design.
 */
/**
 * Extra MIME types an operator has deliberately enabled beyond images (option enginekick_mcp_media_mimes).
 * Each entry must be an exact type/subtype — a wildcard or SQL metacharacter in the option would
 * otherwise reach WP_Query just as it did from the request (V5-ext #2).
 */
function enginekick_mcp_widened_mimes() {
	$raw = trim( (string) get_option( 'enginekick_mcp_media_mimes', '' ) );
	$out = array();
	foreach ( $raw ? preg_split( '/[\s,]+/', $raw ) : array() as $m ) {
		$m = strtolower( trim( $m ) );
		if ( preg_match( '#^[a-z0-9]+/[a-z0-9][a-z0-9.+-]*$#', $m ) && ! in_array( $m, $out, true ) ) {
			$out[] = $m;
		}
	}
	return $out;
}
// The single media-scope test, shared by listing, retrieval, editing and reuse (V5-ext #2).
function enginekick_mcp_attachment_mime_ok( $mime ) {
	$mime = strtolower( (string) $mime );
	return (bool) preg_match( '#^image/[a-z0-9][a-z0-9.+-]*$#', $mime ) || in_array( $mime, enginekick_mcp_widened_mimes(), true );
}

function enginekick_mcp_attachment_guard( $att_id, $need_cap ) {
	$att_id = (int) $att_id;
	if ( ! $att_id || 'attachment' !== get_post_type( $att_id ) ) {
		return new WP_Error( 'not_found', 'Attachment not found.' );
	}
	// Media scope (V5-ext #2): the image-only boundary used to be enforced by list_media's query alone,
	// so get_media, update_media and attachment reuse would all happily act on a PDF by ID. Enforcing
	// it here applies ONE policy to every media path.
	if ( ! enginekick_mcp_attachment_mime_ok( get_post_mime_type( $att_id ) ) ) {
		return new WP_Error( 'forbidden_mime', 'Attachment #' . $att_id . ' (' . get_post_mime_type( $att_id ) . ') is outside the media scope of this connector (images only).' );
	}
	// Same published-only rule as posts (V7 #9): an attachment on publicly viewable content stays readable.
	if ( 'read_post' === $need_cap && enginekick_mcp_published_only() ) {
		$parent = (int) get_post_field( 'post_parent', $att_id );
		$host   = $parent ? get_post( $parent ) : null;
		if ( ! $host || ! is_post_publicly_viewable( $host ) ) {
			return new WP_Error( 'forbidden_cap', 'Only media on published content can be read at the moment: the connector service account is unavailable.' );
		}
	} elseif ( ! current_user_can( $need_cap, $att_id ) ) {
		return new WP_Error( 'forbidden_cap', 'The connector service account lacks the capability to ' . $need_cap . ' this attachment.' );
	}
	if ( 'edit_post' === $need_cap && 'publish' !== enginekick_mcp_mode() ) {
		// V5-ext #4: a draft parent is NOT proof the item is invisible — the same attachment can be
		// embedded in any number of published posts, so editing its alt text or caption still changes
		// live output. post_parent records only where it was uploaded. Rather than scan the whole
		// wp_posts table for embeds on every call, the rule is: outside publish mode you may only
		// edit media THIS request just uploaded, which by construction is not on a live page yet.
		if ( ! in_array( (int) $att_id, enginekick_mcp_uploads_this_request(), true ) ) {
			return new WP_Error(
				'draft_only',
				'Draft-only mode: media metadata edits require publish mode, because an existing '
					. 'attachment may be embedded in published content regardless of what it is attached to. '
					. 'Set alt text and captions at upload time instead, or switch to publish mode.'
			);
		}
	}
	return get_post( $att_id );
}
/**
 * Attachment IDs created by this request. Used to allow metadata edits on media the connector has
 * just uploaded while refusing edits to pre-existing (possibly live-embedded) media.
 */
function enginekick_mcp_uploads_this_request( $add = 0 ) {
	static $ids = array();
	$add = (int) $add;
	if ( $add > 0 && ! in_array( $add, $ids, true ) ) {
		$ids[] = $add;
	}
	return $ids;
}

/* Field / image / request / batch caps (review issues #3, #4 + v2 #4). */
if ( ! defined( 'ENGINEKICK_MCP_MAX_FIELD_BYTES' ) ) { define( 'ENGINEKICK_MCP_MAX_FIELD_BYTES', 2 * 1024 * 1024 ); }
if ( ! defined( 'ENGINEKICK_MCP_MAX_IMAGE_BYTES' ) ) { define( 'ENGINEKICK_MCP_MAX_IMAGE_BYTES', 15 * 1024 * 1024 ); }
if ( ! defined( 'ENGINEKICK_MCP_MAX_BODY_BYTES' ) )  { define( 'ENGINEKICK_MCP_MAX_BODY_BYTES', 6 * 1024 * 1024 ); }  // whole request body
if ( ! defined( 'ENGINEKICK_MCP_MAX_BATCH' ) )       { define( 'ENGINEKICK_MCP_MAX_BATCH', 20 ); }                    // JSON-RPC batch messages
if ( ! defined( 'ENGINEKICK_MCP_MAX_SEARCH' ) )      { define( 'ENGINEKICK_MCP_MAX_SEARCH', 200 ); }                  // list search text (R8 F10)
if ( ! defined( 'ENGINEKICK_MCP_MAX_OFFSET' ) )      { define( 'ENGINEKICK_MCP_MAX_OFFSET', 50000 ); }                // deepest list position (R8 F10)
if ( ! defined( 'ENGINEKICK_MCP_MAX_RESPONSE_BYTES' ) ) { define( 'ENGINEKICK_MCP_MAX_RESPONSE_BYTES', 8 * 1024 * 1024 ); }   // one batch's output (R8 F10)
// Decoded-size limits for imported images (pre-install #2). File size says nothing about decode cost: a 1 MB
// PNG can declare 20000 x 20000 pixels and needs ~1.6 GB to decode. 36 MP (~144 MB in GD) fits the 256 MB
// WordPress raises memory to for image work, and covers ordinary camera photos.
if ( ! defined( 'ENGINEKICK_MCP_MAX_IMAGE_PIXELS' ) ) { define( 'ENGINEKICK_MCP_MAX_IMAGE_PIXELS', 36000000 ); }
if ( ! defined( 'ENGINEKICK_MCP_MAX_IMAGE_SIDE' ) )   { define( 'ENGINEKICK_MCP_MAX_IMAGE_SIDE', 12000 ); }

/* ------------------------------------------------------------------------- *
 * Shared security helpers — client IP, allowlist, rate limit (review #1, #2, #5, #6).
 * function_exists-guarded so the connector module can define the same names when running solo.
 * ------------------------------------------------------------------------- */
// Proxies/CDNs the administrator declared trusted (option enginekick_trusted_proxies: IPs or CIDRs).
function enginekick_trusted_proxies() {
	$raw = trim( (string) get_option( 'enginekick_trusted_proxies', '' ) );
	return '' === $raw ? array() : array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', $raw ) ) ) );
}
function enginekick_ip_in_list( $ip, array $list ) {
	foreach ( $list as $entry ) {
		if ( '' !== $entry && enginekick_ip_in_cidr( $ip, $entry ) ) {
			return true;
		}
	}
	return false;
}
/**
 * The visitor's IP address (V5 F7, pre-install #5).
 *
 * REMOTE_ADDR is whatever connected to PHP. Behind Cloudflare or a load balancer that is the proxy, so the
 * IP allowlist, the rate limits and the audit log all saw the proxy. When REMOTE_ADDR is a proxy the
 * administrator listed as trusted, X-Forwarded-For is walked from the RIGHT, skipping trusted hops, and the
 * first untrusted address is the visitor. Addresses a client forges are prepended further LEFT and are never
 * reached. With no trusted proxies configured, forwarding headers are ignored entirely.
 */
function enginekick_client_ip() {
	$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
	if ( ! filter_var( $remote, FILTER_VALIDATE_IP ) ) {
		return '';
	}
	$trusted = enginekick_trusted_proxies();
	if ( ! $trusted || ! enginekick_ip_in_list( $remote, $trusted ) ) {
		return $remote;
	}
	$hops = array_reverse( array_map( 'trim', explode( ',', (string) ( ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : '' ) ) ) ) );
	foreach ( $hops as $hop ) {
		if ( ! filter_var( $hop, FILTER_VALIDATE_IP ) ) {
			break;   // malformed chain: fall back to the proxy's own address (fails closed on an allowlist)
		}
		if ( ! enginekick_ip_in_list( $hop, $trusted ) ) {
			return $hop;
		}
	}
	return $remote;
}
/**
 * Globally routable unicast addresses only (V7 #2).
 *
 * PHP's NO_PRIV_RANGE|NO_RES_RANGE flags are not the same thing as "public": they accept carrier-grade
 * NAT (100.64/10), IETF protocol assignments (192.0.0/24), the TEST-NETs, benchmarking (198.18/15),
 * multicast, the IPv6 documentation range and the NAT64 prefix — all verified on PHP 8.3. WordPress's own
 * wp_http_validate_url() blocks the IPv4 ones, but this list is what decides the address the connection is
 * PINNED to, so it does the full check itself, for IPv6 as well.
 */
function enginekick_ip_is_public( $ip ) {
	if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
		return false;
	}
	$blocked = array(
		// IPv4 special-purpose ranges (IANA), plus multicast and reserved space.
		'0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16', '172.16.0.0/12',
		'192.0.0.0/24', '192.0.2.0/24', '192.88.99.0/24', '192.168.0.0/16', '198.18.0.0/15',
		'198.51.100.0/24', '203.0.113.0/24', '224.0.0.0/4', '240.0.0.0/4',
		// IPv6: unspecified, loopback, IPv4-mapped/translated, NAT64, discard, documentation,
		// unique-local, link-local and multicast.
		'::/128', '::1/128', '::ffff:0:0/96', '64:ff9b::/96', '64:ff9b:1::/48', '100::/64',
		'2001:db8::/32', 'fc00::/7', 'fe80::/10', 'ff00::/8',
	);
	foreach ( $blocked as $range ) {
		if ( enginekick_ip_in_cidr( $ip, $range ) ) {
			return false;
		}
	}
	return true;
}
function enginekick_ip_in_cidr( $ip, $range ) {
	if ( false === strpos( $range, '/' ) ) {
		return $ip === $range;
	}
	list( $subnet, $bits ) = explode( '/', $range, 2 );
	$bits       = (int) $bits;
	$ip_bin     = @inet_pton( $ip );
	$subnet_bin = @inet_pton( $subnet );
	if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
		return false;
	}
	$bytes = (int) floor( $bits / 8 );
	$rem   = $bits % 8;
	if ( $bytes && 0 !== substr_compare( $ip_bin, $subnet_bin, 0, $bytes ) ) {
		return false;
	}
	if ( $rem ) {
		$mask = chr( ( 0xff << ( 8 - $rem ) ) & 0xff );
		if ( ( $ip_bin[ $bytes ] & $mask ) !== ( $subnet_bin[ $bytes ] & $mask ) ) {
			return false;
		}
	}
	return true;
}
// Validate allowlist entries on save: keep only well-formed IPs / CIDRs (IPv4 prefix 0-32,
// IPv6 0-128); drop invalid ones rather than silently accepting them (review v2 hardening).
function enginekick_sanitize_allowed_ips( $raw ) {
	$out = array();
	foreach ( preg_split( '/[\s,]+/', (string) $raw ) as $e ) {
		$e = trim( $e );
		if ( '' === $e ) {
			continue;
		}
		if ( false !== strpos( $e, '/' ) ) {
			list( $ip, $bits ) = explode( '/', $e, 2 );
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) || ! ctype_digit( (string) $bits ) ) {
				continue;
			}
			$max = ( false !== strpos( $ip, ':' ) ) ? 128 : 32;
			if ( (int) $bits > $max ) {
				continue;
			}
			$out[] = $ip . '/' . (int) $bits;
		} elseif ( filter_var( $e, FILTER_VALIDATE_IP ) ) {
			$out[] = $e;
		}
	}
	// An all-invalid, non-empty submission must NOT collapse to '' — enginekick_ip_allowed()
	// reads '' as "allow every IP", so a single typo silently removed the restriction the
	// administrator thought they had set (V5-ext #10). Signal it; the settings handlers keep
	// the previous value and show an error instead of saving.
	if ( ! $out && '' !== trim( (string) $raw ) ) {
		return new WP_Error( 'bad_allowlist', 'None of those entries is a valid IP address or CIDR range, so the IP restriction was NOT changed. Clear the box explicitly if you meant to allow every IP.' );
	}
	return implode( "\n", $out );
}
// Empty allowlist = allow all (so existing installs are never locked out). When set, REMOTE_ADDR
// must match a plain IP or CIDR entry (comma/newline separated).
function enginekick_ip_allowed() {
	$raw = trim( (string) get_option( 'enginekick_allowed_ips', '' ) );
	if ( '' === $raw ) {
		return true;
	}
	$raw = enginekick_mcp_upgrade_claude_range( $raw );
	$ip = enginekick_client_ip();
	return '' !== $ip && enginekick_ip_in_list( $ip, array_map( 'trim', preg_split( '/[\s,]+/', $raw ) ) );
}
// Table behind the atomic counter (V5-ext #9).
function enginekick_rate_table() {
	global $wpdb;
	return $wpdb->prefix . 'enginekick_rate';
}
/**
 * ATOMIC fixed-window counter (V5-ext #9). Charges $weight to $key for the current window and returns
 * the post-increment total, or false when no atomic counter is available so the caller can degrade.
 *
 * - Persistent object cache: wp_cache_add() is an atomic create-if-absent and wp_cache_incr() an
 *   atomic increment in Redis/Memcached. The window index is part of the key, so each window starts
 *   clean and the TTL only garbage-collects.
 * - Otherwise: a single INSERT ... ON DUPLICATE KEY UPDATE, which the database executes atomically
 *   under the row lock. The read-back can only see a value >= our own charge, so concurrent callers
 *   may over-reject at the boundary but can never admit more than the limit.
 *
 * The old transient path was get → add → set: two concurrent requests both read N and both wrote N+1.
 */
function enginekick_counter_hit( $key, $window, $weight = 1 ) {
	global $wpdb;
	$weight = max( 1, (int) $weight );
	$window = max( 1, (int) $window );
	$win    = (int) floor( time() / $window );
	$bkey   = md5( (string) $key );
	if ( wp_using_ext_object_cache() ) {
		$ck = 'ek_c_' . $bkey . '_' . $win;
		wp_cache_add( $ck, 0, 'enginekick', $window + 5 );
		$n = wp_cache_incr( $ck, $weight, 'enginekick' );
		if ( false !== $n ) {
			return (int) $n;
		}
		// Evicted between add and incr — fall through to the database counter.
	}
	$t     = enginekick_rate_table();
	$exp   = ( $win + 1 ) * $window;
	$quiet = $wpdb->suppress_errors( true );   // a missing table is a known degraded state, not log noise
	$ok    = $wpdb->query( $wpdb->prepare(
		"INSERT INTO $t (bkey, win, exp, n) VALUES (%s, %d, %d, %d) ON DUPLICATE KEY UPDATE n = CASE WHEN win = %d THEN n + %d ELSE %d END, win = %d, exp = %d",
		$bkey, $win, $exp, $weight, $win, $weight, $weight, $win, $exp
	) );
	if ( false === $ok ) {
		$wpdb->suppress_errors( $quiet );
		return false;   // table missing (pre-heal) or the statement failed
	}
	$n = $wpdb->get_var( $wpdb->prepare( "SELECT n FROM $t WHERE bkey = %s AND win = %d", $bkey, $win ) );
	$wpdb->suppress_errors( $quiet );
	if ( null === $n ) {
		return false;
	}
	// Garbage-collect expired rows occasionally, in a bounded batch (V6 #6).
	if ( 1 === wp_rand( 1, 500 ) ) {
		enginekick_rate_gc();
	}
	return (int) $n;
}
/**
 * Delete at most one batch of expired rate rows (V6 #6: this was a single unbounded DELETE, so a
 * distributed flood that grew the table by distinct IP was followed by one large delete). Returns the
 * number of rows removed. Rows are keyed per client IP, so upstream (web server / CDN) rate limiting is
 * still what protects PHP and the database from traffic that never reaches this code.
 */
function enginekick_rate_gc( $batch = 500 ) {
	global $wpdb;
	$t = enginekick_rate_table();
	return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE exp < %d ORDER BY exp ASC LIMIT %d", time() - 300, max( 1, (int) $batch ) ) );
}
// Per-IP rate limit on the atomic counter. `weight` charges N units (a batch charges per message).
// Charge-then-check: the request's own weight is counted before the limit is compared.
function enginekick_rate_ok( $bucket, $limit, $window, $weight = 1 ) {
	$weight = max( 1, (int) $weight );
	$n      = enginekick_counter_hit( $bucket . '|' . enginekick_client_ip(), $window, $weight );
	if ( false !== $n ) {
		return $n <= (int) $limit;
	}
	// DEGRADED MODE ONLY — no atomic counter yet (the rate table is created at activation and healed
	// on the next admin page load). A soft transient throttle beats no throttle; it is not a hard
	// boundary under concurrency.
	$key = 'ek_rl_' . md5( $bucket . '|' . enginekick_client_ip() );
	$cur = (int) get_transient( $key );
	if ( $cur + $weight > $limit ) {
		return false;
	}
	set_transient( $key, $cur + $weight, $window );
	return true;
}

/* ------------------------------------------------------------------------- *
 * SSRF-safe image fetch (review issue #4): https only, host must resolve to a PUBLIC IP,
 * size-capped, image MIME only. Replaces the raw download_url() call.
 * ------------------------------------------------------------------------- */
/**
 * Vet one image URL: https on the standard port, and the host resolves ONLY to public addresses.
 * Returns array( host, ip ) — the address the connection will be pinned to — or a WP_Error.
 */
function enginekick_mcp_vet_image_url( $url ) {
	$parts = wp_parse_url( $url );
	if ( ! $parts || empty( $parts['scheme'] ) || 'https' !== strtolower( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return new WP_Error( 'bad_url', 'Only https:// image URLs are allowed (a redirect to a non-https URL is refused too).' );
	}
	if ( isset( $parts['port'] ) && 443 !== (int) $parts['port'] ) {
		return new WP_Error( 'bad_url', 'Only the standard https port (443) is allowed.' );
	}
	$host = strtolower( trim( $parts['host'], '[]' ) );
	$ips  = array();
	if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
		$ips[] = $host;
	} else {
		$recs = @dns_get_record( $host, DNS_A | DNS_AAAA );
		if ( is_array( $recs ) ) {
			foreach ( $recs as $r ) {
				if ( ! empty( $r['ip'] ) ) {
					$ips[] = $r['ip'];
				}
				if ( ! empty( $r['ipv6'] ) ) {
					$ips[] = $r['ipv6'];
				}
			}
		}
		if ( ! $ips ) {
			$l = @gethostbynamel( $host );
			if ( is_array( $l ) ) {
				$ips = $l;
			}
		}
	}
	if ( ! $ips ) {
		return new WP_Error( 'bad_url', 'Could not resolve the image host.' );
	}
	foreach ( $ips as $ip ) {
		if ( ! enginekick_ip_is_public( $ip ) ) {
			return new WP_Error( 'blocked_url', 'That URL resolves to a private, loopback, link-local, or reserved IP and is blocked (SSRF protection).' );
		}
	}
	return array( 'host' => $host, 'ip' => $ips[0] );
}

/**
 * GET with the connection PINNED to the vetted address (pre-install #7). Our DNS check, WordPress's own
 * check and cURL each resolved the host separately, so a hostile DNS server could answer "public" to the
 * checks and "internal" to the connection (DNS rebinding). CURLOPT_RESOLVE makes cURL connect to exactly
 * the address that was vetted. The transport never follows redirects; the caller does, re-vetting and
 * re-pinning each hop. Pinning needs WordPress's cURL transport, which is the default.
 */
// Can this installation pin a connection to a vetted address at all? (V7 #2: the fetch must fail closed
// rather than quietly fall back to an unpinned transport that re-resolves the host.)
function enginekick_mcp_can_pin() {
	return function_exists( 'curl_init' ) && defined( 'CURLOPT_RESOLVE' );
}
/** The cURL transport class of whichever Requests library this WordPress ships (Requests 2 since WP 6.2). */
function enginekick_mcp_curl_transport_class() {
	if ( class_exists( '\WpOrg\Requests\Transport\Curl' ) ) {
		return '\WpOrg\Requests\Transport\Curl';
	}
	return class_exists( 'Requests_Transport_cURL' ) ? 'Requests_Transport_cURL' : '';
}
function enginekick_mcp_pinned_get( $url, array $vet ) {
	if ( ! enginekick_mcp_can_pin() || '' === enginekick_mcp_curl_transport_class() ) {
		return new WP_Error( 'no_pinning', 'This server has no cURL support, so the image download cannot be pinned to the address that was checked. Image import is disabled rather than risk fetching a different address (DNS rebinding).' );
	}
	// A proxy resolves the destination itself, so pinning cannot apply. Refuse BEFORE any connection (R8 F5).
	$proxy = new WP_HTTP_Proxy();
	if ( $proxy->is_enabled() && $proxy->send_through_proxy( $url ) ) {
		return new WP_Error( 'no_pinning', 'This site sends outbound requests through an HTTP proxy, which looks up the address itself, so the download cannot be pinned to the address that was checked. Image import is refused (DNS rebinding protection).' );
	}
	$ip     = ( false !== strpos( $vet['ip'], ':' ) ) ? '[' . $vet['ip'] . ']' : $vet['ip'];
	$pinned = false;
	$short  = false;
	$pin    = function ( $handle, $args, $req_url ) use ( $url, $vet, $ip, &$pinned ) {
		if ( $req_url !== $url ) {
			return;
		}
		if ( false !== curl_setopt( $handle, CURLOPT_RESOLVE, array( $vet['host'] . ':443:' . $ip ) ) ) {
			$pinned = true;
			return;
		}
		// Pin failed: make this handle unable to connect anywhere, rather than discovering it afterwards (R8 F5).
		if ( defined( 'CURLOPT_PROTOCOLS' ) ) {
			curl_setopt( $handle, CURLOPT_PROTOCOLS, 0 );
		}
		curl_setopt( $handle, CURLOPT_URL, 'https://pin-failed.invalid/' );
	};
	// Force the cURL transport for this request: the fallback transport cannot be pinned, and WordPress picks
	// it silently when cURL lacks something (R8 F5).
	$force = function ( &$r_url, &$r_headers, &$r_data, &$r_type, &$r_options ) use ( $url ) {
		if ( $r_url === $url ) {
			$r_options['transport'] = enginekick_mcp_curl_transport_class();
		}
	};
	// Another plugin (or a test fixture) may answer the request before any transport runs. That is not an
	// unpinned network fetch, so it is distinguished from one rather than treated as a failure.
	$watch = function ( $pre ) use ( &$short ) {
		if ( false !== $pre ) {
			$short = true;
		}
		return $pre;
	};
	add_filter( 'pre_http_request', $watch, PHP_INT_MAX );
	add_action( 'http_api_curl', $pin, 10, 3 );
	add_action( 'requests-requests.before_request', $force, 10, 5 );
	try {
		$resp = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 20,
				'redirection'         => 0,
				'limit_response_size' => ENGINEKICK_MCP_MAX_IMAGE_BYTES,
			)
		);
	} finally {
		// Removed even if a hook throws (R8 F4).
		remove_action( 'requests-requests.before_request', $force, 10 );
		remove_action( 'http_api_curl', $pin, 10 );
		remove_filter( 'pre_http_request', $watch, PHP_INT_MAX );
	}
	if ( ! $pinned && ! $short && ! is_wp_error( $resp ) ) {
		return new WP_Error( 'no_pinning', 'The image download could not be pinned to the address that was checked, so it was refused (DNS rebinding protection).' );
	}
	return $resp;
}

function enginekick_mcp_fetch_image( $url ) {
	$url  = trim( (string) $url );
	$hops = 0;
	while ( true ) {
		// Every hop is vetted the same way as the first URL: https only, public addresses only, pinned.
		// The transport used to follow up to two redirects itself, which allowed a downgrade to http.
		$vet = enginekick_mcp_vet_image_url( $url );
		if ( is_wp_error( $vet ) ) {
			return $vet;
		}
		$resp = enginekick_mcp_pinned_get( $url, $vet );
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		if ( ! in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
			break;
		}
		if ( ++$hops > 2 ) {
			return new WP_Error( 'too_many_redirects', 'The image URL redirected more than twice.' );
		}
		$loc = (string) wp_remote_retrieve_header( $resp, 'location' );
		if ( '' === $loc ) {
			return new WP_Error( 'fetch_failed', 'The image URL redirected without a destination.' );
		}
		$url = WP_Http::make_absolute_url( $loc, $url );
	}
	if ( 200 !== $code ) {
		return new WP_Error( 'fetch_failed', 'Image fetch returned HTTP ' . $code . '.' );
	}
	$allowed = array(
		'image/jpeg' => 'jpg',
		'image/jpg'  => 'jpg',
		'image/png'  => 'png',
		'image/gif'  => 'gif',
		'image/webp' => 'webp',
	);
	$ctype = strtolower( (string) wp_remote_retrieve_header( $resp, 'content-type' ) );
	$mime  = trim( explode( ';', $ctype )[0] );
	if ( ! isset( $allowed[ $mime ] ) ) {
		return new WP_Error( 'bad_type', 'Only JPEG, PNG, GIF, and WebP images are allowed (got "' . $mime . '").' );
	}
	$body = wp_remote_retrieve_body( $resp );
	if ( '' === $body ) {
		return new WP_Error( 'empty', 'The image response was empty.' );
	}
	if ( strlen( $body ) > ENGINEKICK_MCP_MAX_IMAGE_BYTES ) {
		return new WP_Error( 'too_large', 'The image exceeds the ' . (int) ( ENGINEKICK_MCP_MAX_IMAGE_BYTES / 1048576 ) . ' MB limit.' );
	}
	// Validate the BYTES, not the label (V6 #1). The Content-Type check above is only the server's claim:
	// a PDF served as image/jpeg passed it, kept its .pdf name from the URL, and WordPress imported it as
	// a PDF. The file's real type now decides, and the stored extension is derived from that type.
	$info  = @getimagesizefromstring( $body );
	$types = array(
		IMAGETYPE_JPEG => array( 'image/jpeg', 'jpg' ),
		IMAGETYPE_PNG  => array( 'image/png', 'png' ),
		IMAGETYPE_GIF  => array( 'image/gif', 'gif' ),
		IMAGETYPE_WEBP => array( 'image/webp', 'webp' ),
	);
	if ( ! is_array( $info ) || ! isset( $types[ $info[2] ] ) ) {
		return new WP_Error( 'bad_type', 'The downloaded file is not a JPEG, PNG, GIF or WebP image (the server labelled it "' . $mime . '").' );
	}
	list( $real_mime, $ext ) = $types[ $info[2] ];
	$w = (int) $info[0];
	$h = (int) $info[1];
	if ( $w < 1 || $h < 1 || $w > ENGINEKICK_MCP_MAX_IMAGE_SIDE || $h > ENGINEKICK_MCP_MAX_IMAGE_SIDE || $w * $h > ENGINEKICK_MCP_MAX_IMAGE_PIXELS ) {
		return new WP_Error( 'too_many_pixels', sprintf( 'The image is %1$d x %2$d pixels; the limit is %3$d pixels per side and %4$d megapixels, because decoding a larger image would exhaust the server\'s memory.', $w, $h, ENGINEKICK_MCP_MAX_IMAGE_SIDE, (int) ( ENGINEKICK_MCP_MAX_IMAGE_PIXELS / 1000000 ) ) );
	}
	$base = sanitize_file_name( pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_FILENAME ) );
	$name = ( '' !== $base ? $base : 'image-' . time() ) . '.' . $ext;
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = wp_tempnam( $name );
	if ( ! $tmp ) {
		return new WP_Error( 'tmp_fail', 'Could not create a temp file for the image.' );
	}
	if ( false === file_put_contents( $tmp, $body ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		@unlink( $tmp );
		return new WP_Error( 'write_fail', 'Could not write the downloaded image.' );
	}
	return array( 'tmp' => $tmp, 'name' => $name, 'mime' => $real_mime );
}

/* ------------------------------------------------------------------------- *
 * Audit log (review issue #7): every MCP write, attributable — tool, object, IP, UA,
 * request id, before/after content hash + status. Table self-heals in admin.
 * ------------------------------------------------------------------------- */
function enginekick_mcp_audit_table() {
	global $wpdb;
	return $wpdb->prefix . 'enginekick_mcp_audit';
}
/**
 * True once an authenticated MCP request is running. The connector's change log stores the request id only
 * for those, so the /changes export can tell an MCP edit from a person's edit (V7 #4).
 */
function enginekick_mcp_is_active_request( $set = false ) {
	static $active = false;
	if ( $set ) {
		$active = true;
	}
	return $active;
}
function enginekick_mcp_request_id( $next = false ) {
	static $rid = null;
	// $next: a new tool call begins. Each call in a batch gets its own id, so two edits to one post in one HTTP
	// request keep their own audit detail in the /changes export (R8 F8).
	if ( null === $rid || $next ) {
		// Always generated here (pre-install hardening): a caller-supplied X-Request-ID let anyone with the
		// token choose — or collide — the id recorded in the audit log.
		$rid = bin2hex( random_bytes( 8 ) );
	}
	return $rid;
}
// Pull the structured references out of post HTML so the audit log can say EXACTLY what changed
// (which internal links / images were added or removed) — WordPress-authoritative, at write time.
// Returns array( 'links' => [ href => anchor ], 'images' => [ src => alt ], 'words' => int ).
function enginekick_mcp_extract_refs( $content ) {
	$content = (string) $content;
	$home    = wp_parse_url( home_url(), PHP_URL_HOST );
	$home    = $home ? strtolower( preg_replace( '/^www\./', '', $home ) ) : '';
	$links   = array();
	if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $content, $m, PREG_SET_ORDER ) ) {
		foreach ( $m as $a ) {
			$href = trim( $a[1] );
			if ( '' === $href || 0 === strpos( $href, '#' ) || 0 === strpos( $href, 'mailto:' ) || 0 === strpos( $href, 'tel:' ) ) {
				continue;
			}
			$host = wp_parse_url( $href, PHP_URL_HOST );
			$internal = ( null === $host ) || ( $home && strtolower( preg_replace( '/^www\./', '', (string) $host ) ) === $home );
			if ( ! $internal ) {
				continue; // only internal links (external links aren't the SEO signal we track)
			}
			$path = wp_parse_url( $href, PHP_URL_PATH );
			$key  = $path ? rtrim( $path, '/' ) : $href;
			if ( '' === $key ) {
				$key = '/';
			}
			if ( ! isset( $links[ $key ] ) ) {
				$links[ $key ] = substr( trim( wp_strip_all_tags( $a[2] ) ), 0, 120 );
			}
			if ( count( $links ) >= 400 ) {
				break;
			}
		}
	}
	$images = array();
	if ( preg_match_all( '/<img\s[^>]*>/i', $content, $mi ) ) {
		foreach ( $mi[0] as $tag ) {
			if ( ! preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $s ) ) {
				continue;
			}
			$src = trim( $s[1] );
			if ( '' === $src || 0 === strpos( $src, 'data:' ) ) {
				continue;
			}
			$path = wp_parse_url( $src, PHP_URL_PATH );
			$key  = $path ? $path : $src;
			$alt  = preg_match( '/alt=["\']([^"\']*)["\']/i', $tag, $al ) ? trim( $al[1] ) : '';
			if ( ! isset( $images[ $key ] ) ) {
				$images[ $key ] = substr( $alt, 0, 200 );
			}
			if ( count( $images ) >= 200 ) {
				break;
			}
		}
	}
	$words = str_word_count( wp_strip_all_tags( $content ) );
	return array( 'links' => $links, 'images' => $images, 'words' => (int) $words );
}
function enginekick_mcp_post_fingerprint( $post_id ) {
	$p = $post_id ? get_post( $post_id ) : null;
	if ( ! $p ) {
		return array( 'hash' => '', 'status' => '', 'title' => '', 'slug' => '', 'author' => 0, 'links' => array(), 'images' => array(), 'words' => 0, 'thumb' => '', 'thumb_name' => '' );
	}
	// Include the featured-image id so a set_featured_image change produces a different hash
	// (review v3 #4 — content/title/status alone stayed identical for that operation).
	$thumb = (string) get_post_meta( $post_id, '_thumbnail_id', true );
	$refs  = enginekick_mcp_extract_refs( $p->post_content );
	$thumb_name = '';
	if ( $thumb ) {
		$tu = wp_get_attachment_url( (int) $thumb );
		$thumb_name = $tu ? basename( (string) wp_parse_url( $tu, PHP_URL_PATH ) ) : ( 'attachment #' . $thumb );
	}
	return array(
		'hash'       => hash( 'sha256', $p->post_content . '|thumb:' . $thumb ),
		'status'     => $p->post_status,
		'title'      => $p->post_title,
		'slug'       => $p->post_name,
		'author'     => (int) $p->post_author,
		'seo'        => enginekick_mcp_seo_fields_for_audit( (int) $post_id ),
		'links'      => $refs['links'],
		'images'     => $refs['images'],
		'words'      => $refs['words'],
		'thumb'      => $thumb,
		'thumb_name' => $thumb_name,
	);
}
// Attachment fingerprint (title|alt|caption|description) — media tools have no post_content, so this
// gives them a real before/after hash instead of an empty one (review v2 #6). Keeps the individual
// fields so the audit log can say which one changed (alt text / caption / title), before -> after.
function enginekick_mcp_attachment_fingerprint( $att_id ) {
	$p = $att_id ? get_post( $att_id ) : null;
	if ( ! $p ) {
		return array( 'hash' => '', 'status' => '', 'title' => '', 'alt' => '', 'caption' => '', 'description' => '' );
	}
	$alt = (string) get_post_meta( $att_id, '_wp_attachment_image_alt', true );
	return array(
		'hash'        => hash( 'sha256', $p->post_title . '|' . $alt . '|' . $p->post_excerpt . '|' . $p->post_content ),
		'status'      => $p->post_status,
		'title'       => $p->post_title,
		'alt'         => $alt,
		'caption'     => $p->post_excerpt,
		'description' => $p->post_content,
	);
}
// Diff two fingerprints into human-readable change lines (WSAL-style: exactly WHAT changed). Works for
// posts (title/status/featured image/internal links/images/word count) and attachments (alt/caption/
// title). This is the "little details" log: "Added internal link -> /pricing", "Set featured image",
// "Added inline image hero.jpg", "Alt text: '' -> 'dashboard screenshot'". Pure — no side effects.
function enginekick_mcp_describe_changes( $tool, $object_type, $before, $after ) {
	$out = array();
	$b   = is_array( $before ) ? $before : array();
	$a   = is_array( $after ) ? $after : array();
	if ( ! $a ) {
		return $out;
	}
	if ( 'attachment' === $object_type ) {
		foreach ( array( 'alt' => 'Alt text', 'caption' => 'Caption', 'title' => 'Title', 'description' => 'Description' ) as $k => $label ) {
			if ( array_key_exists( $k, $b ) && (string) $b[ $k ] !== (string) $a[ $k ] ) {
				$out[] = $label . ': "' . mb_substr( (string) $b[ $k ], 0, 80 ) . '" -> "' . mb_substr( (string) $a[ $k ], 0, 80 ) . '"';
			}
		}
		return $out;
	}
	// created (no before) — describe the new post briefly
	if ( ! $b || ! isset( $b['title'] ) ) {
		$out[] = 'Created ' . ( isset( $a['status'] ) ? $a['status'] . ' ' : '' ) . 'post "' . mb_substr( (string) ( ( isset( $a['title'] ) ? $a['title'] : '' ) ), 0, 100 ) . '"';
		if ( ! empty( $a['words'] ) ) {
			$out[] = ( (int) $a['words'] ) . ' words';
		}
		return $out;
	}
	if ( (string) ( ( isset( $b['title'] ) ? $b['title'] : '' ) ) !== (string) ( ( isset( $a['title'] ) ? $a['title'] : '' ) ) ) {
		$out[] = 'Title: "' . mb_substr( (string) $b['title'], 0, 80 ) . '" -> "' . mb_substr( (string) $a['title'], 0, 80 ) . '"';
	}
	if ( (string) ( ( isset( $b['status'] ) ? $b['status'] : '' ) ) !== (string) ( ( isset( $a['status'] ) ? $a['status'] : '' ) ) ) {
		$out[] = 'Status: ' . ( $b['status'] ?: 'none' ) . ' -> ' . ( $a['status'] ?: 'none' );
	}
	if ( isset( $b['slug'], $a['slug'] ) && (string) $b['slug'] !== (string) $a['slug'] ) {
		$out[] = 'URL: "' . (string) $b['slug'] . '" -> "' . (string) $a['slug'] . '"';
	}
	if ( isset( $b['seo'], $a['seo'] ) && is_array( $b['seo'] ) && is_array( $a['seo'] ) ) {
		$labels = array( 'seo_title' => 'SEO title', 'meta_description' => 'Meta description', 'focus_keyword' => 'Focus keyword', 'canonical_url' => 'Canonical', 'noindex' => 'noindex', 'nofollow' => 'nofollow' );
		foreach ( $labels as $k => $label ) {
			$bv = isset( $b['seo'][ $k ] ) ? $b['seo'][ $k ] : '';
			$av = isset( $a['seo'][ $k ] ) ? $a['seo'][ $k ] : '';
			if ( $bv === $av ) {
				continue;
			}
			if ( is_bool( $av ) || is_bool( $bv ) ) {
				$out[] = $label . ': ' . ( $bv ? 'on' : 'off' ) . ' -> ' . ( $av ? 'on' : 'off' );
			} else {
				$out[] = $label . ': "' . mb_substr( (string) $bv, 0, 80 ) . '" -> "' . ( '' === (string) $av ? '(plugin default)' : mb_substr( (string) $av, 0, 80 ) ) . '"';
			}
		}
	}
	if ( isset( $b['author'], $a['author'] ) && (int) $b['author'] !== (int) $a['author'] ) {
		$out[] = 'Author: "' . enginekick_mcp_author_name( (int) $b['author'] ) . '" -> "' . enginekick_mcp_author_name( (int) $a['author'] ) . '"';
	}
	if ( (string) ( ( isset( $b['thumb'] ) ? $b['thumb'] : '' ) ) !== (string) ( ( isset( $a['thumb'] ) ? $a['thumb'] : '' ) ) ) {
		if ( empty( $a['thumb'] ) ) {
			$out[] = 'Featured image removed';
		} elseif ( empty( $b['thumb'] ) ) {
			$out[] = 'Featured image set (' . ( $a['thumb_name'] ?: ( '#' . $a['thumb'] ) ) . ')';
		} else {
			$out[] = 'Featured image changed (' . ( $a['thumb_name'] ?: ( '#' . $a['thumb'] ) ) . ')';
		}
	}
	// internal links added / removed (keyed by target path; anchor shown)
	$bl = isset( $b['links'] ) && is_array( $b['links'] ) ? $b['links'] : array();
	$al = isset( $a['links'] ) && is_array( $a['links'] ) ? $a['links'] : array();
	$added_l   = array_diff_key( $al, $bl );
	$removed_l = array_diff_key( $bl, $al );
	if ( $added_l ) {
		$out[] = enginekick_mcp_ref_line( 'Added', 'internal link', $added_l, true );
	}
	if ( $removed_l ) {
		$out[] = enginekick_mcp_ref_line( 'Removed', 'internal link', $removed_l, true );
	}
	// images added / removed (keyed by src path)
	$bi = isset( $b['images'] ) && is_array( $b['images'] ) ? $b['images'] : array();
	$ai = isset( $a['images'] ) && is_array( $a['images'] ) ? $a['images'] : array();
	$added_i   = array_diff_key( $ai, $bi );
	$removed_i = array_diff_key( $bi, $ai );
	if ( $added_i ) {
		$out[] = enginekick_mcp_ref_line( 'Added', 'inline image', $added_i, false );
	}
	if ( $removed_i ) {
		$out[] = enginekick_mcp_ref_line( 'Removed', 'inline image', $removed_i, false );
	}
	$bw = (int) ( ( isset( $b['words'] ) ? $b['words'] : 0 ) );
	$aw = (int) ( ( isset( $a['words'] ) ? $a['words'] : 0 ) );
	if ( abs( $aw - $bw ) >= 20 ) {
		$out[] = 'Body ' . ( $aw > $bw ? '+' : '' ) . ( $aw - $bw ) . ' words (' . $bw . ' -> ' . $aw . ')';
	} elseif ( ! $out && ( ( ( isset( $b['hash'] ) ? $b['hash'] : '' ) ) !== ( ( isset( $a['hash'] ) ? $a['hash'] : '' ) ) ) ) {
		$out[] = 'Content edited (wording changed)';
	}
	return $out;
}
// Format an added/removed link/image set into one line: "Added 2 internal links: -> /pricing
// \"See pricing\", -> /features". $is_link toggles the -> target vs bare filename rendering.
function enginekick_mcp_ref_line( $verb, $noun, $items, $is_link ) {
	$n     = count( $items );
	$parts = array();
	$i     = 0;
	foreach ( $items as $key => $label ) {
		if ( $i >= 6 ) {
			$parts[] = '+' . ( $n - 6 ) . ' more';
			break;
		}
		if ( $is_link ) {
			$parts[] = '-> ' . $key . ( '' !== $label ? ' "' . $label . '"' : '' );
		} else {
			$fn      = basename( $key );
			$parts[] = $fn . ( '' !== $label ? ' (alt: "' . $label . '")' : ' (no alt)' );
		}
		$i++;
	}
	return $verb . ' ' . $n . ' ' . $noun . ( $n > 1 ? 's' : '' ) . ': ' . implode( ', ', $parts );
}
/**
 * What is missing from the plugin's database schema, checked against the real tables (V6 #5): one SHOW
 * TABLES for all four tables plus one SHOW COLUMNS for the audit table. Memoised per request so both
 * modules' admin checks, the audit writer, the exports and the settings page share one lookup; pass
 * $fresh after an install. Returns e.g. array( 'table:enginekick_rate', 'column:outcome' ); empty = complete.
 */
function enginekick_schema_missing( $fresh = false ) {
	static $missing = null;
	if ( null !== $missing && ! $fresh ) {
		return $missing;
	}
	global $wpdb;
	$have    = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . 'enginekick%' ) );
	$missing = array();
	foreach ( array( 'enginekick_crawl', 'enginekick_changes', 'enginekick_mcp_audit', 'enginekick_rate' ) as $t ) {
		if ( ! in_array( $wpdb->prefix . $t, $have, true ) ) {
			$missing[] = 'table:' . $t;
		}
	}
	if ( ! in_array( 'table:enginekick_mcp_audit', $missing, true ) ) {
		$cols = (array) $wpdb->get_col( 'SHOW COLUMNS FROM ' . enginekick_mcp_audit_table() );
		foreach ( array( 'request_id', 'before_hash', 'after_hash', 'changes', 'outcome' ) as $c ) {
			if ( ! in_array( $c, $cols, true ) ) {
				$missing[] = 'column:' . $c;
			}
		}
	}
	if ( ! in_array( 'table:enginekick_changes', $missing, true ) ) {
		$cols = (array) $wpdb->get_col( 'SHOW COLUMNS FROM ' . $wpdb->prefix . 'enginekick_changes' );
		if ( ! in_array( 'request_id', $cols, true ) ) {
			$missing[] = 'column:changes.request_id';   // added in DB version 5 (V7 #4)
		}
	}
	// The export's request_id lookup needs its index (R8 F7). Checked when an installer verifies its work,
	// not on every request: the version is only recorded once this passes, and a stale version retries.
	if ( $fresh && ! in_array( 'table:enginekick_mcp_audit', $missing, true ) ) {
		$idx = (array) $wpdb->get_results( 'SHOW INDEX FROM ' . enginekick_mcp_audit_table(), ARRAY_A );
		if ( ! in_array( 'request_id', array_map( 'strtolower', array_column( $idx, 'Column_name' ) ), true ) ) {
			$missing[] = 'index:audit.request_id';
		}
	}
	return $missing;
}
// The parts of the schema this module owns (the connector owns crawl + changes).
/** Schema items the CONNECTOR creates and repairs (crawl + changes). Everything else belongs to the MCP module. */
function enginekick_connector_schema_items() {
	return array( 'table:enginekick_crawl', 'table:enginekick_changes', 'column:changes.request_id' );
}
function enginekick_connector_schema_missing( $fresh = false ) {
	return array_values( array_intersect( enginekick_schema_missing( $fresh ), enginekick_connector_schema_items() ) );
}
// The MCP installer only reports what it can fix (R8 F3: it used to claim the connector's request_id column,
// re-ran on every admin page, and could never repair it).
function enginekick_mcp_schema_missing( $fresh = false ) {
	return array_values( array_diff( enginekick_schema_missing( $fresh ), enginekick_connector_schema_items() ) );
}

/**
 * Record one MCP write. Returns false when no record could be written, and says so in the tool result
 * (V6 #4: a missing table or a failed insert used to be silent, so a successful write could have no audit
 * row). Outcome is 'partial' when part of the request was not applied.
 */
function enginekick_mcp_audit( $tool, $object_type, $object_id, $before = null, $after = null, $ok = true ) {
	global $wpdb;
	$table = enginekick_mcp_audit_table();
	if ( in_array( 'table:enginekick_mcp_audit', enginekick_schema_missing(), true ) ) {
		if ( $ok ) {
			enginekick_mcp_note( 'The change was made, but its audit record could not be written (the audit table is missing; an administrator page load recreates it).' );
		}
		return false;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) $_SERVER['HTTP_USER_AGENT'], 0, 300 ) : '';
	// The "little details": diff the before/after fingerprints into human-readable change lines
	// (internal links added, featured/inline image set, title/status/alt changed, word delta). Only
	// for successful writes with a real after-state; rejections/errors carry no diff.
	$changes = ( $ok && is_array( $after ) ) ? enginekick_mcp_describe_changes( $tool, $object_type, $before, $after ) : array();
	$partial = $ok && enginekick_mcp_notes_partial();
	if ( $partial ) {
		foreach ( enginekick_mcp_note() as $n ) {
			if ( $n['partial'] ) {
				$changes[] = 'Not applied: ' . $n['message'];
			}
		}
	}
	$inserted = $wpdb->insert(
		$table,
		array(
			'ts'            => gmdate( 'Y-m-d H:i:s' ),
			'tool'          => substr( (string) $tool, 0, 60 ),
			'object_type'   => substr( (string) $object_type, 0, 20 ),
			'object_id'     => (int) $object_id,
			'remote_ip'     => substr( enginekick_client_ip(), 0, 45 ),
			'user_agent'    => $ua,
			'request_id'    => enginekick_mcp_request_id(),
			'before_hash'   => isset( $before['hash'] ) ? (string) $before['hash'] : '',
			'after_hash'    => isset( $after['hash'] ) ? (string) $after['hash'] : '',
			'before_status' => isset( $before['status'] ) ? (string) $before['status'] : '',
			'after_status'  => isset( $after['status'] ) ? (string) $after['status'] : '',
			'changes'       => $changes ? wp_json_encode( array_values( $changes ) ) : '',
			'outcome'       => $ok ? ( $partial ? 'partial' : 'ok' ) : 'failed',
		),
		array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
	);
	if ( false === $inserted && $ok ) {
		enginekick_mcp_note( 'The change was made, but its audit record could not be written (database error).' );
	}
	// Bounded retention (review V4 #6): occasionally trim old audit rows in a small indexed batch so a
	// valid-token caller generating many (success/failed) writes can't grow the table without bound.
	if ( wp_rand( 1, 100 ) === 1 ) {
		$days = max( 30, (int) get_option( 'enginekick_mcp_audit_retention_days', 365 ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . $table . ' WHERE ts < %s ORDER BY id ASC LIMIT 500', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
	return false !== $inserted;
}
function enginekick_mcp_install_audit() {
	global $wpdb;
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	$table = enginekick_mcp_audit_table();
	$cc    = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE $table (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			ts DATETIME NOT NULL,
			tool VARCHAR(60) NOT NULL,
			object_type VARCHAR(20) NOT NULL DEFAULT '',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			remote_ip VARCHAR(45) NOT NULL DEFAULT '',
			user_agent VARCHAR(300) NOT NULL DEFAULT '',
			request_id VARCHAR(64) NOT NULL DEFAULT '',
			before_hash VARCHAR(64) NOT NULL DEFAULT '',
			after_hash VARCHAR(64) NOT NULL DEFAULT '',
			before_status VARCHAR(20) NOT NULL DEFAULT '',
			after_status VARCHAR(20) NOT NULL DEFAULT '',
			changes MEDIUMTEXT NULL,
			outcome VARCHAR(8) NOT NULL DEFAULT 'ok',
			PRIMARY KEY (id),
			KEY ts (ts),
			KEY request_id (request_id)
		) $cc;"
	);
	// Atomic rate/flood counter (V5-ext #9). Two spaces after PRIMARY KEY: dbDelta requires them to
	// recognise an existing primary key on re-runs.
	$rate = enginekick_rate_table();
	dbDelta(
		"CREATE TABLE $rate (
			bkey CHAR(32) NOT NULL,
			win BIGINT NOT NULL DEFAULT 0,
			exp BIGINT NOT NULL DEFAULT 0,
			n INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (bkey),
			KEY exp (exp)
		) $cc;"
	);
	// Record the schema version ONLY after the real tables and columns are verified (V6 #5). Saving it
	// unconditionally meant a failed CREATE/ALTER was marked complete and never retried.
	$left = enginekick_mcp_schema_missing( true );
	if ( $left ) {
		error_log( 'EngineKick: schema install incomplete, will retry on the next admin page load: ' . implode( ', ', $left ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		return false;
	}
	update_option( 'enginekick_mcp_audit_ver', '5' );   // 5: request_id index (R8 F7)
	return true;
}
add_action( 'admin_init', function () {
	// Only in admin (dbDelta pulls admin includes; never on the front end). Runs when the schema version
	// is stale OR any table/column this module needs is actually missing (V6 #5: checking the version and
	// one table meant a dropped rate table was never recreated).
	if ( get_option( 'enginekick_mcp_audit_ver' ) !== '5' || enginekick_mcp_schema_missing() ) {
		enginekick_mcp_install_audit();
	}
	// SERVICE-ACCOUNT SELF-HEAL (fixes 'rejected:no_service'): provision and repair the account HERE,
	// where an admin page load runs as a real administrator and a WAF/security plugin does not block
	// account changes — unlike Claude's bot-context REST request, the original failure. Runs until the
	// account is healthy (svc_ok), AND again whenever the account still holds the stock Editor role:
	// sites healed before 1.6 already have svc_ok set, so without that second condition the move off
	// Editor (which carries unfiltered_html, V5-ext #1) would be left to a bot-context MCP request,
	// where a blocked role change would stop all writes.
	if ( ! current_user_can( 'create_users' ) ) {
		return;
	}
	$svc_user        = get_user_by( 'login', enginekick_mcp_service_login() );
	$needs_migration = $svc_user && in_array( 'editor', (array) $svc_user->roles, true );
	if ( '1' !== get_option( 'enginekick_mcp_svc_ok', '' ) || $needs_migration || enginekick_mcp_service_role_drifted() ) {
		$r = enginekick_mcp_ensure_service_account( true );
		if ( isset( $r['id'] ) && $r['id'] > 0 ) {
			update_option( 'enginekick_mcp_svc_ok', '1' );
		}
	}
} );

/* ------------------------------------------------------------------------- *
 * REST route (the MCP endpoint)
 * ------------------------------------------------------------------------- */

/**
 * permission_callback for the MCP endpoint: token, IP allowlist, operating mode and rate limit. WordPress
 * expects the access decision here rather than '__return_true' plus a check inside the handler, so a refused
 * request never reaches the tool dispatcher.
 */
/**
 * Repair an allowlist that allows PART of Claude's range (the old button's 160.79.106.0/24, or single Claude
 * addresses typed in by hand) by adding Anthropic's full published range. The owner's intent was evidently
 * "let Claude in"; the partial entry is what made Claude show "Reconnect". An allowlist with no Claude address
 * is never touched. Runs inside the allowlist check, so the first call after the update is already let in —
 * nobody has to open wp-admin on each site. Returns the (possibly updated) raw allowlist.
 */
function enginekick_mcp_upgrade_claude_range( $raw ) {
	$entries = array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', (string) $raw ) ) ) );
	if ( ! $entries || in_array( ENGINEKICK_MCP_CLAUDE_IPS, $entries, true ) ) {
		return $raw;
	}
	$claude_hint = false;
	foreach ( $entries as $e ) {
		$net = strpos( $e, '/' ) ? substr( $e, 0, strpos( $e, '/' ) ) : $e;
		if ( filter_var( $net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) && enginekick_ip_in_cidr( $net, ENGINEKICK_MCP_CLAUDE_IPS ) ) {
			$claude_hint = true;
			break;
		}
	}
	if ( ! $claude_hint || enginekick_mcp_list_covers_claude( $entries ) ) {
		return $raw;
	}
	$entries[] = ENGINEKICK_MCP_CLAUDE_IPS;
	$new       = implode( "\n", array_unique( $entries ) );
	update_option( 'enginekick_allowed_ips', $new );
	update_option( 'enginekick_mcp_claude_range_upgraded', array( 'time' => time(), 'before' => (string) $raw ), false );
	return $new;
}
/** True when one allowlist entry contains Anthropic's whole published range (an exact containment test). */
function enginekick_mcp_list_covers_claude( array $entries ) {
	list( $net, $bits ) = explode( '/', ENGINEKICK_MCP_CLAUDE_IPS );
	foreach ( $entries as $e ) {
		if ( ! strpos( $e, '/' ) ) {
			continue;
		}
		$prefix = (int) substr( $e, strpos( $e, '/' ) + 1 );
		if ( $prefix <= (int) $bits && enginekick_ip_in_cidr( $net, $e ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Remember why recent calls were turned away, so "Reconnect" in Claude can be diagnosed on the site in seconds
 * instead of guessed at. At most 20 entries; a repeat of the same reason from the same address within a minute
 * is not written again, so a flood costs no database writes.
 */
/**
 * Connection health, bounded: the time of the last successful handshake and, per day for seven days, how
 * many connections succeeded and how many were refused. One small option; written on handshakes (rare) and
 * refusals (already de-duplicated), never on tool calls.
 */
function enginekick_mcp_health_tick( $kind ) {
	$h = get_option( 'enginekick_mcp_health', array() );
	$h = is_array( $h ) ? $h : array();
	$d = gmdate( 'Y-m-d' );
	if ( ! isset( $h['days'] ) || ! is_array( $h['days'] ) ) {
		$h['days'] = array();
	}
	if ( ! isset( $h['days'][ $d ] ) ) {
		$h['days'][ $d ] = array( 'ok' => 0, 'refused' => 0 );
		krsort( $h['days'] );
		$h['days'] = array_slice( $h['days'], 0, 7, true );
	}
	$h['days'][ $d ][ 'ok' === $kind ? 'ok' : 'refused' ]++;
	if ( 'ok' === $kind ) {
		$h['last_ok'] = time();
	}
	update_option( 'enginekick_mcp_health', $h, false );
}
function enginekick_mcp_log_refusal( $reason ) {
	enginekick_mcp_health_tick( 'refused' );
	$ip  = enginekick_client_ip();
	$log = get_option( 'enginekick_mcp_refusals', array() );
	$log = is_array( $log ) ? $log : array();
	foreach ( $log as $e ) {
		if ( isset( $e['reason'], $e['ip'], $e['t'] ) && $e['reason'] === $reason && $e['ip'] === $ip && time() - (int) $e['t'] < 60 ) {
			return;
		}
	}
	array_unshift( $log, array( 't' => time(), 'reason' => (string) $reason, 'ip' => (string) $ip ) );
	update_option( 'enginekick_mcp_refusals', array_slice( $log, 0, 20 ), false );
}
function enginekick_mcp_refusal_text( $reason ) {
	$t = array(
		'forbidden'    => 'Wrong connector URL: the secret in the URL does not match this site. Claude is using an old URL (usually after the plugin was deleted and reinstalled). Copy the current URL from this page into Claude.',
		'forbidden_ip' => 'The caller\'s address is not on this site\'s IP allowlist.',
		'mcp_disabled' => 'The EngineKick MCP is turned off on this site (Security &amp; access mode).',
		'rate_limited' => 'Too many requests in one minute; Claude retries on its own.',
	);
	return isset( $t[ $reason ] ) ? $t[ $reason ] : esc_html( (string) $reason );
}

function enginekick_mcp_permission( $request ) {
	if ( ! hash_equals( enginekick_mcp_get_token(), (string) $request['token'] ) ) {
		enginekick_mcp_log_refusal( 'forbidden' );
		return new WP_Error( 'forbidden', 'Not a valid EngineKick connector URL.', array( 'status' => 403 ) );
	}
	// A leaked URL is useless off the trusted network (empty allowlist = allow all).
	if ( ! enginekick_ip_allowed() ) {
		enginekick_mcp_log_refusal( 'forbidden_ip' );
		return new WP_Error( 'forbidden_ip', 'This IP address is not allowed to reach the EngineKick endpoints.', array( 'status' => 403 ) );
	}
	if ( 'off' === enginekick_mcp_mode() ) {
		enginekick_mcp_log_refusal( 'mcp_disabled' );
		return new WP_Error( 'mcp_disabled', 'The EngineKick MCP is turned off by the site owner.', array( 'status' => 403 ) );
	}
	// A high ceiling for the connection itself (initialize, tools/list, ping are a few cheap reads). The
	// real per-call limit is charged inside tools/call. Until 1.16 one limit covered both, so a burst of
	// edits could make the NEXT handshake fail — which Claude shows as "Reconnect".
	if ( ! enginekick_rate_ok( 'mcp_any', 600, 60 ) ) {
		enginekick_mcp_log_refusal( 'rate_limited' );
		return new WP_Error( 'rate_limited', 'Too many requests; try again shortly.', array( 'status' => 429 ) );
	}
	enginekick_mcp_is_active_request( true );
	return true;
}

add_action( 'rest_api_init', function () {
	register_rest_route(
		'enginekick-mcp/v1',
		'/(?P<token>[A-Za-z0-9]+)',
		array(
			'methods'             => array( 'GET', 'POST', 'DELETE' ),
			'callback'            => 'enginekick_mcp_handle',
			'permission_callback' => 'enginekick_mcp_permission',
		)
	);
} );

function enginekick_mcp_handle( WP_REST_Request $request ) {
	// Token, IP allowlist, mode and rate limit were all enforced by enginekick_mcp_permission().

	// Reject an oversized request body BEFORE decoding (review v2 #4 — DoS via a huge batch
	//     that costs one rate-limit unit but many DB ops).
	$raw = (string) $request->get_body();
	if ( strlen( $raw ) > ENGINEKICK_MCP_MAX_BODY_BYTES ) {
		return new WP_REST_Response( array( 'error' => 'payload_too_large' ), 413 );
	}

	// The service identity is resolved when a TOOL runs (enginekick_mcp_assume_service_identity), not here:
	// initialize / tools/list / ping must never depend on a user lookup, the service account's health or
	// anything but the token. A handshake that fails for a reason unrelated to the handshake is exactly what
	// made Claude show "Reconnect" (1.16).

	// No server-initiated SSE stream is offered, and sessions cannot be terminated: both answer 405, which is
	// what the Streamable HTTP transport specifies for an unsupported GET / DELETE.
	if ( 'POST' !== $request->get_method() ) {
		$r = new WP_REST_Response( null, 405 );
		$r->header( 'Allow', 'POST' );
		return $r;
	}

	// JSON-RPC 2.0 + MCP Streamable HTTP (R8 F9): malformed JSON is a Parse error; valid JSON that is not a
	// request is an Invalid Request; both answer 400, as the transport requires for input it cannot accept.
	$body = json_decode( $raw, true );
	if ( JSON_ERROR_NONE !== json_last_error() ) {
		return new WP_REST_Response( enginekick_mcp_rpc_error( null, -32700, 'Parse error: the request body is not valid JSON.' ), 400 );
	}
	if ( ! is_array( $body ) || array() === $body ) {
		return new WP_REST_Response( enginekick_mcp_rpc_error( null, -32600, 'Invalid Request: expected a JSON-RPC request object.' ), 400 );
	}

	// Batch (allowed by protocol versions before 2025-06-18): cap the count, charge EACH message against the
	// rate limit, validate each member on its own, and cap the combined output.
	if ( enginekick_mcp_is_list( $body ) ) {
		if ( count( $body ) > ENGINEKICK_MCP_MAX_BATCH ) {
			return new WP_REST_Response( enginekick_mcp_rpc_error( null, -32600, 'Batch too large (max ' . ENGINEKICK_MCP_MAX_BATCH . ').' ), 400 );
		}
		$responses = array();
		$bytes     = 0;
		foreach ( $body as $msg ) {
			// Once the batch's output passes the ceiling, remaining tool calls are not run (R8 F10).
			if ( $bytes > ENGINEKICK_MCP_MAX_RESPONSE_BYTES && is_array( $msg ) && isset( $msg['method'], $msg['id'] ) && 'tools/call' === $msg['method'] ) {
				$responses[] = enginekick_mcp_tool_error( $msg['id'], 'Not run: this batch\'s response is already over ' . (int) ( ENGINEKICK_MCP_MAX_RESPONSE_BYTES / 1048576 ) . ' MB. Send fewer requests per batch.' );
				continue;
			}
			$r = enginekick_mcp_handle_message( $msg );
			if ( null !== $r ) {
				$responses[] = $r;
				$bytes      += strlen( (string) wp_json_encode( $r ) );
			}
		}
		return empty( $responses )
			? new WP_REST_Response( null, 202 )
			: new WP_REST_Response( $responses, 200 );
	}

	$resp = enginekick_mcp_handle_message( $body );
	if ( null === $resp ) {
		return new WP_REST_Response( null, 202 ); // a notification: accepted, never answered
	}
	$invalid = isset( $resp['error']['code'] ) && in_array( $resp['error']['code'], array( -32600, -32700 ), true );
	return new WP_REST_Response( $resp, $invalid ? 400 : 200 );
}

/**
 * WordPress rejects a request body that is not valid JSON before any route code runs ('rest_invalid_json').
 * On the MCP endpoint that must still answer as JSON-RPC: a Parse error (R8 F9). Priority 1, so the
 * connector's no-store headers (added later on rest_post_dispatch) still apply to the replacement.
 */
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	if ( ! ( $response instanceof WP_REST_Response ) || 0 !== strpos( (string) $request->get_route(), '/enginekick-mcp/v1/' ) ) {
		return $response;
	}
	$data = $response->get_data();
	if ( is_array( $data ) && isset( $data['code'] ) && 'rest_invalid_json' === $data['code'] ) {
		return new WP_REST_Response( enginekick_mcp_rpc_error( null, -32700, 'Parse error: the request body is not valid JSON.' ), 400 );
	}
	return $response;
}, 1, 3 );

/** A JSON array (list), as opposed to a JSON object. */
function enginekick_mcp_is_list( array $a ) {
	return array() === $a || array_keys( $a ) === range( 0, count( $a ) - 1 );
}
/**
 * Validate one JSON-RPC message, then dispatch it. Returns the response, or null for a notification.
 * A message without an id is a notification and is never answered (JSON-RPC 2.0 §4.1). Only MCP's own
 * notifications mean anything here; a tools/call without an id is not executed, since its result (or its
 * failure) could never be reported.
 */
function enginekick_mcp_handle_message( $msg ) {
	if ( ! is_array( $msg ) || enginekick_mcp_is_list( $msg ) ) {
		return enginekick_mcp_rpc_error( null, -32600, 'Invalid Request: expected a JSON-RPC request object.' );
	}
	$has_id = array_key_exists( 'id', $msg );
	$id     = $has_id ? $msg['id'] : null;
	if ( $has_id && ! is_string( $id ) && ! is_int( $id ) ) {
		return enginekick_mcp_rpc_error( null, -32600, 'Invalid Request: id must be a string or an integer.' );
	}
	if ( ! isset( $msg['jsonrpc'] ) || '2.0' !== $msg['jsonrpc'] ) {
		return enginekick_mcp_rpc_error( $id, -32600, 'Invalid Request: jsonrpc must be "2.0".' );
	}
	if ( ! isset( $msg['method'] ) || ! is_string( $msg['method'] ) || '' === $msg['method'] ) {
		return enginekick_mcp_rpc_error( $id, -32600, 'Invalid Request: method must be a non-empty string.' );
	}
	if ( isset( $msg['params'] ) && ! is_array( $msg['params'] ) ) {
		return enginekick_mcp_rpc_error( $id, -32600, 'Invalid Request: params must be an object.' );
	}
	if ( ! $has_id ) {
		return null;
	}
	return enginekick_mcp_dispatch( $msg );
}

/* ------------------------------------------------------------------------- *
 * JSON-RPC dispatch
 * ------------------------------------------------------------------------- */

/**
 * What both catch arms of the dispatcher do: never leak raw exception text to a remote caller
 * (review v3 #5) — log it server-side, record the failed attempt, and return a stable message.
 */
function enginekick_mcp_tool_exception( $e, $id, $name, array $args, $is_write ) {
	error_log( 'EngineKick MCP tool "' . $name . '" exception: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	if ( $is_write ) {
		enginekick_mcp_audit( $name, 'exception', (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) ) ), null, null, false );
	}
	return enginekick_mcp_tool_error( $id, 'The tool failed unexpectedly. The site owner can check the server error log for details.' );
}
function enginekick_mcp_dispatch( array $msg ) {
	$id     = ( isset( $msg['id'] ) ? $msg['id'] : null );
	$method = ( isset( $msg['method'] ) ? $msg['method'] : '' );
	$params = ( isset( $msg['params'] ) && is_array( $msg['params'] ) ) ? $msg['params'] : array();

	switch ( $method ) {
		case 'initialize':
			enginekick_mcp_health_tick( 'ok' );   // a successful connection, visible on the admin page
			// Negotiate (R8 F9): echo the client's version only if this server supports it; otherwise offer the
			// newest one it does. Echoing any string claimed compatibility with versions never checked.
			$supported    = array( '2025-06-18', '2025-03-26', '2024-11-05' );
			$asked        = ( isset( $params['protocolVersion'] ) && is_string( $params['protocolVersion'] ) ) ? $params['protocolVersion'] : '';
			$client_proto = in_array( $asked, $supported, true ) ? $asked : ENGINEKICK_MCP_PROTOCOL;
			return enginekick_mcp_result(
				$id,
				array(
					'protocolVersion' => $client_proto,
					'capabilities'    => array( 'tools' => (object) array() ),
					'serverInfo'      => array(
						'name'    => 'EngineKick MCP',
						'version' => ENGINEKICK_MCP_VERSION,
					),
					'instructions'    => enginekick_mcp_instructions(),
				)
			);

		case 'notifications/initialized':
		case 'notifications/cancelled':
			return null; // notifications get no response body

		case 'ping':
			return enginekick_mcp_result( $id, (object) array() );

		case 'tools/list':
			// Advertise only the tools the current mode permits, so the client never tries a
			// blocked write in read-only.
			$tools = enginekick_mcp_tools();
			if ( 'read_only' === enginekick_mcp_mode() ) {
				$reads = enginekick_mcp_read_tools();
				$tools = array_values( array_filter( $tools, function ( $t ) use ( $reads ) {
					return in_array( $t['name'], $reads, true );
				} ) );
			}
			return enginekick_mcp_result( $id, array( 'tools' => $tools ) );

		case 'tools/call':
			enginekick_mcp_request_id( true );   // a fresh id for each tool call (R8 F8)
			return enginekick_mcp_call_tool( $id, $params );

		case 'resources/list':
			return enginekick_mcp_result( $id, array( 'resources' => array() ) );

		case 'resources/templates/list':
			return enginekick_mcp_result( $id, array( 'resourceTemplates' => array() ) );

		case 'prompts/list':
			return enginekick_mcp_result( $id, array( 'prompts' => array() ) );

		default:
			if ( null === $id ) {
				return null;
			}
			return enginekick_mcp_rpc_error( $id, -32601, 'Method not found: ' . $method );
	}
}

function enginekick_mcp_result( $id, $result ) {
	return array(
		'jsonrpc' => '2.0',
		'id'      => $id,
		'result'  => $result,
	);
}

function enginekick_mcp_rpc_error( $id, $code, $message ) {
	return array(
		'jsonrpc' => '2.0',
		'id'      => $id,
		'error'   => array(
			'code'    => $code,
			'message' => $message,
		),
	);
}

/* ------------------------------------------------------------------------- *
 * Anti-hallucination guardrails (steer the MCP client)
 * ------------------------------------------------------------------------- */

/**
 * Operating manual returned in the initialize handshake. Clients (Claude) read
 * this BEFORE calling any tool, so it is the best place to stop the model from
 * (a) inventing tool names and (b) telling the user to "connect/authenticate"
 * when it already has full write access through this endpoint.
 */
function enginekick_mcp_instructions() {
	return implode(
		"\n",
		array(
			'This server gives you full READ and WRITE access to this WordPress site. You are ALREADY connected and authenticated by the secret in the URL — never tell the user to connect, log in, authorize, or install anything.',
			'',
			'Canonical workflows:',
			'- Find posts: list_posts (paginate with page/per_page), or get_post for one by id.',
			'- EDIT a post: call get_post first, then update_post (replaces the whole body) OR replace_in_post (surgical insert/replace around an exact snippet). Both need only the post_id.',
			'- CREATE a post: create_post (defaults to draft; set status to publish to publish).',
			'- Links/images: add_internal_links, list_media, upload_media_from_url, set_featured_image, add_image_to_post, update_media (alt text).',
			'',
			'Hard rules:',
			'- Use ONLY the tools returned by tools/list. Do NOT invent tool names — there is no edit_post, delete_post, publish_post, or generic wp_* tool. Use update_post (and set status=publish to publish).',
			'- Deleting/trashing is intentionally unavailable. Do not attempt it.',
			'- If a write fails because the server rejects HTML in the request body, retry the SAME tool using the base64 transport fields (content_b64, title_b64, find_b64, new_content_b64). The decoded content is sanitised identically to plain content (scripts/event-handlers/unsafe URLs are stripped), so this is a transport fallback, not a way to bypass validation.',
		)
	);
}

/**
 * One stable error for an unknown tool name. It lists the valid tools and keeps the anti-hallucination
 * instruction. The earlier
 * Levenshtein "did you mean" suggestion was dropped (external V5 review, ponytail): tools/list already
 * gives the client discovery, and a fuzzy guess invites the model to call the wrong tool.
 */
function enginekick_mcp_unknown_tool_msg( $name ) {
	// Only reachable in draft_write/publish: in read_only mode an unknown name is classified as a write
	// tool and refused at dispatch before this runs, so every tool is valid to list here.
	$names = array_column( enginekick_mcp_tools(), 'name' );
	return "Unknown tool '" . mb_substr( (string) $name, 0, 60 ) . "'. Use only these tools: " . implode( ', ', $names )
		. '. Call tools/list for their schemas. You are already connected — do not ask the user to connect or authenticate.';
}

/* ------------------------------------------------------------------------- *
 * Tool registry (advertised via tools/list)
 * ------------------------------------------------------------------------- */

function enginekick_mcp_tools() {
	return array(
		array(
			'name'        => 'get_site_info',
			'description' => 'Return basic info about this WordPress site: name, description, URL, and post counts. Useful for building correct internal-link URLs.',
			'inputSchema' => array( 'type' => 'object', 'properties' => (object) array() ),
		),
		array(
			'name'        => 'update_seo',
			'description' => 'Set a post\'s SEO fields in the site\'s SEO plugin (Rank Math, Yoast SEO, All in One SEO or SEOPress — get_site_info says which). Only the fields you pass change; pass "" to reset a text field to the plugin\'s own default. get_post shows the current values. The change is checked by reading it back.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'          => array( 'type' => 'integer' ),
					'seo_title'        => array( 'type' => 'string', 'description' => 'The title shown in search results and the browser tab. Plain text; the plugin\'s variables (e.g. %sitename%) are kept.' ),
					'meta_description' => array( 'type' => 'string', 'description' => 'The snippet shown under the title in search results. Plain text.' ),
					'focus_keyword'    => array( 'type' => 'string', 'description' => 'The keyword the plugin\'s content analysis scores against.' ),
					'canonical_url'    => array( 'type' => 'string', 'description' => 'Canonical URL. Must be a page on this same site.' ),
					'noindex'          => array( 'type' => 'boolean', 'description' => 'true: ask search engines not to index this page. false: allow indexing.' ),
					'nofollow'         => array( 'type' => 'boolean', 'description' => 'true: ask search engines not to follow links on this page. false: allow.' ),
				),
				'required'   => array( 'post_id' ),
			),
		),
		array(
			'name'        => 'list_authors',
			'description' => 'List the people the site owner allows posts to be credited to, and which one is the default. Pass one of them as author (id, name or slug) to create_post or update_post. Posts are never credited to the EngineKick Service account when a default is set.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_type' => array( 'type' => 'string', 'description' => "Only people who can write this post type. Default 'post'." ),
				),
			),
		),
		array(
			'name'        => 'list_posts',
			'description' => 'List posts (or pages) with pagination so you can walk through every post. Supports keyword search and status/type filters. Returns id, title, status, type, link, dates, and a short excerpt for each, plus total counts.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_type' => array( 'type' => 'string', 'description' => "Post type, e.g. 'post' or 'page'. Default 'post'." ),
					'status'    => array( 'type' => 'string', 'description' => "Comma-separated statuses (publish,draft,pending,private,future). Default: all of these." ),
					'search'    => array( 'type' => 'string', 'description' => 'Optional keyword to search titles/content.' ),
					'page'      => array( 'type' => 'integer', 'description' => 'Page number, starting at 1.' ),
					'per_page'  => array( 'type' => 'integer', 'description' => 'Results per page, 1-100. Default 20.' ),
					'orderby'   => array( 'type' => 'string', 'description' => "modified | date | title. Default modified." ),
					'order'     => array( 'type' => 'string', 'description' => 'ASC | DESC. Default DESC.' ),
				),
			),
		),
		array(
			'name'        => 'get_post',
			'description' => 'Get the full raw content of a single post by ID, including the block markup, categories, tags, and metadata. Use this before editing so you edit the real current content.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id' => array( 'type' => 'integer', 'description' => 'The post ID.' ),
				),
				'required'   => array( 'post_id' ),
			),
		),
		array(
			'name'        => 'create_post',
			'description' => 'Create a new post or page. Defaults to draft status for safety. Returns the new post ID and links. If a firewall (WAF) blocks HTML in request bodies, send the body via content_b64 (base64) instead of content.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'title'       => array( 'type' => 'string' ),
					'title_b64'   => array( 'type' => 'string', 'description' => 'Base64 of title (alternative to title).' ),
					'content'     => array( 'type' => 'string', 'description' => 'Post body. May contain HTML / Gutenberg block markup.' ),
					'content_b64' => array( 'type' => 'string', 'description' => 'Base64-encoded post body. Use this INSTEAD of content whenever the body contains HTML/block markup, a transport fallback for servers that reject HTML in request bodies. Decoded AND sanitised server-side with the same validation as plain content.' ),
					'status'      => array( 'type' => 'string', 'description' => 'draft | pending | publish | private. Default draft.' ),
					'post_type'   => array( 'type' => 'string', 'description' => "Default 'post'." ),
					'slug'        => array( 'type' => 'string', 'description' => 'URL slug, e.g. french-bulldog-sleep. Optional; WordPress derives one from the title if omitted.' ),
					'author'      => array( 'type' => 'string', 'description' => 'Who the post is credited to: a user id, display name or slug from list_authors. Optional; defaults to the site\'s chosen default author.' ),
					'excerpt'     => array( 'type' => 'string' ),
					'excerpt_b64' => array( 'type' => 'string', 'description' => 'Base64 of excerpt (alternative to excerpt).' ),
					'categories'  => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'description' => 'Category names; created if missing.' ),
					'tags'        => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'description' => 'Tag names.' ),
				),
				'required'   => array( 'title' ),
			),
		),
		array(
			'name'        => 'update_post',
			'description' => 'Edit an existing post. Only the fields you pass are changed. Deleting/trashing is blocked: status cannot be set to trash. Returns the updated post. Pass slug to change the post\'s URL: on a published post the old URL then 301-redirects to the new one automatically (query strings kept), so no .htaccess or redirect-plugin entry is needed; the result\'s url_change shows both addresses. If a firewall (WAF) blocks HTML in request bodies, send the body via content_b64 (base64) instead of content.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'     => array( 'type' => 'integer' ),
					'title'       => array( 'type' => 'string' ),
					'title_b64'   => array( 'type' => 'string', 'description' => 'Base64 of title (alternative to title).' ),
					'content'     => array( 'type' => 'string', 'description' => 'Full replacement body. Fetch the post first if you only want to change part of it.' ),
					'content_b64' => array( 'type' => 'string', 'description' => 'Base64-encoded replacement body. Use this INSTEAD of content whenever it contains HTML/block markup, a transport fallback for servers that reject HTML in request bodies. Decoded AND sanitised server-side with the same validation as plain content.' ),
					'excerpt'     => array( 'type' => 'string' ),
					'excerpt_b64' => array( 'type' => 'string', 'description' => 'Base64 of excerpt (alternative to excerpt).' ),
					'status'      => array( 'type' => 'string', 'description' => 'draft | pending | publish | private (trash is not allowed).' ),
					'slug'        => array( 'type' => 'string', 'description' => 'New URL slug: the last part of the address, e.g. french-bulldog-sleep. One segment, no slashes. If another post already uses it, WordPress adds a suffix (-2) and the result warns you.' ),
					'author'      => array( 'type' => 'string', 'description' => 'Re-credit the post: a user id, display name or slug from list_authors.' ),
					'categories'  => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
					'tags'        => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				),
				'required'   => array( 'post_id' ),
			),
		),
		array(
			'name'        => 'add_internal_links',
			'description' => 'Insert internal links into an existing post by wrapping matching anchor text in <a> tags. Each link is matched in body text only (not inside existing tags or links). Provide target_post_id (preferred) or target_url.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'         => array( 'type' => 'integer' ),
					'max_occurrences' => array( 'type' => 'integer', 'description' => 'Max times to link each anchor phrase. Default 1.' ),
					'links'           => array(
						'type'        => 'array',
						'description' => 'Links to insert.',
						'items'       => array(
							'type'       => 'object',
							'properties' => array(
								'anchor_text'    => array( 'type' => 'string', 'description' => 'Exact visible text to turn into a link.' ),
								'target_post_id' => array( 'type' => 'integer', 'description' => 'Destination post ID (its permalink is used).' ),
								'target_url'     => array( 'type' => 'string', 'description' => 'Destination URL (used if no target_post_id).' ),
							),
							'required'   => array( 'anchor_text' ),
						),
					),
				),
				'required'   => array( 'post_id', 'links' ),
			),
		),
		array(
			'name'        => 'list_terms',
			'description' => 'List taxonomy terms (categories or tags) with their IDs, slugs, post counts, and links. Helpful when deciding internal-link targets or organizing posts.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'taxonomy' => array( 'type' => 'string', 'description' => "category | post_tag | a custom taxonomy. Default category." ),
					'per_page' => array( 'type' => 'integer', 'description' => '1-200. Default 100.' ),
				),
			),
		),
		array(
			'name'        => 'list_media',
			'description' => 'List items in the Media Library (images by default) with pagination and optional keyword search. Returns id, title, alt text, MIME type, URL, dimensions, and which post each item is attached to.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'search'      => array( 'type' => 'string', 'description' => 'Optional keyword for titles/filenames/alt text.' ),
					'mime_type'   => array( 'type' => 'string', 'description' => "MIME filter, e.g. 'image', 'image/png'. Default 'image'." ),
					'attached_to' => array( 'type' => 'integer', 'description' => 'Only items attached to this post ID.' ),
					'page'        => array( 'type' => 'integer' ),
					'per_page'    => array( 'type' => 'integer', 'description' => '1-100. Default 20.' ),
				),
			),
		),
		array(
			'name'        => 'get_media',
			'description' => 'Get full details for one Media Library item by ID: URL, alt text, caption, description, MIME type, dimensions, and the available image sizes with their URLs.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'attachment_id' => array( 'type' => 'integer' ),
				),
				'required'   => array( 'attachment_id' ),
			),
		),
		array(
			'name'        => 'update_media',
			'description' => 'Edit metadata for a Media Library item: title, alt text, caption, and description. Does not delete or replace the file. Ideal for fixing missing alt text in bulk.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'attachment_id' => array( 'type' => 'integer' ),
					'title'         => array( 'type' => 'string' ),
					'alt_text'      => array( 'type' => 'string' ),
					'caption'       => array( 'type' => 'string' ),
					'description'   => array( 'type' => 'string' ),
				),
				'required'   => array( 'attachment_id' ),
			),
		),
		array(
			'name'        => 'upload_media_from_url',
			'description' => 'Download an image from a URL into the Media Library and optionally attach it to a post. Returns the new attachment ID and URL. Use this to add images you found or generated.',
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'url'            => array( 'type' => 'string', 'description' => 'Direct URL to the image file.' ),
					'title'          => array( 'type' => 'string' ),
					'alt_text'       => array( 'type' => 'string' ),
					'caption'        => array( 'type' => 'string' ),
					'attach_to_post' => array( 'type' => 'integer', 'description' => 'Optional post ID to attach the image to.' ),
				),
				'required'   => array( 'url' ),
			),
		),
		array(
			'name'        => 'set_featured_image',
			'description' => "Set a post's featured image. Provide an existing attachment_id, or an image_url to upload and use.",
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'       => array( 'type' => 'integer' ),
					'attachment_id' => array( 'type' => 'integer', 'description' => 'Existing Media Library item to use.' ),
					'image_url'     => array( 'type' => 'string', 'description' => 'Or a URL to upload and then set as featured.' ),
					'alt_text'      => array( 'type' => 'string', 'description' => 'Alt text to set when uploading from image_url.' ),
				),
				'required'   => array( 'post_id' ),
			),
		),
		array(
			'name'        => 'add_image_to_post',
			'description' => "Insert an image into a post's content as a Gutenberg image block. Provide an attachment_id or an image_url (which will be uploaded). Append or prepend.",
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'       => array( 'type' => 'integer' ),
					'attachment_id' => array( 'type' => 'integer' ),
					'image_url'     => array( 'type' => 'string' ),
					'alt_text'      => array( 'type' => 'string' ),
					'caption'       => array( 'type' => 'string' ),
					'position'      => array( 'type' => 'string', 'description' => "'append' (default) or 'prepend'." ),
				),
				'required'   => array( 'post_id' ),
			),
		),
		array(
			'name'        => 'replace_in_post',
			'description' => "Make a surgical edit to a post WITHOUT resending the whole body. Finds an exact snippet of the current content and inserts new content after it, before it, or replaces it. Keeps the request tiny, so prefer this over update_post for inserting blocks or fixing placement. Tip: first call get_post, copy an exact anchor (ideally a block delimiter like '<!-- /wp:paragraph -->' right after the target block), and pass complete block markup as new_content. If a firewall (WAF) blocks HTML in request bodies, pass both find and new_content base64-encoded as find_b64 / new_content_b64 (the anchor itself often contains tags like </p> or block delimiters, so encode both). Decoded server-side.",
			'inputSchema' => array(
				'type'       => 'object',
				'properties' => array(
					'post_id'         => array( 'type' => 'integer' ),
					'find'            => array( 'type' => 'string', 'description' => 'Exact text that already exists in the post content (copy it from get_post). Must match verbatim.' ),
					'find_b64'        => array( 'type' => 'string', 'description' => 'Base64 of the anchor text (alternative to find) — a transport fallback for servers that reject HTML in request bodies.' ),
					'new_content'     => array( 'type' => 'string', 'description' => 'Content to insert, or in replace mode the replacement text.' ),
					'new_content_b64' => array( 'type' => 'string', 'description' => 'Base64 of the new content (alternative to new_content). A transport fallback for servers that reject HTML in request bodies (decoded + sanitised identically to plain content).' ),
					'position'        => array( 'type' => 'string', 'description' => "'after' (default), 'before', or 'replace', relative to the found text." ),
					'occurrence'      => array( 'type' => 'integer', 'description' => 'Which match of find to act on if it appears more than once. Default 1.' ),
				),
				'required'   => array( 'post_id' ),
			),
		),
	);
}

/* ------------------------------------------------------------------------- *
 * tools/call dispatcher
 * ------------------------------------------------------------------------- */

/**
 * Run the rest of this request as the dedicated least-privilege service user (EngineKick Service role) so
 * block markup saves and every write is attributable — NEVER as an administrator. If the service user
 * cannot be resolved, writes are refused per tool (fail closed) and reads degrade to published-only. Called
 * once, by the first tools/call of the request; the handshake never needs it.
 */
function enginekick_mcp_assume_service_identity() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	$svc  = enginekick_mcp_author_id();
	if ( $svc > 0 ) {
		wp_set_current_user( $svc );
		return;
	}
	// No identity at all rather than whoever the incoming request happened to carry (V6 remediation note:
	// reads retained the incoming-user context).
	wp_set_current_user( 0 );
	// FAIL CLOSED FOR READS (V5-ext #6). Without the service identity the request runs as user 0, and
	// list_posts() still asked for draft/pending/private — perm => 'readable' gates private but core does NOT
	// gate drafts, so unpublished summaries and excerpts stayed reachable. Mark the request published-only;
	// the read tools clamp themselves against this flag.
	enginekick_mcp_published_only( true );
}

function enginekick_mcp_call_tool( $id, array $params ) {
	$name = ( isset( $params['name'] ) ? $params['name'] : '' );
	$args = ( isset( $params['arguments'] ) && is_array( $params['arguments'] ) ) ? $params['arguments'] : array();

	// The per-call limit (120 tool calls a minute per address). Charged here, per tool call, so a batch
	// pays for each member and the connection handshake is never charged for edits.
	if ( ! enginekick_rate_ok( 'mcp', 120, 60 ) ) {
		enginekick_mcp_log_refusal( 'rate_limited' );
		return enginekick_mcp_rpc_error( $id, -32000, 'Rate limited: more than 120 tool calls in a minute from this address. Wait a moment and retry; the connection itself is fine.' );
	}
	enginekick_mcp_assume_service_identity();

	enginekick_mcp_note( null, false, true );   // notes are per tool call (a batch holds several)
	// A field this connector does not understand is reported, never silently dropped. Both the slug and the
	// author requests used to be ignored while the call reported success, so the caller believed a URL or
	// an author had changed when nothing had.
	$ek_unknown = enginekick_mcp_unknown_args( $name, $args );
	if ( $ek_unknown ) {
		enginekick_mcp_note( 'Ignored: this connector does not support ' . implode( ', ', $ek_unknown ) . ' for ' . $name . ', so ' . ( 1 === count( $ek_unknown ) ? 'that field was' : 'those fields were' ) . ' NOT applied. Check tools/list for the supported fields.', true );
	}
	$is_write = enginekick_mcp_is_write_tool( $name );
	// Mode gate: in read-only mode, refuse every write tool up front (and record the rejection).
	if ( 'read_only' === enginekick_mcp_mode() && $is_write ) {
		enginekick_mcp_audit( $name, 'rejected:read_only', (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) ) ), null, null, false );
		return enginekick_mcp_tool_error( $id, 'This connector is in READ-ONLY mode; writes are disabled by the site owner. Ask them to raise the EngineKick MCP mode if a change is needed.' );
	}
	// Fail-closed: if the dedicated service account isn't available, refuse writes (never run them as
	// an admin) — reads still work as the current (published-only) context.
	if ( $is_write && enginekick_mcp_author_id() <= 0 ) {
		enginekick_mcp_audit( $name, 'rejected:no_service_user', (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) ) ), null, null, false );
		return enginekick_mcp_tool_error( $id, 'Writes are disabled: the enginekick-service account could not be created or verified. An administrator should open the EngineKick MCP page to resolve it.' );
	}

	try {
		switch ( $name ) {
			case 'get_site_info':
				$data = enginekick_mcp_get_site_info();
				break;
			case 'list_authors':
				$data = enginekick_mcp_list_authors( $args );
				break;
			case 'update_seo':
				$data = enginekick_mcp_update_seo( $args );
				break;
			case 'list_posts':
				$data = enginekick_mcp_list_posts( $args );
				break;
			case 'get_post':
				$data = enginekick_mcp_get_post( $args );
				break;
			case 'create_post':
				$data = enginekick_mcp_create_post( $args );
				break;
			case 'update_post':
				$data = enginekick_mcp_update_post( $args );
				break;
			case 'add_internal_links':
				$data = enginekick_mcp_add_internal_links( $args );
				break;
			case 'list_terms':
				$data = enginekick_mcp_list_terms( $args );
				break;
			case 'list_media':
				$data = enginekick_mcp_list_media( $args );
				break;
			case 'get_media':
				$data = enginekick_mcp_get_media( $args );
				break;
			case 'update_media':
				$data = enginekick_mcp_update_media( $args );
				break;
			case 'upload_media_from_url':
				$data = enginekick_mcp_upload_media_from_url( $args );
				break;
			case 'set_featured_image':
				$data = enginekick_mcp_set_featured_image( $args );
				break;
			case 'add_image_to_post':
				$data = enginekick_mcp_add_image_to_post( $args );
				break;
			case 'replace_in_post':
				$data = enginekick_mcp_replace_in_post( $args );
				break;
			default:
				return enginekick_mcp_tool_error( $id, enginekick_mcp_unknown_tool_msg( $name ) );
		}
	} catch ( Exception $e ) {
		return enginekick_mcp_tool_exception( $e, $id, $name, $args, $is_write );
	}

	if ( is_wp_error( $data ) ) {
		// Record failed writes too, so the audit distinguishes attempts from successes (review v2 #6).
		if ( $is_write ) {
			enginekick_mcp_audit( $name, 'error', (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) ) ), null, null, false );
		}
		$extra = array_column( enginekick_mcp_note(), 'message' );
		return enginekick_mcp_tool_error( $id, $data->get_error_message() . ( $extra ? ' (' . implode( ' ', $extra ) . ')' : '' ) );
	}

	// Truthful result (V6 #4): anything not applied, or that failed alongside the change, is returned.
	// Partial results stay non-errors on purpose: the change happened, and callers such as the TimeSync
	// router must still log the work that was done.
	$notes = enginekick_mcp_note();
	if ( $notes && is_array( $data ) ) {
		$data['warnings'] = array_column( $notes, 'message' );
		if ( enginekick_mcp_notes_partial() ) {
			$data['partial'] = true;
		}
	}

	return enginekick_mcp_result(
		$id,
		array(
			'content' => array(
				array(
					'type' => 'text',
					'text' => wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
				),
			),
			'isError' => false,
		)
	);
}

function enginekick_mcp_tool_error( $id, $message ) {
	return enginekick_mcp_result(
		$id,
		array(
			'content' => array(
				array( 'type' => 'text', 'text' => 'Error: ' . $message ),
			),
			'isError' => true,
		)
	);
}

/* ------------------------------------------------------------------------- *
 * Tool implementations
 * ------------------------------------------------------------------------- */

function enginekick_mcp_get_site_info() {
	$counts = wp_count_posts( 'post' );
	return array(
		'name'            => get_bloginfo( 'name' ),
		'description'     => get_bloginfo( 'description' ),
		'url'             => home_url(),
		'published_posts' => isset( $counts->publish ) ? (int) $counts->publish : 0,
		'draft_posts'     => isset( $counts->draft ) ? (int) $counts->draft : 0,
		// Which SEO plugin update_seo writes to ('none' when there is none it supports).
		'seo_plugin'      => ( $ek_seo = enginekick_mcp_seo_plugins() ) ? implode( ', ', array_map( function ( $p ) {
			return enginekick_mcp_seo_label( $p ) . ( '' !== enginekick_mcp_seo_dormant_reason( $p ) ? ' (setup not completed - not printing SEO tags yet)' : '' );
		}, $ek_seo ) ) : 'none',
	);
}

/**
 * Bounds for the list tools (R8 F10): a search string and a page depth the database can answer cheaply.
 * Returns array( page, search ) or a WP_Error that says how to narrow the request instead.
 */
function enginekick_mcp_list_bounds( array $args, $per_page ) {
	$search = is_array( ( isset( $args['search'] ) ? $args['search'] : null ) ) ? '' : (string) ( ( isset( $args['search'] ) ? $args['search'] : '' ) );
	if ( strlen( $search ) > ENGINEKICK_MCP_MAX_SEARCH ) {
		return new WP_Error( 'search_too_long', 'search is limited to ' . ENGINEKICK_MCP_MAX_SEARCH . ' characters. Use a few distinctive words.' );
	}
	$page = max( (int) ( ( isset( $args['page'] ) ? $args['page'] : 1 ) ), 1 );
	if ( ( $page - 1 ) * $per_page > ENGINEKICK_MCP_MAX_OFFSET ) {
		return new WP_Error( 'page_too_deep', 'That page starts beyond item ' . ENGINEKICK_MCP_MAX_OFFSET . '. Narrow the list with search, status or post_type instead of paging that far.' );
	}
	return array( $page, $search );
}
function enginekick_mcp_list_posts( array $args ) {
	$per_page = min( max( (int) ( ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ), 1 ), 100 );
	$ek_bounds = enginekick_mcp_list_bounds( $args, $per_page );   // R8 F10
	if ( is_wp_error( $ek_bounds ) ) {
		return $ek_bounds;
	}
	list( $ek_page, $ek_search ) = $ek_bounds;

	// TYPE CLAMP (V5 F4): post_type went straight into WP_Query, and WP_Query performs NO capability
	// check on the post type at all. A caller could name any CPT on the site — WooCommerce orders,
	// form entries, membership records, CRM objects — and read back titles, links and a content
	// excerpt for all of them, in read-only mode. Restrict to the same allowlist the write tools use.
	$allowed  = enginekick_mcp_allowed_post_types();
	$req_type = sanitize_key( (string) ( is_array( ( isset( $args['post_type'] ) ? $args['post_type'] : null ) ) ? '' : ( ( isset( $args['post_type'] ) ? $args['post_type'] : 'post' ) ) ) );
	if ( '' === $req_type ) { $req_type = 'post'; }
	if ( ! in_array( $req_type, $allowed, true ) ) {
		return new WP_Error( 'forbidden_type', 'Post type "' . $req_type . '" is not enabled for the connector (allowed: ' . implode( ', ', $allowed ) . ').' );
	}

	// STATUS CLAMP: only the documented editorial statuses. Keeps 'trash', 'auto-draft' and any
	// plugin-registered status (wc-processing, etc.) out of reach even for an allowlisted type.
	$valid_status = enginekick_mcp_published_only() ? array( 'publish' ) : array( 'publish', 'draft', 'pending', 'private', 'future' );
	$status       = $valid_status;
	if ( isset( $args['status'] ) && '' !== $args['status'] && ! is_array( $args['status'] ) ) {
		$asked  = array_map( 'trim', explode( ',', (string) $args['status'] ) );
		$status = array_values( array_intersect( $asked, $valid_status ) );
		if ( ! $status ) {
			return new WP_Error( 'bad_request', enginekick_mcp_published_only()
				? 'The connector service account is unavailable, so only published content can be read. Ask an administrator to open the EngineKick MCP page and repair it.'
				: 'status must be one or more of: ' . implode( ', ', $valid_status ) . '.' );
		}
	}

	// PER-OBJECT BOUNDARY (V6 #2). get_post() allows an unpublished post only with edit_post on it, but
	// WP_Query's 'readable' perm gates private items and NOT drafts, pending or scheduled ones. Without the
	// type's edit_others capability those must be limited to the identity's own posts IN the query, so
	// the listing, its totals and its page count never include objects get_post() would refuse.
	$unpub      = array_values( array_intersect( $status, array( 'draft', 'pending', 'future' ) ) );
	$pto        = get_post_type_object( $req_type );
	$own_unpub  = $unpub && ! current_user_can( $pto->cap->edit_others_posts );
	$restrict   = function ( $where, $q ) use ( $unpub ) {
		global $wpdb;
		if ( ! $q->get( 'enginekick_own_unpublished' ) ) {
			return $where;
		}
		$in = implode( ',', array_fill( 0, count( $unpub ), '%s' ) );
		return $where . $wpdb->prepare( " AND ( {$wpdb->posts}.post_status NOT IN ($in) OR {$wpdb->posts}.post_author = %d )", array_merge( $unpub, array( get_current_user_id() ) ) );
	};
	if ( $own_unpub ) {
		add_filter( 'posts_where', $restrict, 10, 2 );
	}
	$query = new WP_Query(
		array(
			'post_type'                  => $req_type,
			'post_status'                => $status,
			// 'readable': private items only with read_private_posts, otherwise the identity's own.
			'perm'                       => 'readable',
			'enginekick_own_unpublished' => $own_unpub,
			'posts_per_page'      => $per_page,
			'paged'               => $ek_page,
			's'                   => $ek_search,
			'orderby'             => in_array( ( ( isset( $args['orderby'] ) ? $args['orderby'] : '' ) ), array( 'modified', 'date', 'title', 'ID' ), true ) ? $args['orderby'] : 'modified',
			'order'               => strtoupper( ( isset( $args['order'] ) ? $args['order'] : 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC',
			'ignore_sticky_posts'        => true,
		)
	);
	if ( $own_unpub ) {
		remove_filter( 'posts_where', $restrict, 10 );
	}

	$posts = array();
	foreach ( $query->posts as $p ) {
		// Belt to the query restriction: the per-object guard get_post() uses, for UNPUBLISHED items. Not
		// for published ones: core maps read_post on a public post to the plain 'read' capability, which the
		// published-only fallback (user 0) lacks, so guarding them would empty that listing.
		if ( ! is_post_status_viewable( $p->post_status ) && is_wp_error( enginekick_mcp_object_guard( $p->ID, 'read_post' ) ) ) {
			continue;
		}
		$posts[] = enginekick_mcp_format_post_summary( $p );
	}

	return array(
		'page'        => max( (int) ( ( isset( $args['page'] ) ? $args['page'] : 1 ) ), 1 ),
		'per_page'    => $per_page,
		'total'       => (int) $query->found_posts,
		'total_pages' => (int) $query->max_num_pages,
		'posts'       => $posts,
	);
}

function enginekick_mcp_format_post_summary( $p ) {
	return array(
		'id'       => (int) $p->ID,
		'title'    => get_the_title( $p ),
		'status'   => $p->post_status,
		'type'     => $p->post_type,
		'author'   => enginekick_mcp_author_name( (int) $p->post_author ),
		'link'     => get_permalink( $p ),
		'date'     => $p->post_date,
		'modified' => $p->post_modified,
		'excerpt'  => wp_trim_words( wp_strip_all_tags( $p->post_content ), 30 ),
	);
}

function enginekick_mcp_get_post( array $args ) {
	$id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	if ( ! $id ) {
		return new WP_Error( 'bad_request', 'post_id is required.' );
	}
	// Read guard (review V4 #1): restrict to allowed post types + read capability, so a token cannot
	// retrieve unrelated private objects (templates, other CPTs) by guessing IDs.
	$p = enginekick_mcp_object_guard( $id, 'read_post' );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	return enginekick_mcp_format_post_full( $p );
}

/** What the caller may do with a post, by the connector's mode (R8 ponytail: it used to promise write access in read-only). */
function enginekick_mcp_edit_hint() {
	switch ( enginekick_mcp_mode() ) {
		case 'publish':
			return 'You can edit this post: call update_post (full body) or replace_in_post (surgical edit) with this post_id. Do not ask the user to connect or authenticate. If a write is blocked by a firewall, retry using the _b64 (base64) fields.';
		case 'draft_write':
			return 'You can edit drafts, but this site is in draft-only mode: live (published) posts cannot be changed. Use update_post or replace_in_post on drafts.';
		default:
			return 'This connector is read-only on this site: you can read posts but not change them.';
	}
}
function enginekick_mcp_format_post_full( $p ) {
	return array(
		'id'         => (int) $p->ID,
		'title'      => $p->post_title,
		'status'     => $p->post_status,
		'type'       => $p->post_type,
		'slug'       => $p->post_name,
		'author'     => enginekick_mcp_author_name( (int) $p->post_author ),
		'author_id'  => (int) $p->post_author,
		'link'       => get_permalink( $p ),
		'date'       => $p->post_date,
		'modified'   => $p->post_modified,
		'excerpt'    => $p->post_excerpt,
		'content'    => $p->post_content,
		'categories' => wp_get_post_categories( $p->ID, array( 'fields' => 'names' ) ),
		'tags'       => wp_get_post_tags( $p->ID, array( 'fields' => 'names' ) ),
		'word_count' => str_word_count( wp_strip_all_tags( $p->post_content ) ),
		'seo'        => enginekick_mcp_seo_snapshot( (int) $p->ID ),
		'edit_link'  => get_edit_post_link( $p->ID, 'raw' ),
		'_how_to_edit' => enginekick_mcp_edit_hint(),
	);
}

/**
 * Resolve a text field that may arrive plain or base64-encoded.
 *
 * WAFs (Cloudflare, Solid Security, etc.) often block request bodies that
 * contain HTML markup. To slip past content inspection, a caller may send any
 * field "<key>" base64-encoded as "<key>_b64"; the markup only reassembles
 * here, server-side, after every firewall has passed the (opaque) request.
 *
 * Returns: the decoded string, null if neither key was supplied, or a WP_Error
 * if the base64 was malformed.
 */
function enginekick_mcp_decode_field( array $args, $key ) {
	$max     = ENGINEKICK_MCP_MAX_FIELD_BYTES;
	$b64_key = $key . '_b64';
	if ( isset( $args[ $b64_key ] ) && '' !== $args[ $b64_key ] ) {
		$in = (string) $args[ $b64_key ];
		// Reject an oversized payload BEFORE decoding (base64 is ~1.34x its bytes).
		if ( strlen( $in ) > (int) ( $max * 1.4 ) ) {
			return new WP_Error( 'too_large', sprintf( 'The "%s" value exceeds the size limit.', $b64_key ) );
		}
		$clean = preg_replace( '/\s+/', '', $in );
		$raw   = base64_decode( $clean, true );
		if ( false === $raw ) {
			return new WP_Error( 'bad_base64', sprintf( 'The "%s" value is not valid base64.', $b64_key ) );
		}
		if ( strlen( $raw ) > $max ) {
			return new WP_Error( 'too_large', sprintf( 'The "%s" content exceeds the %d MB limit.', $b64_key, (int) ( $max / 1048576 ) ) );
		}
		if ( '' !== $raw && function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			return new WP_Error( 'bad_base64', sprintf( 'The "%s" value did not decode to valid UTF-8 text.', $b64_key ) );
		}
		return $raw;
	}
	if ( isset( $args[ $key ] ) ) {
		$v = (string) $args[ $key ];
		if ( strlen( $v ) > $max ) {
			return new WP_Error( 'too_large', sprintf( 'The "%s" content exceeds the %d MB limit.', $key, (int) ( $max / 1048576 ) ) );
		}
		return $v;
	}
	return null;
}

function enginekick_mcp_create_post( array $args ) {
	// Object guard: only an allowlisted post type may be created, and only with the create capability
	// (review V4 #1). Returns the validated type or a WP_Error.
	$ptype = enginekick_mcp_create_guard( ( isset( $args['post_type'] ) ? $args['post_type'] : 'post' ) );
	if ( is_wp_error( $ptype ) ) {
		return $ptype;
	}
	$allowed = array( 'draft', 'pending', 'publish', 'private' );
	$status  = in_array( ( ( isset( $args['status'] ) ? $args['status'] : '' ) ), $allowed, true ) ? $args['status'] : 'draft';
	// Draft-only mode: never let newly-created content go live.
	if ( 'publish' !== enginekick_mcp_mode() && in_array( $status, array( 'publish', 'private', 'future' ), true ) ) {
		$status = 'draft';
	}
	// Publishing at create time needs the publish capability for this type.
	if ( in_array( $status, array( 'publish', 'private', 'future' ), true ) && ! current_user_can( enginekick_mcp_publish_cap( $ptype ) ) ) {
		$status = 'draft';
	}

	$title = enginekick_mcp_decode_field( $args, 'title' );
	if ( is_wp_error( $title ) ) {
		return $title;
	}
	$content = enginekick_mcp_decode_field( $args, 'content' );
	if ( is_wp_error( $content ) ) {
		return $content;
	}
	$excerpt = enginekick_mcp_decode_field( $args, 'excerpt' );
	if ( is_wp_error( $excerpt ) ) {
		return $excerpt;
	}
	// Refuse bad term requests BEFORE the post exists (V6 #4).
	$terms = enginekick_mcp_plan_terms( $args );
	if ( is_wp_error( $terms ) ) {
		return $terms;
	}
	$slug = null;
	if ( isset( $args['slug'] ) && '' !== trim( (string) $args['slug'] ) ) {
		$slug = enginekick_mcp_clean_slug( $args['slug'] );
		if ( is_wp_error( $slug ) ) {
			return $slug;
		}
	}
	// Who the post is credited to — decided before anything is written, so a refused author creates nothing.
	$author_id = enginekick_mcp_resolve_author( isset( $args['author'] ) ? $args['author'] : null, $ptype );
	if ( is_wp_error( $author_id ) ) {
		return $author_id;
	}

	$postarr = array(
		'post_title'   => ( null !== $title && '' !== $title ) ? wp_strip_all_tags( $title ) : 'Untitled',
		'post_content' => null !== $content ? enginekick_mcp_kses_content( $content ) : '',
		'post_excerpt' => null !== $excerpt ? enginekick_mcp_kses_content( $excerpt ) : '',   // V5-ext #1
		'post_status'  => $status,
		'post_type'    => $ptype,
		'post_author'  => (int) $author_id,
	);
	if ( null !== $slug ) {
		$postarr['post_name'] = $slug;
	}
	$post_id = enginekick_mcp_write_post( $postarr, true );   // insert

	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	if ( null !== $slug && (string) get_post_field( 'post_name', $post_id ) !== $slug ) {
		enginekick_mcp_note( 'The address "' . $slug . '" is already used by other content, so WordPress gave this post "' . get_post_field( 'post_name', $post_id ) . '" instead.' );
	}

	enginekick_mcp_apply_terms( $post_id, $terms );   // anything not applied becomes a 'partial' note

	enginekick_mcp_audit( 'create_post', 'post', (int) $post_id, null, enginekick_mcp_post_fingerprint( (int) $post_id ) );

	return array(
		'id'        => (int) $post_id,
		'status'    => $status,
		'mode'      => enginekick_mcp_mode(),
		'slug'      => (string) get_post_field( 'post_name', $post_id ),
		'author'    => enginekick_mcp_author_name( (int) $author_id ),
		'link'      => get_permalink( $post_id ),
		'edit_link' => get_edit_post_link( $post_id, 'raw' ),
	);
}

/* ------------------------------------------------------------------------- *
 * SEO plugins: Rank Math, Yoast SEO, All in One SEO, SEOPress.
 *
 * Each plugin keeps a post's SEO title, description, focus keyword, canonical and robots in its own place,
 * read from its own source code (2026-10-02):
 *   Rank Math       post meta rank_math_{title,description,focus_keyword,canonical_url}, rank_math_robots
 *                   (a list such as ['noindex','nofollow']), read fresh on every page.
 *   Yoast SEO       post meta _yoast_wpseo_{title,metadesc,focuskw,canonical,meta-robots-noindex,-nofollow}
 *                   (noindex '1' = noindex, '2' = index, '0' = default). Yoast's indexables table is rebuilt
 *                   from that meta by its own watcher at the end of the request.
 *   All in One SEO  its own aioseo_posts table, written through its own Models\Post::savePost() — the call
 *                   its editor uses, with patch semantics (only the keys passed change).
 *   SEOPress        post meta _seopress_{titles_title,titles_desc,analysis_target_kw,robots_canonical},
 *                   _seopress_robots_index / _follow ('yes' = noindex / nofollow).
 * Every write is read back; a field that did not take is reported, never claimed.
 * ------------------------------------------------------------------------- */

/** Active SEO plugins this connector can write to, in priority order. */
function enginekick_mcp_seo_plugins() {
	$out = array();
	if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
		$out[] = 'rank_math';
	}
	if ( defined( 'WPSEO_VERSION' ) ) {
		$out[] = 'yoast';
	}
	if ( function_exists( 'aioseo' ) && class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
		$out[] = 'aioseo';
	}
	if ( defined( 'SEOPRESS_VERSION' ) ) {
		$out[] = 'seopress';
	}
	return $out;
}
/**
 * Why a plugin that is active still is not printing SEO tags, or ''. Rank Math stays silent on the front end
 * until the site owner connects an account or skips its setup wizard; values saved before then are kept and
 * appear once that is done, but nothing changes on the page in the meantime.
 */
function enginekick_mcp_seo_dormant_reason( $plugin ) {
	if ( 'rank_math' === $plugin && class_exists( '\RankMath\Helper' ) && method_exists( '\RankMath\Helper', 'is_invalid_registration' )
		&& \RankMath\Helper::is_invalid_registration() ) {
		return 'Rank Math is installed but its setup was never completed, so it is not printing any SEO tags on the site yet. The values are saved and will appear as soon as the site owner finishes (or skips) the Rank Math setup wizard in wp-admin.';
	}
	return '';
}
function enginekick_mcp_seo_label( $plugin ) {
	$labels = array( 'rank_math' => 'Rank Math', 'yoast' => 'Yoast SEO', 'aioseo' => 'All in One SEO', 'seopress' => 'SEOPress' );
	return isset( $labels[ $plugin ] ) ? $labels[ $plugin ] : (string) $plugin;
}

/** The SEO values a plugin holds for a post ('' / false = the plugin's own default applies). */
function enginekick_mcp_seo_read( $plugin, $post_id ) {
	$m = function ( $key ) use ( $post_id ) {
		return (string) get_post_meta( $post_id, $key, true );
	};
	switch ( $plugin ) {
		case 'rank_math':
			$robots = get_post_meta( $post_id, 'rank_math_robots', true );
			$robots = is_array( $robots ) ? $robots : array();
			return array(
				'seo_title'        => $m( 'rank_math_title' ),
				'meta_description' => $m( 'rank_math_description' ),
				'focus_keyword'    => $m( 'rank_math_focus_keyword' ),
				'canonical_url'    => $m( 'rank_math_canonical_url' ),
				'noindex'          => in_array( 'noindex', $robots, true ),
				'nofollow'         => in_array( 'nofollow', $robots, true ),
			);
		case 'yoast':
			return array(
				'seo_title'        => $m( '_yoast_wpseo_title' ),
				'meta_description' => $m( '_yoast_wpseo_metadesc' ),
				'focus_keyword'    => $m( '_yoast_wpseo_focuskw' ),
				'canonical_url'    => $m( '_yoast_wpseo_canonical' ),
				'noindex'          => '1' === $m( '_yoast_wpseo_meta-robots-noindex' ),
				'nofollow'         => '1' === $m( '_yoast_wpseo_meta-robots-nofollow' ),
			);
		case 'aioseo':
			$row = \AIOSEO\Plugin\Common\Models\Post::getPost( $post_id );
			$fk  = isset( $row->focus_keyword ) ? (string) $row->focus_keyword : '';
			if ( '' === $fk && isset( $row->keyphrases ) ) {
				$kp = is_string( $row->keyphrases ) ? json_decode( $row->keyphrases ) : $row->keyphrases;
				$fk = ( is_object( $kp ) && isset( $kp->focus->keyphrase ) ) ? (string) $kp->focus->keyphrase : '';
			}
			$custom = isset( $row->robots_default ) && ! $row->robots_default;
			return array(
				'seo_title'        => isset( $row->title ) ? (string) $row->title : '',
				'meta_description' => isset( $row->description ) ? (string) $row->description : '',
				'focus_keyword'    => $fk,
				'canonical_url'    => isset( $row->canonical_url ) ? (string) $row->canonical_url : '',
				'noindex'          => $custom && ! empty( $row->robots_noindex ),
				'nofollow'         => $custom && ! empty( $row->robots_nofollow ),
			);
		case 'seopress':
			return array(
				'seo_title'        => $m( '_seopress_titles_title' ),
				'meta_description' => $m( '_seopress_titles_desc' ),
				'focus_keyword'    => $m( '_seopress_analysis_target_kw' ),
				'canonical_url'    => $m( '_seopress_robots_canonical' ),
				'noindex'          => 'yes' === $m( '_seopress_robots_index' ),
				'nofollow'         => 'yes' === $m( '_seopress_robots_follow' ),
			);
	}
	return array();
}

/** Write $chg (only the fields being changed) to one plugin. Returns true or a WP_Error. */
function enginekick_mcp_seo_write( $plugin, $post_id, array $chg ) {
	$set = function ( $key, $value ) use ( $post_id ) {
		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, wp_slash( $value ) );   // meta is unslashed on save (R8 F2)
		}
	};
	switch ( $plugin ) {
		case 'rank_math':
			$map = array( 'seo_title' => 'rank_math_title', 'meta_description' => 'rank_math_description', 'focus_keyword' => 'rank_math_focus_keyword', 'canonical_url' => 'rank_math_canonical_url' );
			foreach ( $map as $k => $key ) {
				if ( array_key_exists( $k, $chg ) ) {
					$set( $key, $chg[ $k ] );
				}
			}
			if ( array_key_exists( 'noindex', $chg ) || array_key_exists( 'nofollow', $chg ) ) {
				$robots = get_post_meta( $post_id, 'rank_math_robots', true );
				$robots = is_array( $robots ) ? $robots : array();
				if ( array_key_exists( 'noindex', $chg ) ) {
					$robots   = array_diff( $robots, array( 'index', 'noindex' ) );
					$robots[] = $chg['noindex'] ? 'noindex' : 'index';
				}
				if ( array_key_exists( 'nofollow', $chg ) ) {
					$robots   = array_diff( $robots, array( 'follow', 'nofollow' ) );
					$robots[] = $chg['nofollow'] ? 'nofollow' : 'follow';
				}
				update_post_meta( $post_id, 'rank_math_robots', array_values( array_unique( $robots ) ) );
			}
			return true;
		case 'yoast':
			$map = array( 'seo_title' => '_yoast_wpseo_title', 'meta_description' => '_yoast_wpseo_metadesc', 'focus_keyword' => '_yoast_wpseo_focuskw', 'canonical_url' => '_yoast_wpseo_canonical' );
			foreach ( $map as $k => $key ) {
				if ( array_key_exists( $k, $chg ) ) {
					$set( $key, $chg[ $k ] );
				}
			}
			if ( array_key_exists( 'noindex', $chg ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', $chg['noindex'] ? '1' : '2' );
			}
			if ( array_key_exists( 'nofollow', $chg ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', $chg['nofollow'] ? '1' : '0' );
			}
			return true;   // Yoast's own meta watcher rebuilds its indexable at the end of this request
		case 'aioseo':
			$data = array();
			$map  = array( 'seo_title' => 'title', 'meta_description' => 'description', 'focus_keyword' => 'focus_keyword', 'canonical_url' => 'canonical_url' );
			foreach ( $map as $k => $key ) {
				if ( array_key_exists( $k, $chg ) ) {
					$data[ $key ] = $chg[ $k ];
				}
			}
			if ( array_key_exists( 'noindex', $chg ) || array_key_exists( 'nofollow', $chg ) ) {
				// Custom robots need "use defaults" switched off and BOTH flags stated, or the one not being
				// changed would silently flip.
				$cur              = enginekick_mcp_seo_read( 'aioseo', $post_id );
				$data['default']  = false;
				$data['noindex']  = array_key_exists( 'noindex', $chg ) ? (bool) $chg['noindex'] : (bool) $cur['noindex'];
				$data['nofollow'] = array_key_exists( 'nofollow', $chg ) ? (bool) $chg['nofollow'] : (bool) $cur['nofollow'];
			}
			$res = \AIOSEO\Plugin\Common\Models\Post::savePost( $post_id, $data );
			if ( is_string( $res ) && '' !== $res ) {
				return new WP_Error( 'seo_write_failed', 'All in One SEO refused the change: ' . $res );
			}
			return true;
		case 'seopress':
			$map = array( 'seo_title' => '_seopress_titles_title', 'meta_description' => '_seopress_titles_desc', 'focus_keyword' => '_seopress_analysis_target_kw', 'canonical_url' => '_seopress_robots_canonical' );
			foreach ( $map as $k => $key ) {
				if ( array_key_exists( $k, $chg ) ) {
					$set( $key, $chg[ $k ] );
				}
			}
			if ( array_key_exists( 'noindex', $chg ) ) {
				$set( '_seopress_robots_index', $chg['noindex'] ? 'yes' : '' );
			}
			if ( array_key_exists( 'nofollow', $chg ) ) {
				$set( '_seopress_robots_follow', $chg['nofollow'] ? 'yes' : '' );
			}
			return true;
	}
	return new WP_Error( 'seo_unknown_plugin', 'Unknown SEO plugin.' );
}

/** What get_post shows: the primary plugin's values, or plugin = null when none is active. */
function enginekick_mcp_seo_snapshot( $post_id ) {
	$plugins = enginekick_mcp_seo_plugins();
	if ( ! $plugins ) {
		return array( 'plugin' => null, 'note' => 'No supported SEO plugin is active, so search engines see the post title and excerpt. Supported: Rank Math, Yoast SEO, All in One SEO, SEOPress.' );
	}
	$out = array( 'plugin' => enginekick_mcp_seo_label( $plugins[0] ) ) + enginekick_mcp_seo_read( $plugins[0], $post_id );
	if ( count( $plugins ) > 1 ) {
		$out['also_active'] = array_map( 'enginekick_mcp_seo_label', array_slice( $plugins, 1 ) );
	}
	return $out;
}
/** SEO values for the audit fingerprint; null when there is no SEO plugin (nothing to compare). */
function enginekick_mcp_seo_fields_for_audit( $post_id ) {
	$plugins = $post_id ? enginekick_mcp_seo_plugins() : array();
	return $plugins ? enginekick_mcp_seo_read( $plugins[0], $post_id ) : null;
}

function enginekick_mcp_update_seo( array $args ) {
	$id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	$og = enginekick_mcp_object_guard( $id, 'edit_post' );
	if ( is_wp_error( $og ) ) {
		return $og;
	}
	$guard = enginekick_mcp_guard_live_edit( $id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$plugins = enginekick_mcp_seo_plugins();
	if ( ! $plugins ) {
		return new WP_Error( 'no_seo_plugin', 'No supported SEO plugin is active on this site, so there are no SEO fields to set. Supported: Rank Math, Yoast SEO, All in One SEO, SEOPress. Without one, search engines use the post title and excerpt — change those with update_post.' );
	}

	// Validate everything before writing anything.
	$chg = array();
	foreach ( array( 'seo_title' => 300, 'meta_description' => 1000, 'focus_keyword' => 200 ) as $k => $max ) {
		if ( array_key_exists( $k, $args ) ) {
			$v = sanitize_text_field( (string) $args[ $k ] );
			if ( strlen( $v ) > $max ) {
				return new WP_Error( 'seo_too_long', $k . ' is longer than ' . $max . ' characters.' );
			}
			$chg[ $k ] = $v;
		}
	}
	if ( array_key_exists( 'canonical_url', $args ) ) {
		$v = trim( (string) $args['canonical_url'] );
		if ( '' !== $v ) {
			$scheme = strtolower( (string) wp_parse_url( $v, PHP_URL_SCHEME ) );
			$host   = strtolower( (string) wp_parse_url( $v, PHP_URL_HOST ) );
			if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || '' === $host ) {
				return new WP_Error( 'bad_canonical', 'canonical_url must be a full http(s) address on this site.' );
			}
			// Same site only: a canonical pointing elsewhere quietly hands this page's ranking to another
			// domain, which is exactly what a leaked connector URL must not be able to do.
			if ( strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) !== $host ) {
				return new WP_Error( 'bad_canonical', 'canonical_url must point at this site (' . wp_parse_url( home_url(), PHP_URL_HOST ) . '). A canonical to another domain hands this page\'s search ranking to that domain, so the connector does not set one; a site administrator can, in the SEO plugin.' );
			}
			$v = esc_url_raw( $v );
		}
		$chg['canonical_url'] = $v;
	}
	foreach ( array( 'noindex', 'nofollow' ) as $k ) {
		if ( array_key_exists( $k, $args ) ) {
			$b = $args[ $k ];
			if ( true === $b || false === $b ) {
				$chg[ $k ] = $b;
			} elseif ( in_array( $b, array( 1, 0, '1', '0', 'true', 'false' ), true ) ) {
				$chg[ $k ] = in_array( $b, array( 1, '1', 'true' ), true );
			} else {
				return new WP_Error( 'seo_bad_flag', $k . ' must be true or false.' );
			}
		}
	}
	if ( ! $chg ) {
		return new WP_Error( 'nothing_to_change', 'Nothing to change: pass at least one of seo_title, meta_description, focus_keyword, canonical_url, noindex, nofollow.' );
	}

	$before = enginekick_mcp_post_fingerprint( $id );
	foreach ( $plugins as $plugin ) {
		$res = enginekick_mcp_seo_write( $plugin, $id, $chg );
		if ( is_wp_error( $res ) ) {
			enginekick_mcp_note( enginekick_mcp_seo_label( $plugin ) . ': ' . $res->get_error_message(), true );
			continue;
		}
		// Read back: a value the plugin did not keep is reported, not claimed.
		$now = enginekick_mcp_seo_read( $plugin, $id );
		foreach ( $chg as $k => $want ) {
			if ( isset( $now[ $k ] ) && $now[ $k ] !== $want ) {
				enginekick_mcp_note( enginekick_mcp_seo_label( $plugin ) . ' did not keep ' . $k . ' (it holds ' . wp_json_encode( $now[ $k ] ) . ').', true );
			}
		}
	}
	foreach ( $plugins as $plugin ) {
		$why = enginekick_mcp_seo_dormant_reason( $plugin );
		if ( '' !== $why ) {
			enginekick_mcp_note( $why );   // saved, but the page will not show it yet — say so
		}
	}
	clean_post_cache( $id );
	enginekick_mcp_audit( 'update_seo', 'post', $id, $before, enginekick_mcp_post_fingerprint( $id ) );

	$out = array(
		'post_id'    => $id,
		'link'       => get_permalink( $id ),
		'seo_plugin' => implode( ', ', array_map( 'enginekick_mcp_seo_label', $plugins ) ),
		'seo'        => enginekick_mcp_seo_snapshot( $id ),
		'changed'    => array_keys( $chg ),
	);
	return $out;
}

/* ------------------------------------------------------------------------- *
 * Post author.
 *
 * Writes run AS the EngineKick Service account (least privilege, auditable), but a post is CREDITED to a
 * person: the default author the site admin chose on the EngineKick MCP page, or another person from the
 * admin's list named in the call. Never anyone outside that list — a leaked connector URL must not be able
 * to put the site owner's (or anyone's) name on content the admin did not allow. Never the service account
 * when a default is set; when none is, the post falls back to it and the result says so.
 * ------------------------------------------------------------------------- */

/** Display name for a user id, for results and the audit trail. */
function enginekick_mcp_author_name( $user_id ) {
	$u = $user_id ? get_userdata( (int) $user_id ) : false;
	return $u ? (string) $u->display_name : ( $user_id ? 'user #' . (int) $user_id : 'nobody' );
}

/** May this user be credited as the author of $post_type posts? */
function enginekick_mcp_can_be_author( $user, $post_type = 'post' ) {
	if ( ! $user instanceof WP_User || ! $user->exists() ) {
		return false;
	}
	if ( enginekick_mcp_service_login() === $user->user_login ) {
		return false;   // the whole point: never credit the automation account
	}
	$pto = get_post_type_object( $post_type );
	return user_can( $user, ( $pto && isset( $pto->cap->edit_posts ) ) ? $pto->cap->edit_posts : 'edit_posts' );
}

/** The people the admin allows Claude to credit, keyed by id, default first; only those who can still write. */
function enginekick_mcp_allowed_authors( $post_type = 'post' ) {
	$ids = array_map( 'intval', (array) get_option( 'enginekick_mcp_allowed_authors', array() ) );
	$def = (int) get_option( 'enginekick_mcp_default_author', 0 );
	if ( $def ) {
		array_unshift( $ids, $def );
	}
	$out = array();
	foreach ( array_unique( $ids ) as $uid ) {
		$u = $uid ? get_userdata( $uid ) : false;
		if ( $u && enginekick_mcp_can_be_author( $u, $post_type ) ) {
			$out[ (int) $u->ID ] = $u;
		}
	}
	return $out;
}

/**
 * Which user a post is credited to. $requested is what the caller passed (id, display name, slug or
 * username) or null for "the default". Returns a user id, or WP_Error when a named author is not allowed.
 * Falling back to the service account always leaves a note explaining why and what to do.
 */
function enginekick_mcp_resolve_author( $requested, $post_type ) {
	$allowed = enginekick_mcp_allowed_authors( $post_type );
	if ( null !== $requested && '' !== trim( (string) $requested ) ) {
		$want = trim( (string) $requested );
		foreach ( $allowed as $uid => $u ) {
			if ( ( preg_match( '/^\d+$/', $want ) && (int) $want === $uid )
				|| 0 === strcasecmp( $want, (string) $u->display_name )
				|| 0 === strcasecmp( $want, (string) $u->user_nicename )
				|| 0 === strcasecmp( $want, (string) $u->user_login ) ) {
				return $uid;
			}
		}
		$names = implode( ', ', array_map( function ( $u ) {
			return (string) $u->display_name;
		}, $allowed ) );
		return new WP_Error( 'author_not_allowed', '"' . $want . '" is not one of the people the site owner allows posts to be credited to' . ( '' !== $names ? ' (' . $names . ')' : '' ) . '. Call list_authors to see them; the site owner can add people on the EngineKick MCP page.' );
	}
	$def = (int) get_option( 'enginekick_mcp_default_author', 0 );
	if ( $def && isset( $allowed[ $def ] ) ) {
		return $def;
	}
	if ( $def ) {
		enginekick_mcp_note( 'The default author (' . enginekick_mcp_author_name( $def ) . ') can no longer write posts, so this post is credited to the EngineKick Service account. Ask the site owner to choose another default author on the EngineKick MCP page, then re-credit it with update_post.' );
	} else {
		enginekick_mcp_note( 'No default author is set, so this post is credited to the EngineKick Service account. Ask the site owner to choose a default author on the EngineKick MCP page (or pass author), then re-credit it with update_post.' );
	}
	return enginekick_mcp_author_id();
}

function enginekick_mcp_list_authors( array $args ) {
	$ptype = isset( $args['post_type'] ) ? sanitize_key( (string) $args['post_type'] ) : 'post';
	if ( ! in_array( $ptype, enginekick_mcp_allowed_post_types(), true ) ) {
		return new WP_Error( 'forbidden_type', 'That post type is not enabled for the connector.' );
	}
	$def     = (int) get_option( 'enginekick_mcp_default_author', 0 );
	$allowed = enginekick_mcp_allowed_authors( $ptype );
	$out     = array();
	foreach ( $allowed as $uid => $u ) {
		// Id, public display name and the public author slug only — never a login or an email address.
		$out[] = array( 'id' => $uid, 'name' => (string) $u->display_name, 'slug' => (string) $u->user_nicename, 'default' => $uid === $def );
	}
	return array(
		'authors'        => $out,
		'default_author' => isset( $allowed[ $def ] ) ? $def : 0,
		'note'           => $out
			? 'Pass author (id, name or slug) to create_post or update_post. Without it, new posts are credited to the default author.'
			: 'The site owner has not chosen any authors yet, so new posts are credited to the EngineKick Service account. They can choose a default author on the EngineKick MCP page.',
	);
}

/** Arguments a call passed that the tool's schema does not define. */
function enginekick_mcp_unknown_args( $name, array $args ) {
	foreach ( enginekick_mcp_tools() as $t ) {
		if ( $t['name'] === $name ) {
			$known = array_keys( (array) ( isset( $t['inputSchema']['properties'] ) ? $t['inputSchema']['properties'] : array() ) );
			return array_values( array_diff( array_keys( $args ), $known ) );
		}
	}
	return array();   // unknown tool: reported separately
}

/* ------------------------------------------------------------------------- *
 * URL changes (slug) and redirects from the old address.
 *
 * WordPress core redirects a renamed POST's old slug (_wp_old_slug), but not a page's, and only for posts
 * that are published at the moment of the rename. The connector records the old address of anything it
 * renames and answers a 404 on that address with a 301 to the CURRENT permalink — resolved by post ID, so a
 * chain of renames is always one hop and never a loop. It runs only on a 404, so it can never override a
 * real page, and only while the target is publicly viewable, so it never points at hidden content.
 * ------------------------------------------------------------------------- */

/** Clean a requested slug. Returns the slug, or a WP_Error explaining what was wrong. */
function enginekick_mcp_clean_slug( $raw ) {
	$raw = trim( trim( (string) $raw ), '/' );
	if ( false !== strpos( $raw, '/' ) ) {
		return new WP_Error( 'bad_slug', 'A slug is one part of the address, without slashes (for example french-bulldog-sleep). To put a page under another page, set its parent in WordPress.' );
	}
	$slug = sanitize_title( $raw );
	if ( '' === $slug ) {
		return new WP_Error( 'bad_slug', 'That slug has nothing usable in it. Use letters, numbers and hyphens, for example french-bulldog-sleep.' );
	}
	if ( strlen( $slug ) > 200 ) {
		return new WP_Error( 'bad_slug', 'That slug is too long: WordPress allows 200 characters.' );
	}
	return $slug;
}

/** One comparable form for an address path: decoded, lower-case, leading slash, no trailing slash. */
function enginekick_mcp_norm_path( $path ) {
	return '/' . trim( strtolower( rawurldecode( (string) $path ) ), '/' );
}

/**
 * Remember that $post_id used to live at $old_url, so the old address can redirect. Returns true when a
 * redirect is now in place, false when none is needed (plain permalinks, or the path did not change).
 */
function enginekick_mcp_remember_old_path( $post_id, $old_url ) {
	$old  = enginekick_mcp_norm_path( wp_parse_url( (string) $old_url, PHP_URL_PATH ) );
	$new  = enginekick_mcp_norm_path( wp_parse_url( (string) get_permalink( $post_id ), PHP_URL_PATH ) );
	$home = enginekick_mcp_norm_path( wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
	if ( $old === $new || $old === $home ) {
		return false;
	}
	// The address the post has NOW must never redirect away from itself (renamed back to an old slug).
	delete_post_meta( $post_id, '_enginekick_old_path', $new );
	if ( ! in_array( $old, (array) get_post_meta( $post_id, '_enginekick_old_path' ), true ) ) {
		add_post_meta( $post_id, '_enginekick_old_path', wp_slash( $old ) );
	}
	if ( ! get_option( 'enginekick_has_old_paths' ) ) {
		update_option( 'enginekick_has_old_paths', '1', true );   // lets every other 404 skip the lookup
	}
	return true;
}

/** On a 404, send a remembered old address to the current permalink. */
function enginekick_mcp_old_path_redirect() {
	if ( ! is_404() || ! get_option( 'enginekick_has_old_paths' ) ) {
		return;
	}
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$path = enginekick_mcp_norm_path( wp_parse_url( $uri, PHP_URL_PATH ) );
	if ( '/' === $path ) {
		return;
	}
	global $wpdb;
	$id = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_enginekick_old_path' AND meta_value = %s ORDER BY meta_id DESC LIMIT 1",
		$path
	) );
	if ( ! $id || ! is_post_publicly_viewable( $id ) ) {
		return;
	}
	$to = (string) get_permalink( $id );
	if ( '' === $to || enginekick_mcp_norm_path( wp_parse_url( $to, PHP_URL_PATH ) ) === $path ) {
		return;
	}
	$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
	if ( '' !== $query ) {
		$to .= ( false === strpos( $to, '?' ) ? '?' : '&' ) . $query;   // campaign tags survive the move
	}
	wp_safe_redirect( $to, 301, 'EngineKick' );
	exit;
}
// Priority 9: before core's own old-slug redirect and canonical guessing (10), so an address the connector
// renamed always lands on the current permalink with its query string intact.
add_action( 'template_redirect', 'enginekick_mcp_old_path_redirect', 9 );

function enginekick_mcp_update_post( array $args ) {
	$id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	// Object guard: allowed post type + edit capability for THIS object (review V4 #1).
	$og = enginekick_mcp_object_guard( $id, 'edit_post' );
	if ( is_wp_error( $og ) ) {
		return $og;
	}
	$guard = enginekick_mcp_guard_live_edit( $id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	// Publishing / setting a live status needs the publish capability for this post type.
	if ( isset( $args['status'] ) && in_array( $args['status'], array( 'publish', 'private', 'future' ), true ) ) {
		$pg = enginekick_mcp_object_guard( $id, 'publish_post' );
		if ( is_wp_error( $pg ) ) {
			return $pg;
		}
	}
	$before = enginekick_mcp_post_fingerprint( $id );

	$postarr = array( 'ID' => $id );

	$title = enginekick_mcp_decode_field( $args, 'title' );
	if ( is_wp_error( $title ) ) {
		return $title;
	}
	if ( null !== $title ) {
		$postarr['post_title'] = wp_strip_all_tags( $title );
	}

	$content = enginekick_mcp_decode_field( $args, 'content' );
	if ( is_wp_error( $content ) ) {
		return $content;
	}
	if ( null !== $content ) {
		$postarr['post_content'] = enginekick_mcp_kses_content( $content );
	}

	$excerpt = enginekick_mcp_decode_field( $args, 'excerpt' );
	if ( is_wp_error( $excerpt ) ) {
		return $excerpt;
	}
	if ( null !== $excerpt ) {
		$postarr['post_excerpt'] = enginekick_mcp_kses_content( $excerpt );   // V5-ext #1
	}
	if ( isset( $args['status'] ) ) {
		$allowed = array( 'draft', 'pending', 'publish', 'private' );
		if ( ! in_array( $args['status'], $allowed, true ) ) {
			return new WP_Error( 'forbidden_status', 'That status is not allowed. Deleting/trashing is disabled.' );
		}
		if ( 'publish' !== enginekick_mcp_mode() && in_array( $args['status'], array( 'publish', 'private', 'future' ), true ) ) {
			return new WP_Error( 'draft_only', 'Draft-only mode: cannot set status to ' . $args['status'] . '. Ask the site owner to switch the EngineKick MCP to publish mode.' );
		}
		$postarr['post_status'] = $args['status'];
	}
	// URL change. Cleaned and validated here, before anything is written.
	$slug     = null;
	$old_slug = (string) get_post_field( 'post_name', $id );
	if ( isset( $args['slug'] ) && '' !== trim( (string) $args['slug'] ) ) {
		$slug = enginekick_mcp_clean_slug( $args['slug'] );
		if ( is_wp_error( $slug ) ) {
			return $slug;
		}
		if ( $slug === $old_slug ) {
			$slug = null;   // already the address — nothing to do
		} else {
			$postarr['post_name'] = $slug;
		}
	}
	// Re-credit only when asked; an update that does not mention author never changes it.
	if ( isset( $args['author'] ) && '' !== trim( (string) $args['author'] ) ) {
		$new_author = enginekick_mcp_resolve_author( $args['author'], get_post_type( $id ) );
		if ( is_wp_error( $new_author ) ) {
			return $new_author;
		}
		if ( (int) $new_author !== (int) get_post_field( 'post_author', $id ) ) {
			$postarr['post_author'] = (int) $new_author;
		}
	}
	$old_url    = (string) get_permalink( $id );
	$was_public = is_post_publicly_viewable( $id );
	// Every check that can refuse the call runs BEFORE the post changes (V6 #4): a refused update used to
	// commit the title/content first and then report failure on the terms.
	$terms = enginekick_mcp_plan_terms( $args );
	if ( is_wp_error( $terms ) ) {
		return $terms;
	}

	$res = enginekick_mcp_write_post( $postarr );
	if ( is_wp_error( $res ) ) {
		return $res;
	}

	enginekick_mcp_apply_terms( $id, $terms );   // after the write: failures are 'partial' notes, not errors

	$url_change = null;
	if ( null !== $slug ) {
		$got     = (string) get_post_field( 'post_name', $id );
		$new_url = (string) get_permalink( $id );
		if ( $got !== $slug ) {
			// The rename happened, just not to the exact address asked for: say so, so the caller does
			// not link to or announce an address that does not exist.
			enginekick_mcp_note( 'The address "' . $slug . '" is already used by other content, so WordPress gave this post "' . $got . '" instead: ' . $new_url );
		}
		$redirected = $was_public ? enginekick_mcp_remember_old_path( $id, $old_url ) : false;
		$url_change = array(
			'from'     => $old_url,
			'to'       => $new_url,
			'redirect' => $redirected
				? 'The old address now 301-redirects to the new one.'
				: ( $was_public ? 'No redirect needed: the address path did not change.' : 'No redirect needed: the old address was not public.' ),
		);
	}

	enginekick_mcp_audit( 'update_post', 'post', $id, $before, enginekick_mcp_post_fingerprint( $id ) );

	$out = enginekick_mcp_format_post_full( get_post( $id ) );
	if ( $url_change ) {
		$out['url_change'] = $url_change;
	}
	return $out;
}

/**
 * Validate a categories/tags request and work out what can be applied — WITHOUT writing (V6 #3, #4).
 *
 * Refusals (malformed input, more than 30 names, no permission to assign the taxonomy at all) are returned
 * BEFORE the post is touched, so a refused call never leaves a half-applied change. A name that does not
 * exist yet is created only with the taxonomy's own edit_terms capability; without it the name is planned
 * as skipped and reported, and the rest of the request still applies.
 *
 * Deliberately stricter than WordPress's REST API, which lets anyone who may assign TAGS create new ones:
 * an operator who removes term management from the service role gets exactly that boundary.
 */
function enginekick_mcp_plan_terms( array $args ) {
	$plan = array();
	foreach ( array( 'categories' => 'category', 'tags' => 'post_tag' ) as $arg => $tax ) {
		if ( ! isset( $args[ $arg ] ) ) {
			continue;
		}
		if ( ! is_array( $args[ $arg ] ) ) {
			return new WP_Error( 'bad_request', '"' . $arg . '" must be an array of names.' );
		}
		if ( count( $args[ $arg ] ) > 30 ) {
			return new WP_Error( 'too_many_terms', 'At most 30 ' . $arg . ' per call (got ' . count( $args[ $arg ] ) . ').' );
		}
		$names = array();
		foreach ( $args[ $arg ] as $n ) {
			$n = is_scalar( $n ) ? trim( (string) $n ) : '';
			if ( '' !== $n && ! in_array( $n, $names, true ) ) {
				$names[] = $n;
			}
		}
		if ( 'category' === $tax && ! $names ) {
			continue;   // unchanged contract: an empty category list leaves the post's categories alone
		}
		$tobj = get_taxonomy( $tax );
		if ( ! $tobj || ! current_user_can( $tobj->cap->assign_terms ) ) {
			return new WP_Error( 'forbidden_cap', 'The connector service account cannot assign ' . $arg . '.' );
		}
		$step = array( 'arg' => $arg, 'ids' => array(), 'create' => array(), 'skip' => array(), 'requested' => count( $names ) );
		foreach ( $names as $name ) {
			$t = term_exists( $name, $tax );
			if ( $t ) {
				$step['ids'][] = (int) ( is_array( $t ) ? $t['term_id'] : $t );
			} elseif ( current_user_can( $tobj->cap->edit_terms ) ) {
				$step['create'][] = $name;
			} else {
				$step['skip'][] = $name;
			}
		}
		$plan[ $tax ] = $step;
	}
	return $plan;
}

// Apply a term plan after the post write. Every term or setter failure becomes a 'partial' note.
function enginekick_mcp_apply_terms( $post_id, array $plan ) {
	foreach ( $plan as $tax => $step ) {
		$label = ( 'category' === $tax ) ? 'Category' : 'Tag';
		$ids   = $step['ids'];
		foreach ( $step['skip'] as $name ) {
			enginekick_mcp_note( $label . ' "' . $name . '" was not applied: it does not exist yet and the connector service account may not create ' . $step['arg'] . '.', true );
		}
		foreach ( $step['create'] as $name ) {
			$t = wp_insert_term( $name, $tax );
			if ( ! is_wp_error( $t ) ) {
				$ids[] = (int) $t['term_id'];
				continue;
			}
			$existing = term_exists( $name, $tax );   // created meanwhile by someone else
			if ( $existing ) {
				$ids[] = (int) $existing['term_id'];
			} else {
				enginekick_mcp_note( $label . ' "' . $name . '" was not applied: ' . $t->get_error_message(), true );
			}
		}
		$ids = array_values( array_unique( $ids ) );
		if ( ! $ids && $step['requested'] > 0 ) {
			continue;   // nothing applicable: leave the existing terms rather than wiping them
		}
		$res = ( 'category' === $tax ) ? wp_set_post_categories( $post_id, $ids ) : wp_set_object_terms( $post_id, $ids, 'post_tag' );
		if ( false === $res || is_wp_error( $res ) ) {
			enginekick_mcp_note( ( 'category' === $tax ? 'Categories' : 'Tags' ) . ' could not be saved' . ( is_wp_error( $res ) ? ': ' . $res->get_error_message() : '.' ), true );
		}
	}
}

function enginekick_mcp_add_internal_links( array $args ) {
	$id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	$p  = enginekick_mcp_object_guard( $id, 'edit_post' );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$guard = enginekick_mcp_guard_live_edit( $id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$before = enginekick_mcp_post_fingerprint( $id );
	$links  = ( isset( $args['links'] ) ? $args['links'] : array() );
	if ( ! is_array( $links ) || empty( $links ) ) {
		return new WP_Error( 'bad_request', 'A non-empty "links" array is required.' );
	}
	// Bounds (V5-ext #9): every link runs a PCRE pass over the whole body, so both the number of
	// links and the replacements per link are capped.
	if ( count( $links ) > 50 ) {
		return new WP_Error( 'too_many_links', 'At most 50 links per call (got ' . count( $links ) . ').' );
	}
	$max = isset( $args['max_occurrences'] ) ? min( 20, max( 1, (int) $args['max_occurrences'] ) ) : 1;

	list( $new_content, $report ) = enginekick_mcp_insert_links( $p->post_content, $links, $max );

	if ( $new_content === $p->post_content ) {
		return array(
			'updated' => false,
			'message' => 'No anchor text matched in the post body; nothing was changed.',
			'report'  => $report,
		);
	}
	// Second data-loss guard (V5 F2): never let a link pass shrink a non-empty body to nothing, or
	// lose more than half of it. Link insertion only ever ADDS markup, so a shrink means a bug.
	if ( '' !== trim( (string) $p->post_content )
		&& ( '' === trim( (string) $new_content ) || strlen( (string) $new_content ) < strlen( (string) $p->post_content ) ) ) {
		enginekick_mcp_audit( 'add_internal_links', 'rejected:shrink', $id, null, null, false );   // object_type is VARCHAR(20)
		return new WP_Error( 'content_shrink', 'Refused: the link pass would have shortened the post body. Nothing was written. Report this — it indicates a pattern failure, not a content problem.' );
	}

	// The anchors were built here (esc_url on the target, the anchor text is the site's own words), so the
	// body goes back unchanged apart from them — see enginekick_mcp_write_post for why it is not re-filtered.
	$res = enginekick_mcp_write_post( array( 'ID' => $id, 'post_content' => $new_content ) );
	if ( is_wp_error( $res ) ) {
		return $res;
	}

	enginekick_mcp_audit( 'add_internal_links', 'post', $id, $before, enginekick_mcp_post_fingerprint( $id ) );

	return array(
		'updated' => true,
		'post_id' => $id,
		'link'    => get_permalink( $id ),
		'report'  => $report,
	);
}

/**
 * Wrap matching anchor text in <a> tags, only in body text (not inside an
 * existing tag's attributes and not inside an existing <a>...</a>).
 *
 * @return array [ string $content, array $report ]
 */
function enginekick_mcp_insert_links( $content, array $links, $max_per_link ) {
	$report = array();

	foreach ( $links as $link ) {
		$anchor = isset( $link['anchor_text'] ) ? trim( (string) $link['anchor_text'] ) : '';

		$url = '';
		if ( ! empty( $link['target_post_id'] ) ) {
			// Link only to a PUBLISHED post of an enabled type (pre-install #6). Any post ID used to be accepted,
			// so a live page could be given the permalink of a draft, a private post or a blocked type.
			$target = get_post( (int) $link['target_post_id'] );
			if ( ! $target || ! in_array( $target->post_type, enginekick_mcp_allowed_post_types(), true ) || ! is_post_publicly_viewable( $target ) ) {
				$report[] = array(
					'anchor'   => $anchor,
					'url'      => '',
					'inserted' => 0,
					'skipped'  => 'target post #' . (int) $link['target_post_id'] . ' is not a published post of an enabled type',
				);
				continue;
			}
			$url = get_permalink( $target );
		}
		if ( '' === $url && ! empty( $link['target_url'] ) ) {
			$url = esc_url_raw( (string) $link['target_url'] );
		}

		if ( '' === $anchor || '' === $url ) {
			$report[] = array(
				'anchor'   => $anchor,
				'url'      => $url,
				'inserted' => 0,
				'skipped'  => 'missing anchor_text or target',
			);
			continue;
		}

		$count   = 0;
		$quoted  = preg_quote( $anchor, '/' );
		// Don't match mid-word or right after '>', don't match inside a tag, and
		// don't match text already sitting inside an <a>...</a>.
		// Whole words only, never inside a tag or an existing link. The old lookbehind also refused text
		// right after '>', so an anchor that STARTS a paragraph ("<p>Pricing ...") was never linked, and with no
		// trailing boundary "price" matched inside "pricey".
		$pattern = '/(?<!\w)(' . $quoted . ')(?!\w)(?![^<]*>)(?![^<]*<\/a>)/u';

		$result = preg_replace_callback(
			$pattern,
			function ( $m ) use ( $url, &$count ) {
				++$count;
				return '<a href="' . esc_url( $url ) . '">' . $m[1] . '</a>';
			},
			$content,
			$max_per_link
		);

		// DATA LOSS GUARD (V5 F2): preg_replace_callback() returns NULL on a PCRE failure — the /u
		// modifier on content from a legacy latin1 database (PREG_BAD_UTF8_ERROR), or the O(n)
		// lookaheads exhausting pcre.backtrack_limit on a long page with a common anchor. Assigning
		// that NULL back into $content used to propagate an empty body into wp_update_post(), wiping
		// the post. Keep the original content and report the anchor as skipped instead.
		if ( null === $result ) {
			$err       = function_exists( 'preg_last_error_msg' ) ? preg_last_error_msg() : ( 'PCRE error ' . preg_last_error() );
			$report[]  = array(
				'anchor'   => $anchor,
				'url'      => $url,
				'inserted' => 0,
				'skipped'  => 'pattern failed (' . $err . ') — content left unchanged',
			);
			continue;
		}
		$content = $result;

		$report[] = array(
			'anchor'   => $anchor,
			'url'      => $url,
			'inserted' => $count,
		);
	}

	return array( $content, $report );
}

// Taxonomies this connector may read. Allowlist (V5-ext #8): taxonomy_exists() alone let a read
// credential enumerate ANY registered taxonomy, including internal or customer-related ones
// registered by other plugins. Widen deliberately via the option.
function enginekick_mcp_allowed_taxonomies() {
	$raw  = trim( (string) get_option( 'enginekick_mcp_taxonomies', '' ) );
	$list = $raw ? preg_split( '/[\s,]+/', $raw ) : array( 'category', 'post_tag' );
	$out  = array();
	foreach ( (array) $list as $t ) {
		$t = sanitize_key( $t );
		if ( '' !== $t && taxonomy_exists( $t ) && ! in_array( $t, $out, true ) ) { $out[] = $t; }
	}
	return $out ? $out : array( 'category', 'post_tag' );
}

function enginekick_mcp_list_terms( array $args ) {
	$taxonomy = is_array( ( isset( $args['taxonomy'] ) ? $args['taxonomy'] : null ) ) ? '' : sanitize_key( (string) ( ( isset( $args['taxonomy'] ) ? $args['taxonomy'] : 'category' ) ) );
	if ( '' === $taxonomy ) { $taxonomy = 'category'; }
	if ( ! taxonomy_exists( $taxonomy ) ) {
		return new WP_Error( 'bad_request', 'Unknown taxonomy: ' . $taxonomy );
	}
	$allowed = enginekick_mcp_allowed_taxonomies();
	if ( ! in_array( $taxonomy, $allowed, true ) ) {
		return new WP_Error( 'forbidden_taxonomy', 'Taxonomy "' . $taxonomy . '" is not enabled for the connector (allowed: ' . implode( ', ', $allowed ) . ').' );
	}
	$number = min( max( (int) ( ( isset( $args['per_page'] ) ? $args['per_page'] : 100 ) ), 1 ), 200 );

	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => $number,
		)
	);
	if ( is_wp_error( $terms ) ) {
		return $terms;
	}

	$out = array();
	foreach ( $terms as $t ) {
		$link  = get_term_link( $t );
		$out[] = array(
			'id'    => (int) $t->term_id,
			'name'  => $t->name,
			'slug'  => $t->slug,
			'count' => (int) $t->count,
			'link'  => is_wp_error( $link ) ? '' : $link,
		);
	}

	return array(
		'taxonomy' => $taxonomy,
		'terms'    => $out,
	);
}

/* ------------------------------------------------------------------------- *
 * Media / image tool implementations
 * ------------------------------------------------------------------------- */

function enginekick_mcp_list_media( array $args ) {
	$per_page = min( max( (int) ( ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ), 1 ), 100 );
	$ek_bounds = enginekick_mcp_list_bounds( $args, $per_page );   // R8 F10
	if ( is_wp_error( $ek_bounds ) ) {
		return $ek_bounds;
	}
	list( $ek_page, $ek_search ) = $ek_bounds;

	// MIME CLAMP (V5 F4): mime_type went straight into WP_Query, so 'application' listed every
	// private PDF, export and document in the library with its direct URL. The connector's job is
	// images; an operator can widen it deliberately via the enginekick_mcp_media_mimes option.
	// The V5 prefix test (strpos($mime,'image') === 0) was bypassable: WP_Query accepts a
	// comma-separated list and SQL wildcards in post_mime_type, so "image,application/pdf" and
	// "image,%" both began with "image" and then matched far more than images (V5-ext #2). Validate
	// every token exactly instead, and rebuild the value from the validated tokens.
	$widened = enginekick_mcp_widened_mimes();
	$raw     = is_array( ( isset( $args['mime_type'] ) ? $args['mime_type'] : null ) ) ? 'image' : trim( (string) ( ( isset( $args['mime_type'] ) ? $args['mime_type'] : 'image' ) ) );
	if ( '' === $raw ) { $raw = 'image'; }
	$tokens = array();
	foreach ( explode( ',', $raw ) as $tok ) {
		$tok = strtolower( trim( $tok ) );
		if ( '' === $tok ) {
			continue;
		}
		// Exact form only: "image", or "image/<subtype>". No wildcards, no % or _ SQL metacharacters.
		$is_image = ( 'image' === $tok ) || (bool) preg_match( '#^image/[a-z0-9][a-z0-9.+-]*$#', $tok );
		if ( ! $is_image && ! in_array( $tok, $widened, true ) ) {
			return new WP_Error( 'forbidden_mime', 'This connector lists image media only; "' . $tok . '" is not an allowed MIME value.' );
		}
		$tokens[] = $tok;
	}
	if ( ! $tokens ) { $tokens = array( 'image' ); }
	$mime = implode( ',', $tokens );

	$q_args = array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'posts_per_page' => $per_page,
		'paged'          => $ek_page,
		's'              => $ek_search,
		'post_mime_type' => $mime,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	if ( isset( $args['attached_to'] ) ) {
		$q_args['post_parent'] = (int) $args['attached_to'];
	}

	$query    = new WP_Query( $q_args );
	$items    = array();
	$withheld = 0;
	foreach ( $query->posts as $att ) {
		// One consistent attachment policy across list / get / reuse (V5-ext #2): listing used to
		// return whatever the query matched, with no per-object read check, so media belonging to
		// inaccessible content could be enumerated even though get_media() would refuse it.
		if ( is_wp_error( enginekick_mcp_attachment_guard( $att->ID, 'read_post' ) ) ) {
			$withheld++;
			continue;
		}
		$items[] = enginekick_mcp_format_media_summary( $att );
	}

	return array(
		'page'        => max( (int) ( ( isset( $args['page'] ) ? $args['page'] : 1 ) ), 1 ),
		'per_page'    => $per_page,
		'total'       => (int) $query->found_posts,
		'total_pages' => (int) $query->max_num_pages,
		'media'       => $items,
		'withheld'    => $withheld,   // items the access guard removed from this page of results
	);
}

function enginekick_mcp_format_media_summary( $att ) {
	$meta = wp_get_attachment_metadata( $att->ID );
	return array(
		'id'          => (int) $att->ID,
		'title'       => $att->post_title,
		'alt'         => (string) get_post_meta( $att->ID, '_wp_attachment_image_alt', true ),
		'mime'        => $att->post_mime_type,
		'url'         => wp_get_attachment_url( $att->ID ),
		'width'       => isset( $meta['width'] ) ? (int) $meta['width'] : null,
		'height'      => isset( $meta['height'] ) ? (int) $meta['height'] : null,
		'date'        => $att->post_date,
		'attached_to' => (int) $att->post_parent,
	);
}

function enginekick_mcp_get_media( array $args ) {
	$id  = (int) ( ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) );
	// Read guard (V5 F3): an attachment inherits its parent's status, so an unguarded read leaked the
	// metadata and direct URL of media belonging to private or unpublished content.
	$att = enginekick_mcp_attachment_guard( $id, 'read_post' );
	if ( is_wp_error( $att ) ) {
		return $att;
	}

	$meta  = wp_get_attachment_metadata( $id );
	$sizes = array();
	if ( ! empty( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
		foreach ( array_keys( $meta['sizes'] ) as $size ) {
			$src = wp_get_attachment_image_src( $id, $size );
			if ( $src ) {
				$sizes[ $size ] = array(
					'url'    => $src[0],
					'width'  => $src[1],
					'height' => $src[2],
				);
			}
		}
	}

	return array(
		'id'          => $id,
		'title'       => $att->post_title,
		'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
		'caption'     => $att->post_excerpt,
		'description' => $att->post_content,
		'mime'        => $att->post_mime_type,
		'url'         => wp_get_attachment_url( $id ),
		'width'       => isset( $meta['width'] ) ? (int) $meta['width'] : null,
		'height'      => isset( $meta['height'] ) ? (int) $meta['height'] : null,
		'attached_to' => (int) $att->post_parent,
		'sizes'       => $sizes,
	);
}

function enginekick_mcp_update_media( array $args ) {
	$id = (int) ( ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) );
	// Write guard (V5 F3): capability for THIS attachment + the draft-mode live-library refusal.
	// Alt text and captions render on the front end, so editing them IS a live-content change.
	$og = enginekick_mcp_attachment_guard( $id, 'edit_post' );
	if ( is_wp_error( $og ) ) {
		return $og;
	}
	$before_fp = enginekick_mcp_attachment_fingerprint( $id );

	$postarr = array( 'ID' => $id );
	if ( isset( $args['title'] ) ) {
		$postarr['post_title'] = wp_strip_all_tags( $args['title'] );
	}
	if ( isset( $args['caption'] ) ) {
		$postarr['post_excerpt'] = enginekick_mcp_kses_content( $args['caption'] );   // V5-ext #1
	}
	if ( isset( $args['description'] ) ) {
		$postarr['post_content'] = enginekick_mcp_kses_content( $args['description'] );
	}
	if ( count( $postarr ) > 1 ) {
		$res = enginekick_mcp_write_post( $postarr );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
	}
	if ( isset( $args['alt_text'] ) ) {
		$alt = sanitize_text_field( $args['alt_text'] );
		update_post_meta( $id, '_wp_attachment_image_alt', wp_slash( $alt ) );   // meta is unslashed on save (R8 F2); false also means "unchanged", so verify the stored value
		if ( $alt !== (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) {
			enginekick_mcp_note( 'The alt text was not saved.', true );
		}
	}

	enginekick_mcp_audit( 'update_media', 'attachment', $id, $before_fp, enginekick_mcp_attachment_fingerprint( $id ) );

	return enginekick_mcp_get_media( array( 'attachment_id' => $id ) );
}

function enginekick_mcp_upload_media_from_url( array $args ) {
	// Rate-limit media uploads specifically (they are the heaviest tool).
	if ( ! enginekick_rate_ok( 'mcp_media', 20, 60 ) ) {
		return new WP_Error( 'rate_limited', 'Too many media uploads in a short window; try again shortly.' );
	}
	// Capability check (V5-ext #7): media_handle_sideload() is a low-level API and enforces nothing.
	if ( ! current_user_can( 'upload_files' ) ) {
		return new WP_Error( 'forbidden_cap', 'The connector service account cannot upload files.' );
	}

	// Parent guard (V5 F3): attach_to_post arrived unvalidated, so an upload could be parented onto
	// any object on the site — including live content in draft-only mode, and types outside the
	// connector's allowlist. Validate it as an editable post before anything is fetched or written.
	$parent = isset( $args['attach_to_post'] ) ? (int) $args['attach_to_post'] : 0;
	if ( $parent ) {
		$pg = enginekick_mcp_object_guard( $parent, 'edit_post' );
		if ( is_wp_error( $pg ) ) {
			return $pg;
		}
		$lg = enginekick_mcp_guard_live_edit( $parent );
		if ( is_wp_error( $lg ) ) {
			return $lg;
		}
	}

	// DAILY BUDGET (pre-install #3). The per-minute limit alone allowed 20 x 15 MB a minute with no ceiling, so a
	// leaked connector URL could fill the disk. Site-wide per UTC day; generous for editorial use and adjustable
	// with the enginekick_mcp_upload_daily_count / enginekick_mcp_upload_daily_mb options. Refused attempts
	// still count, so the budget cannot be probed for free.
	$max_count = max( 1, (int) get_option( 'enginekick_mcp_upload_daily_count', 100 ) );
	$max_mb    = max( 1, (int) get_option( 'enginekick_mcp_upload_daily_mb', 500 ) );
	$used      = enginekick_counter_hit( 'mcp_upload_count|day', DAY_IN_SECONDS );
	if ( false === $used ) {
		// FAIL CLOSED (V7 #3): without the counter there is no storage ceiling at all, so the upload is
		// refused rather than run unmetered. Read tools are unaffected, and an admin page load repairs the
		// counter table.
		return new WP_Error( 'budget_unavailable', 'Image import is paused: the upload budget counter is unavailable (the rate table is missing). An administrator opening any wp-admin page restores it.' );
	}
	if ( $used > $max_count ) {
		return new WP_Error( 'daily_limit', 'The daily image upload limit (' . $max_count . ' uploads) has been reached. Try again after midnight UTC, or ask the site owner to raise it.' );
	}

	// SSRF-safe fetch: https only, public IP only, pinned, size- and pixel-capped, real image bytes only.
	$fetch = enginekick_mcp_fetch_image( isset( $args['url'] ) ? (string) $args['url'] : '' );
	if ( is_wp_error( $fetch ) ) {
		return $fetch;
	}
	$bytes_used = enginekick_counter_hit( 'mcp_upload_bytes|day', DAY_IN_SECONDS, max( 1, (int) filesize( $fetch['tmp'] ) ) );
	if ( false === $bytes_used || $bytes_used > $max_mb * 1048576 ) {
		@unlink( $fetch['tmp'] );
		return ( false === $bytes_used )
			? new WP_Error( 'budget_unavailable', 'Image import is paused: the upload budget counter is unavailable. An administrator opening any wp-admin page restores it.' )
			: new WP_Error( 'daily_limit', 'This image would exceed the daily upload budget (' . $max_mb . ' MB). Try again after midnight UTC, or ask the site owner to raise it.' );
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$file_array = array(
		'name'     => $fetch['name'],
		'tmp_name' => $fetch['tmp'],
	);
	$title = ( isset( $args['title'] ) ? $args['title'] : '' );

	// Only the four image types may be stored by this sideload (V6 #1). media_handle_sideload() takes no
	// overrides in current WordPress, so the allowed MIME map is narrowed for exactly this call.
	$image_mimes = function () {
		return array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp' );
	};
	add_filter( 'upload_mimes', $image_mimes, PHP_INT_MAX );
	try {
		// Core hands the title to wp_insert_attachment(), which unslashes it (R8 F2).
		$attach_id = media_handle_sideload( $file_array, $parent, '' !== (string) $title ? wp_slash( (string) $title ) : null );
	} finally {
		remove_filter( 'upload_mimes', $image_mimes, PHP_INT_MAX );   // never left narrowed after an exception (R8 F4)
	}
	if ( is_wp_error( $attach_id ) ) {
		if ( file_exists( $fetch['tmp'] ) ) {
			@unlink( $fetch['tmp'] );
		}
		return $attach_id;
	}
	if ( get_post_mime_type( $attach_id ) !== $fetch['mime'] ) {
		wp_delete_attachment( (int) $attach_id, true );
		return new WP_Error( 'bad_type', 'The stored file type did not match the validated image type, so the upload was removed.' );
	}

	enginekick_mcp_uploads_this_request( (int) $attach_id );   // allows metadata edits on it this request
	if ( ! empty( $args['alt_text'] ) ) {
		$alt = sanitize_text_field( $args['alt_text'] );
		update_post_meta( $attach_id, '_wp_attachment_image_alt', wp_slash( $alt ) );   // R8 F2
		if ( $alt !== (string) get_post_meta( $attach_id, '_wp_attachment_image_alt', true ) ) {
			enginekick_mcp_note( 'The image was imported but its alt text was not saved.', true );
		}
	}
	if ( isset( $args['caption'] ) ) {
		$cap = enginekick_mcp_write_post( array( 'ID' => $attach_id, 'post_excerpt' => enginekick_mcp_kses_content( $args['caption'] ) ) );   // V5-ext #1
		if ( ! $cap || is_wp_error( $cap ) ) {
			enginekick_mcp_note( 'The image was imported but its caption was not saved.', true );
		}
	}

	enginekick_mcp_audit( 'upload_media_from_url', 'attachment', (int) $attach_id, null, enginekick_mcp_attachment_fingerprint( (int) $attach_id ) );

	return array(
		'id'          => (int) $attach_id,
		'url'         => wp_get_attachment_url( $attach_id ),
		'attached_to' => $parent,
	);
}

// Undo an upload made earlier in the same tool call when a later step fails (V6 #4: no orphans).
function enginekick_mcp_rollback_upload( $att_id ) {
	$gone = wp_delete_attachment( (int) $att_id, true );
	// Say what actually happened (R8 F12): a failed delete is reported, not described as a removal.
	if ( $gone && ! get_post( (int) $att_id ) ) {
		enginekick_mcp_audit( 'upload_media_from_url', 'rolled_back', (int) $att_id, null, null, false );
		enginekick_mcp_note( 'The image uploaded for this call (attachment #' . (int) $att_id . ') was removed because the rest of the call failed.' );
	} else {
		enginekick_mcp_audit( 'upload_media_from_url', 'rollback_failed', (int) $att_id, null, null, false );
		enginekick_mcp_note( 'The image uploaded for this call (attachment #' . (int) $att_id . ') could NOT be removed after the rest of the call failed; it is still in the media library.', true );
	}
}

function enginekick_mcp_set_featured_image( array $args ) {
	$post_id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	$og = enginekick_mcp_object_guard( $post_id, 'edit_post' );
	if ( is_wp_error( $og ) ) {
		return $og;
	}
	$guard = enginekick_mcp_guard_live_edit( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}

	$att      = (int) ( ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) );
	$uploaded = 0;
	if ( ! $att && ! empty( $args['image_url'] ) ) {
		$up = enginekick_mcp_upload_media_from_url(
			array(
				'url'            => $args['image_url'],
				'attach_to_post' => $post_id,
				'alt_text'       => ( isset( $args['alt_text'] ) ? $args['alt_text'] : '' ),
			)
		);
		if ( is_wp_error( $up ) ) {
			return $up;
		}
		$att      = (int) $up['id'];
		$uploaded = $att;
	}

	if ( ! $att ) {
		return new WP_Error( 'bad_request', 'Provide a valid attachment_id or image_url.' );
	}
	// Reuse guard (V5-ext #2): an existing attachment_id reached set_post_thumbnail() with no access
	// check at all, so a caller could point a post at media it may not read.
	$ag = enginekick_mcp_attachment_guard( $att, 'read_post' );
	if ( is_wp_error( $ag ) ) {
		if ( $uploaded ) {
			enginekick_mcp_rollback_upload( $uploaded );   // R8 F12: never leave this call's upload behind
		}
		return $ag;
	}
	// Must be an image (V5-ext #5). set_post_thumbnail() DELETES the existing thumbnail and returns
	// the delete result when wp_get_attachment_image() is empty — i.e. pointing this at a PDF used to
	// silently strip the post's real featured image while the tool reported success.
	if ( 0 !== strpos( (string) get_post_mime_type( $att ), 'image/' ) ) {
		if ( $uploaded ) {
			enginekick_mcp_rollback_upload( $uploaded );
		}
		return new WP_Error( 'not_an_image', 'Attachment #' . $att . ' is not an image (' . get_post_mime_type( $att ) . '); a featured image must be an image.' );
	}

	$before_fp = enginekick_mcp_post_fingerprint( $post_id );
	// Idempotent (V6 #8): an already-set thumbnail is success. set_post_thumbnail() returns
	// update_post_meta()'s result, which is documented as false for an unchanged value; current core does
	// not actually hit that (the stored "123" never strictly equals the int 123), but a retry must not
	// depend on that detail. A false return is re-checked against what is stored.
	$set_ok = ( (int) get_post_thumbnail_id( $post_id ) === $att )
		|| set_post_thumbnail( $post_id, $att )
		|| ( (int) get_post_thumbnail_id( $post_id ) === $att );
	if ( ! $set_ok ) {
		if ( $uploaded ) {
			enginekick_mcp_rollback_upload( $uploaded );
		}
		enginekick_mcp_audit( 'set_featured_image', 'rejected:thumb_fail', $post_id, $before_fp, null, false );
		return new WP_Error( 'thumbnail_failed', 'WordPress did not set the featured image (attachment #' . $att . ' produced no usable image). The post was left unchanged.' );
	}
	enginekick_mcp_audit( 'set_featured_image', 'post', $post_id, $before_fp, enginekick_mcp_post_fingerprint( $post_id ) );

	return array(
		'post_id'                => $post_id,
		'featured_attachment_id' => $att,
		'url'                    => wp_get_attachment_url( $att ),
	);
}

function enginekick_mcp_add_image_to_post( array $args ) {
	$post_id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	$p       = enginekick_mcp_object_guard( $post_id, 'edit_post' );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$guard = enginekick_mcp_guard_live_edit( $post_id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}

	$before_fp = enginekick_mcp_post_fingerprint( $post_id );
	$att      = (int) ( ( isset( $args['attachment_id'] ) ? $args['attachment_id'] : 0 ) );
	$alt      = ( isset( $args['alt_text'] ) ? $args['alt_text'] : '' );
	$url      = '';
	$uploaded = 0;

	if ( ! $att && ! empty( $args['image_url'] ) ) {
		$up = enginekick_mcp_upload_media_from_url(
			array(
				'url'            => $args['image_url'],
				'attach_to_post' => $post_id,
				'alt_text'       => $alt,
			)
		);
		if ( is_wp_error( $up ) ) {
			return $up;
		}
		$att      = (int) $up['id'];
		$url      = $up['url'];
		$uploaded = $att;
	} elseif ( $att ) {
		// Reuse guard (V5-ext #2): an existing attachment_id was embedded into post content with no
		// access check.
		$ag = enginekick_mcp_attachment_guard( $att, 'read_post' );
		if ( is_wp_error( $ag ) ) {
			return $ag;
		}
		$url = wp_get_attachment_url( $att );
	}

	if ( ! $url ) {
		if ( $uploaded ) {
			enginekick_mcp_rollback_upload( $uploaded );   // R8 F12
			return new WP_Error( 'no_image_url', 'The image was uploaded but WordPress returned no address for it (a storage or CDN plugin may be interfering), so nothing was added to the post.' );
		}
		return new WP_Error( 'bad_request', 'Provide a valid attachment_id or image_url.' );
	}

	$caption = isset( $args['caption'] ) ? esc_html( $args['caption'] ) : '';   // caller-supplied
	$img     = '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '"' . ( $att ? ' class="wp-image-' . $att . '"' : '' ) . '/>';
	$figure  = '<figure class="wp-block-image size-large">' . $img . ( $caption ? '<figcaption class="wp-element-caption">' . $caption . '</figcaption>' : '' ) . '</figure>';
	$attrs   = $att ? ' {"id":' . $att . ',"sizeSlug":"large"}' : ' {"sizeSlug":"large"}';
	$block   = '<!-- wp:image' . $attrs . " -->\n" . $figure . "\n<!-- /wp:image -->";

	$position = ( ( ( isset( $args['position'] ) ? $args['position'] : 'append' ) ) === 'prepend' ) ? 'prepend' : 'append';
	// Sanitise only the block being added, then splice it onto the existing body (V7 #1): passing the whole
	// document through KSES removed embeds and custom blocks the site owner had saved.
	$block    = enginekick_mcp_kses_content( $block );
	$content  = ( 'prepend' === $position ) ? $block . "\n\n" . $p->post_content : $p->post_content . "\n\n" . $block;

	$res = enginekick_mcp_write_post( array( 'ID' => $post_id, 'post_content' => $content ) );
	if ( is_wp_error( $res ) ) {
		if ( $uploaded ) {
			enginekick_mcp_rollback_upload( $uploaded );
		}
		return $res;
	}

	enginekick_mcp_audit( 'add_image_to_post', 'post', $post_id, $before_fp, enginekick_mcp_post_fingerprint( $post_id ) );

	return array(
		'updated'       => true,
		'post_id'       => $post_id,
		'attachment_id' => $att,
		'image_url'     => $url,
		'position'      => $position,
		'link'          => get_permalink( $post_id ),
	);
}

/* ------------------------------------------------------------------------- *
 * Surgical edits that cannot assemble active markup (R8 F1).
 *
 * replace_in_post splices caller text into a body it does not rewrite (so an administrator's iframes and
 * scripts elsewhere survive — V7 #1). Sanitising the fragment alone was not enough: "src=x onerror=alert(1)"
 * has no tag, passes KSES, and becomes an event handler once spliced into an existing <img>. So the check
 * runs on the RESULT: every whole tag the edit touches is filtered at the connector's level, and an edit that
 * filtering would change is refused rather than silently altered.
 * ------------------------------------------------------------------------- */

/**
 * Markup spans in $html as a browser tokenises them: tags (a '>' inside a quoted attribute value does not end
 * the tag), comments, and the raw text inside <script>/<style>. Returns list of array( start, end, type ).
 */
function enginekick_mcp_html_spans( $html ) {
	$spans = array();
	$n     = strlen( $html );
	$i     = 0;
	while ( $i < $n ) {
		$lt = strpos( $html, '<', $i );
		if ( false === $lt ) {
			break;
		}
		if ( '<!--' === substr( $html, $lt, 4 ) ) {
			$end     = strpos( $html, '-->', $lt + 4 );
			$end     = ( false === $end ) ? $n : $end + 3;
			$spans[] = array( $lt, $end, 'comment' );
			$i       = $end;
			continue;
		}
		$next = ( $lt + 1 < $n ) ? $html[ $lt + 1 ] : '';
		if ( ! preg_match( '/[a-zA-Z\/!?]/', $next ) ) {
			$i = $lt + 1;   // a bare "<" in text
			continue;
		}
		$j    = $lt + 1;
		$q    = '';
		$prev = '';
		while ( $j < $n ) {
			$c = $html[ $j ];
			if ( '' !== $q ) {
				if ( $c === $q ) {
					$q = '';
				}
			} elseif ( ( '"' === $c || "'" === $c ) && '=' === $prev ) {
				$q = $c;   // a quoted attribute value starts only right after "="
			} elseif ( '>' === $c ) {
				break;
			}
			if ( ' ' !== $c && "\t" !== $c && "\n" !== $c && "\r" !== $c && "\f" !== $c ) {
				$prev = $c;
			}
			$j++;
		}
		$end     = ( $j < $n ) ? $j + 1 : $n;
		$spans[] = array( $lt, $end, 'tag' );
		if ( preg_match( '/^<(script|style)\b/i', substr( $html, $lt, 8 ), $mm ) ) {
			$close   = stripos( $html, '</' . $mm[1], $end );
			$close   = ( false === $close ) ? $n : $close;
			$spans[] = array( $end, $close, 'raw' );
			$i       = $close;
			continue;
		}
		$i = $end;
	}
	return $spans;
}

/** Tag and attribute names in a fragment, e.g. array( 'img' => array( 'src' => true, 'alt' => true ) ). */
function enginekick_mcp_markup_names( $html, array $protocols ) {
	$names = array();
	if ( preg_match_all( '#<\s*/?\s*([a-zA-Z][a-zA-Z0-9-]*)([^>]*)>?#', (string) $html, $m, PREG_SET_ORDER ) ) {
		foreach ( $m as $t ) {
			$tag = strtolower( $t[1] );
			if ( ! isset( $names[ $tag ] ) ) {
				$names[ $tag ] = array();
			}
			foreach ( array_keys( (array) wp_kses_hair( $t[2], $protocols ) ) as $attr ) {
				$names[ $tag ][ strtolower( $attr ) ] = true;
			}
		}
	}
	return $names;
}

/**
 * Splice $middle between $prefix and $suffix, but only if that cannot create markup the connector may not
 * write. $cut_start / $cut_end are the edit's boundaries in the ORIGINAL body ($prefix . <removed> . $suffix).
 * Returns the new body, or a WP_Error explaining the refusal.
 */
function enginekick_mcp_safe_splice( $original, $cut_start, $cut_end, $prefix, $middle, $suffix ) {
	// 1) An edit may not begin or end inside a comment (a Gutenberg block delimiter, say) or script/style text.
	foreach ( enginekick_mcp_html_spans( $original ) as $sp ) {
		if ( 'tag' === $sp[2] ) {
			continue;
		}
		foreach ( array( $cut_start, $cut_end ) as $p ) {
			$inside = ( 'raw' === $sp[2] ) ? ( $sp[0] <= $p && $p <= $sp[1] && $sp[1] > $sp[0] ) : ( $sp[0] < $p && $p < $sp[1] );
			if ( $inside ) {
				return new WP_Error( 'unsafe_edit_context', 'Refused: this edit starts or ends inside ' . ( 'raw' === $sp[2] ? 'a <script> or <style> block' : 'an HTML comment (for example a block delimiter such as <!-- wp:paragraph -->)' ) . '. Replace the whole comment or block, or choose text outside it. The post was not changed.' );
			}
		}
	}

	// 2) Widen the edited span to every whole tag/comment it touches in the result.
	$result = $prefix . $middle . $suffix;
	$rs     = strlen( $prefix );
	$re     = $rs + strlen( $middle );
	foreach ( enginekick_mcp_html_spans( $result ) as $sp ) {
		if ( 'raw' === $sp[2] ) {
			continue;
		}
		if ( $sp[0] < $rs && $rs < $sp[1] ) {
			$rs = $sp[0];
		}
		if ( $sp[0] < $re && $re < $sp[1] ) {
			$re = $sp[1];
		}
	}
	$region = substr( $result, $rs, $re - $rs );

	// 3) Filter that region at the connector's level, and separately with a pass that allows every tag,
	//    attribute and URL scheme present — which applies the same normalisation (quoting, entities) but removes
	//    nothing. If the two differ, the edit would create something this site does not allow.
	$all_protocols = array_unique( array_merge( wp_allowed_protocols(), array( 'javascript', 'vbscript', 'data', 'livescript', 'mocha', 'file' ) ) );
	$names         = enginekick_mcp_markup_names( $region, $all_protocols );
	$safe          = enginekick_mcp_kses_content( $region );
	$normalised    = wp_kses( $region, $names, $all_protocols );
	if ( $safe !== $normalised ) {
		$kept    = enginekick_mcp_markup_names( $safe, $all_protocols );
		$removed = array();
		foreach ( $names as $tag => $attrs ) {
			if ( ! isset( $kept[ $tag ] ) ) {
				$removed[] = '<' . $tag . '>';
				continue;
			}
			foreach ( array_keys( $attrs ) as $a ) {
				if ( ! isset( $kept[ $tag ][ $a ] ) ) {
					$removed[] = $a;
				}
			}
		}
		$what = $removed ? implode( ', ', array_unique( $removed ) ) : 'a link or URL scheme';
		return new WP_Error( 'unsafe_markup', 'Refused: this edit would create markup this site does not allow (' . $what . '). The post was not changed. Remove that and try again.' );
	}
	return substr( $result, 0, $rs ) . $safe . substr( $result, $re );
}

function enginekick_mcp_replace_in_post( array $args ) {
	$id = (int) ( ( isset( $args['post_id'] ) ? $args['post_id'] : 0 ) );
	$p  = enginekick_mcp_object_guard( $id, 'edit_post' );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$guard = enginekick_mcp_guard_live_edit( $id );
	if ( is_wp_error( $guard ) ) {
		return $guard;
	}
	$before = enginekick_mcp_post_fingerprint( $id );

	$find = enginekick_mcp_decode_field( $args, 'find' );
	if ( is_wp_error( $find ) ) {
		return $find;
	}
	if ( null === $find || '' === $find ) {
		return new WP_Error( 'bad_request', 'A "find" snippet is required (plain find or find_b64).' );
	}

	$new = enginekick_mcp_decode_field( $args, 'new_content' );
	if ( is_wp_error( $new ) ) {
		return $new;
	}
	// Validated in context after the splice (R8 F1): the fragment alone says nothing about what it becomes
	// once it lands inside an existing tag. The rest of the body is never rewritten (V7 #1).
	$new = ( null === $new ) ? '' : (string) $new;
	$position   = in_array( ( ( isset( $args['position'] ) ? $args['position'] : '' ) ), array( 'after', 'before', 'replace' ), true ) ? $args['position'] : 'after';
	$occurrence = max( 1, (int) ( ( isset( $args['occurrence'] ) ? $args['occurrence'] : 1 ) ) );

	$content = $p->post_content;

	// Locate the Nth occurrence of the anchor text.
	$pos    = false;
	$offset = 0;
	for ( $i = 0; $i < $occurrence; $i++ ) {
		$pos = strpos( $content, $find, $offset );
		if ( false === $pos ) {
			break;
		}
		$offset = $pos + strlen( $find );
	}
	if ( false === $pos ) {
		return new WP_Error(
			'not_found',
			'The "find" text was not located in the post' . ( $occurrence > 1 ? ' (occurrence ' . $occurrence . ')' : '' ) . '. Call get_post and copy an exact snippet.'
		);
	}

	if ( 'replace' === $position ) {
		$new_content = enginekick_mcp_safe_splice( $content, $pos, $pos + strlen( $find ), substr( $content, 0, $pos ), $new, substr( $content, $pos + strlen( $find ) ) );
	} elseif ( 'before' === $position ) {
		$new_content = enginekick_mcp_safe_splice( $content, $pos, $pos, substr( $content, 0, $pos ), $new . "\n\n", substr( $content, $pos ) );
	} else { // after
		$end         = $pos + strlen( $find );
		$new_content = enginekick_mcp_safe_splice( $content, $end, $end, substr( $content, 0, $end ), "\n\n" . $new, substr( $content, $end ) );
	}
	if ( is_wp_error( $new_content ) ) {
		enginekick_mcp_audit( 'replace_in_post', 'rejected:unsafe', $id, $before, null, false );
		return $new_content;
	}

	if ( $new_content === $content ) {
		return array(
			'updated' => false,
			'message' => 'The edit produced no change.',
		);
	}

	$res = enginekick_mcp_write_post( array( 'ID' => $id, 'post_content' => $new_content ) );
	if ( is_wp_error( $res ) ) {
		return $res;
	}

	enginekick_mcp_audit( 'replace_in_post', 'post', $id, $before, enginekick_mcp_post_fingerprint( $id ) );

	return array(
		'updated'    => true,
		'post_id'    => $id,
		'position'   => $position,
		'matched_at' => $pos,
		'link'       => get_permalink( $id ),
	);
}

/* ------------------------------------------------------------------------- *
 * Admin page (top-level "EngineKick MCP" menu) + reminder notice
 * ------------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	// Top-level menu so admin-menu managers can't bury it inside Settings.
	// The page lives at admin.php?page=enginekick-mcp.
	add_menu_page(
		'EngineKick MCP',
		'EngineKick MCP',
		'manage_options',
		'enginekick-mcp',
		'enginekick_mcp_settings_page',
		'dashicons-rest-api',
		81
	);
} );

add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$link = esc_url( admin_url( 'admin.php?page=enginekick-mcp' ) );
	// A publish-capable connector is a standing risk: warn on EVERY admin screen (not dismissible)
	// so it is never silently left open.
	if ( 'publish' === enginekick_mcp_mode() ) {
		echo '<div class="notice notice-warning"><p><strong>EngineKick MCP is in PUBLISH mode</strong> — a holder of the connector URL can publish and edit LIVE content. <a href="' . $link . '">Review / lower the mode</a> when you are done.</p></div>';
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && isset( $screen->id ) && false !== strpos( (string) $screen->id, 'enginekick-mcp' ) ) {
		return; // already on the EngineKick MCP page
	}
	echo '<div class="notice notice-info is-dismissible"><p><strong>EngineKick MCP</strong> is active (mode: <code>' . esc_html( enginekick_mcp_mode() ) . '</code>). <a href="' . $link . '">Open the EngineKick MCP page</a> to copy your Claude connector URL or change the mode.</p></div>';
} );

function enginekick_mcp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( isset( $_POST['enginekick_mcp_regen'] ) && check_admin_referer( 'enginekick_mcp_regen' ) ) {
		update_option( ENGINEKICK_MCP_OPTION_TOKEN, enginekick_mcp_generate_token() );
		echo '<div class="notice notice-success is-dismissible"><p>New connector URL generated. Update it in Claude — the old URL no longer works.</p></div>';
	}
	if ( isset( $_POST['enginekick_mcp_security'] ) && check_admin_referer( 'enginekick_mcp_security' ) ) {
		$mode  = isset( $_POST['enginekick_mcp_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['enginekick_mcp_mode'] ) ) : 'draft_write';
		$valid = array( 'off', 'read_only', 'draft_write', 'publish' );
		update_option( 'enginekick_mcp_mode', in_array( $mode, $valid, true ) ? $mode : 'off' );
		$ips = enginekick_sanitize_allowed_ips( wp_unslash( ( isset( $_POST['enginekick_allowed_ips'] ) ? $_POST['enginekick_allowed_ips'] : '' ) ) );
		if ( is_wp_error( $ips ) ) {
			echo '<div class="notice notice-error"><p><strong>IP restriction not saved:</strong> ' . esc_html( $ips->get_error_message() ) . '</p></div>';
		} else {
			update_option( 'enginekick_allowed_ips', $ips );
		}
		if ( isset( $_POST['enginekick_trusted_proxies'] ) ) {
			$proxies = enginekick_sanitize_allowed_ips( wp_unslash( $_POST['enginekick_trusted_proxies'] ) );
			if ( is_wp_error( $proxies ) ) {
				echo '<div class="notice notice-error"><p><strong>Trusted proxies not saved:</strong> ' . esc_html( $proxies->get_error_message() ) . '</p></div>';
			} else {
				update_option( 'enginekick_trusted_proxies', $proxies );
			}
		}
		echo '<div class="notice notice-success is-dismissible"><p>Access mode saved.</p></div>';
	}
	if ( isset( $_POST['enginekick_update_settings'] ) && check_admin_referer( 'enginekick_update_settings' ) && current_user_can( 'update_plugins' ) && function_exists( 'enginekick_update_save_settings' ) ) {
		enginekick_update_save_settings();
	}
	if ( isset( $_POST['enginekick_mcp_authors'] ) && check_admin_referer( 'enginekick_mcp_authors' ) && current_user_can( 'manage_options' ) ) {
		$def   = isset( $_POST['enginekick_mcp_default_author'] ) ? absint( wp_unslash( $_POST['enginekick_mcp_default_author'] ) ) : 0;
		$extra = isset( $_POST['enginekick_mcp_allowed_authors'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['enginekick_mcp_allowed_authors'] ) ) : array();
		$def_u = $def ? get_userdata( $def ) : false;
		if ( $def && ! enginekick_mcp_can_be_author( $def_u ) ) {
			echo '<div class="notice notice-error"><p><strong>Post author not saved:</strong> that person cannot write posts on this site, so posts cannot be credited to them. Choose someone with an Author, Editor or Administrator role.</p></div>';
		} else {
			$keep = array();
			foreach ( array_unique( $extra ) as $uid ) {
				$u = $uid ? get_userdata( $uid ) : false;
				if ( $u && enginekick_mcp_can_be_author( $u ) && $uid !== $def ) {
					$keep[] = $uid;
				}
			}
			update_option( 'enginekick_mcp_default_author', $def, false );
			update_option( 'enginekick_mcp_allowed_authors', $keep, false );
			echo '<div class="notice notice-success is-dismissible"><p>Post author saved. New posts from Claude are credited to <strong>' . esc_html( $def ? enginekick_mcp_author_name( $def ) : 'the EngineKick Service account (no default chosen)' ) . '</strong>.</p></div>';
		}
	}
	if ( isset( $_POST['enginekick_mcp_adopt'] ) && check_admin_referer( 'enginekick_mcp_adopt' ) && current_user_can( 'promote_users' ) ) {
		$r = enginekick_mcp_adopt_service_account();
		if ( $r['id'] > 0 ) {
			update_option( 'enginekick_mcp_svc_ok', '1' );
			echo '<div class="notice notice-success is-dismissible"><p><strong>Account adopted:</strong> ' . esc_html( $r['message'] ) . ' It now holds the EngineKick Service role. It was not created by this plugin, so uninstalling the plugin will not delete it.</p></div>';
		} else {
			echo '<div class="notice notice-error"><p><strong>Could not adopt the account:</strong> ' . esc_html( $r['message'] ) . '</p></div>';
		}
	}
	if ( isset( $_POST['enginekick_mcp_repair'] ) && check_admin_referer( 'enginekick_mcp_repair' ) ) {
		// Runs as the logged-in admin → allowed to create users even when a WAF blocks bot-context REST.
		$r = enginekick_mcp_ensure_service_account( true );
		if ( $r['id'] > 0 ) {
			echo '<div class="notice notice-success is-dismissible"><p><strong>Service account repaired:</strong> ' . esc_html( $r['message'] ) . '</p></div>';
		} else {
			echo '<div class="notice notice-error"><p><strong>Could not repair the service account:</strong> ' . esc_html( $r['message'] ) . '</p></div>';
		}
	}
	if ( isset( $_POST['enginekick_mcp_allow_claude'] ) && check_admin_referer( 'enginekick_mcp_allow_claude' ) ) {
		// Append Claude's egress CIDR to whatever is there, then re-sanitize/dedupe.
		$cur   = trim( (string) get_option( 'enginekick_allowed_ips', '' ) );
		$merged = enginekick_sanitize_allowed_ips( $cur . "\n" . ENGINEKICK_MCP_CLAUDE_IPS );
		if ( is_wp_error( $merged ) ) { $merged = ENGINEKICK_MCP_CLAUDE_IPS; }   // Claude's own range is always valid
		update_option( 'enginekick_allowed_ips', implode( "\n", array_unique( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', $merged ) ) ) ) ) );
		echo '<div class="notice notice-success is-dismissible"><p>Added Claude\'s IP range (<code>' . esc_html( ENGINEKICK_MCP_CLAUDE_IPS ) . '</code>) to the allowlist.</p></div>';
	}

	$mode     = enginekick_mcp_mode();
	$allow_ip = (string) get_option( 'enginekick_allowed_ips', '' );
	$url      = esc_url( enginekick_mcp_endpoint_url() );
	$modes    = array(
		'off'         => 'Off — the MCP endpoint is disabled entirely (logging still works).',
		'read_only'   => 'Read-only — Claude can list/read posts and media, but cannot write anything.',
		'draft_write' => 'Draft-write (recommended) — create and edit drafts; cannot publish or change live content.',
		'publish'     => 'Publish — full write access, including publishing and editing live content.',
	);
	?>
	<div class="wrap">
		<h1>EngineKick MCP Connector</h1>
		<p>Connect this site to Claude (web app or Cowork) so Claude can read every post, create drafts, edit posts, add internal links, and manage your image library. Deleting is intentionally disabled.</p>

		<?php
		// ---- Connection self-test: every gate a Claude write passes through, GREEN/RED. ----
		$svc       = enginekick_mcp_ensure_service_account( false );
		$svc_ok    = $svc['id'] > 0;
		$has_token = (bool) get_option( ENGINEKICK_MCP_OPTION_TOKEN );
		$mode_now  = enginekick_mcp_mode();
		$writeable = in_array( $mode_now, array( 'draft_write', 'publish' ), true );
		$allow_raw = trim( (string) get_option( 'enginekick_allowed_ips', '' ) );
		if ( '' !== $allow_raw ) {
			$allow_raw = enginekick_mcp_upgrade_claude_range( $allow_raw );
		}
		$allow_list = $allow_raw ? array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', $allow_raw ) ) ) ) : array();
		$ek_upg     = get_option( 'enginekick_mcp_claude_range_upgraded' );
		if ( is_array( $ek_upg ) && time() - (int) $ek_upg['time'] < 30 * DAY_IN_SECONDS ) {
			echo '<div class="notice notice-info"><p><strong>Updated Claude\'s IP range.</strong> The IP allowlist allowed only part of the addresses Claude calls from (<code>' . esc_html( str_replace( "\n", ', ', (string) $ek_upg['before'] ) ) . '</code>), so some of Claude\'s calls were refused and Claude showed &ldquo;Reconnect&rdquo;. Anthropic publishes <code>' . esc_html( ENGINEKICK_MCP_CLAUDE_IPS ) . '</code> for Claude\'s MCP calls; it was added ' . esc_html( human_time_diff( (int) $ek_upg['time'] ) ) . ' ago. Nothing else in the allowlist changed.</p></div>';
		}
		// "Ready" describes what is CONFIGURED here (V7 #10). It never claimed to, and cannot, prove that a
		// provider's whole egress range is allowed: the old version probed five hard-coded addresses, which
		// missed .37 of the documented .34-.39 span and could report success while another address was blocked.
		$all_green = $svc_ok && $has_token && $writeable;
		// One row of the status table: a state icon, a label and an explanation.
		$ek_row = function ( $ok, $label, $detail, $warn = false ) {
			$icon = $ok ? '<span style="color:#1a7f37;font-weight:700;">&#10003; OK</span>'
				: ( $warn ? '<span style="color:#996b00;font-weight:700;">&#9888; Check</span>' : '<span style="color:#b32d2e;font-weight:700;">&#10007; Fix</span>' );
			echo '<tr><td style="padding:6px 14px 6px 0;white-space:nowrap;vertical-align:top;">' . $icon . '</td><td style="padding:6px 14px 6px 0;font-weight:600;vertical-align:top;white-space:nowrap;">' . esc_html( $label ) . '</td><td style="padding:6px 0;color:#444;">' . wp_kses_post( $detail ) . '</td></tr>';
		};
		?>
		<h2 style="margin-top:6px;">Connection status</h2>
		<div style="margin:8px 0 20px;padding:12px 16px;background:#fff;border:1px solid #ccd0d4;max-width:900px;border-left:4px solid <?php echo $all_green ? '#1a7f37' : '#b32d2e'; ?>;">
			<table style="border-collapse:collapse;"><tbody>
			<?php
			$ek_row( $has_token, 'Connector URL', $has_token ? 'Secret is set. The URL below is live.' : 'No secret yet — reload this page to generate one.' );
			$ek_row( true, 'Access mode', 'Current mode: <code>' . esc_html( $mode_now ) . '</code>' . ( $writeable ? ' (writes allowed).' : ' — <strong>Claude cannot write in this mode.</strong> Set Draft-write or Publish below.' ), ! $writeable );
			// Served through a proxy/CDN with no trusted proxies configured: every IP decision sees the proxy.
			if ( ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) || ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) && ! enginekick_trusted_proxies() ) {
				$ek_row( false, 'Proxy / CDN', 'This page reached WordPress through a proxy or CDN (forwarding headers are present), but no trusted proxies are configured, so the IP allowlist, rate limits and audit log see the proxy (<code>' . esc_html( (string) ( ( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '' ) ) ) . '</code>) rather than the real client. Add the CDN or load balancer ranges under <strong>Trusted proxies</strong> below before relying on the allowlist.', true );
			}
			if ( ! $allow_list ) {
				$ek_row( true, 'IP allowlist', 'Empty — all IPs allowed. Claude will always reach the endpoint.' );
			} else {
				$ek_covers = enginekick_mcp_list_covers_claude( $allow_list );
				$ek_row( $ek_covers, 'IP allowlist', 'Requests are accepted only from: <code>' . esc_html( implode( '</code>, <code>', $allow_list ) ) . '</code>. '
					. ( $ek_covers
						? 'This covers all of Claude&rsquo;s published address range (<code>' . esc_html( ENGINEKICK_MCP_CLAUDE_IPS ) . '</code>).'
						: 'This does <strong>not</strong> include all of Claude&rsquo;s published address range (<code>' . esc_html( ENGINEKICK_MCP_CLAUDE_IPS ) . '</code>). Calls from the rest get a 403, which Claude shows as &ldquo;Reconnect&rdquo;. Use the button below.' ), true );
			}
			$ek_def = (int) get_option( 'enginekick_mcp_default_author', 0 );
			$ek_row( $ek_def && enginekick_mcp_can_be_author( get_userdata( $ek_def ) ), 'Post author', $ek_def
				? 'New posts are credited to <strong>' . esc_html( enginekick_mcp_author_name( $ek_def ) ) . '</strong>' . ( enginekick_mcp_can_be_author( get_userdata( $ek_def ) ) ? '.' : ' &mdash; who can no longer write posts. Choose someone else below.' )
				: 'Not chosen &mdash; posts Claude creates are credited to the EngineKick Service account. Choose a default author below.', true );
			$ek_row( $svc_ok, 'Service account', $svc_ok
				? 'Ready (user #' . (int) $svc['id'] . '). Writes attribute here — <code>rejected:no_service</code> is resolved.'
				: '<strong>' . esc_html( $svc['message'] ) . '</strong> This is the cause of <code>rejected:no_service</code> in the audit log.' );
			?>
			</tbody></table>
			<div style="margin-top:12px;">
				<?php if ( 'unadopted' === $svc['status'] ) : ?>
					<form method="post" style="display:inline-block;margin-right:10px;">
						<?php wp_nonce_field( 'enginekick_mcp_adopt' ); ?>
						<button type="submit" name="enginekick_mcp_adopt" value="1" class="button button-primary"
							onclick="return confirm('Run Claude\'s edits as the existing enginekick-service account? It will be moved to the EngineKick Service role.');">Adopt this account</button>
					</form>
				<?php elseif ( ! $svc_ok ) : ?>
					<form method="post" style="display:inline-block;margin-right:10px;">
						<?php wp_nonce_field( 'enginekick_mcp_repair' ); ?>
						<button type="submit" name="enginekick_mcp_repair" value="1" class="button button-primary">Repair service account</button>
					</form>
				<?php endif; ?>
				<?php if ( $allow_list ) : ?>
					<form method="post" style="display:inline-block;">
						<?php wp_nonce_field( 'enginekick_mcp_allow_claude' ); ?>
						<button type="submit" name="enginekick_mcp_allow_claude" value="1" class="button">Allow Claude&rsquo;s IP range</button>
					</form>
				<?php endif; ?>
				<?php if ( $all_green ) : ?>
					<span style="color:#1a7f37;font-weight:600;">Configuration looks right — the token, mode and service account are all set. Connectivity from Claude is not tested here: if Claude shows &ldquo;reconnect&rdquo;, check the IP allowlist row above, then remove and re-add the connector using the URL below.</span>
				<?php endif; ?>
			</div>
		</div>

		<h2>Post author</h2>
		<p>Claude's edits run through the EngineKick Service account, but published posts should carry a real person's name. Choose who new posts are credited to, and who else Claude may credit when asked. Nobody outside this list can be named, even by someone holding the connector URL.</p>
		<form method="post" style="margin:10px 0 22px;padding:14px 16px;background:#fff;border:1px solid #ccd0d4;max-width:760px;">
			<?php
			wp_nonce_field( 'enginekick_mcp_authors' );
			// Everyone whose role can write posts (role-based, so it works back to WordPress 5.0), minus the
			// service account. Capped so a site with thousands of writers still renders.
			$ek_roles = array();
			foreach ( wp_roles()->roles as $ek_role => $ek_def_role ) {
				if ( ! empty( $ek_def_role['capabilities']['edit_posts'] ) ) {
					$ek_roles[] = $ek_role;
				}
			}
			$ek_people = $ek_roles ? get_users( array( 'role__in' => $ek_roles, 'orderby' => 'display_name', 'number' => 300 ) ) : array();
			$ek_people = array_filter( $ek_people, function ( $u ) {
				return enginekick_mcp_service_login() !== $u->user_login;
			} );
			$ek_cur_def   = (int) get_option( 'enginekick_mcp_default_author', 0 );
			$ek_cur_extra = array_map( 'intval', (array) get_option( 'enginekick_mcp_allowed_authors', array() ) );
			?>
			<p><label for="enginekick_mcp_default_author"><strong>Credit new posts to</strong></label><br>
				<select name="enginekick_mcp_default_author" id="enginekick_mcp_default_author">
					<option value="0"<?php selected( 0, $ek_cur_def ); ?>>&mdash; not chosen (EngineKick Service) &mdash;</option>
					<?php foreach ( $ek_people as $ek_u ) : ?>
						<option value="<?php echo (int) $ek_u->ID; ?>"<?php selected( (int) $ek_u->ID, $ek_cur_def ); ?>><?php echo esc_html( $ek_u->display_name . ' (' . $ek_u->user_login . ')' ); ?></option>
					<?php endforeach; ?>
				</select></p>
			<p><strong>Claude may also credit</strong> <span class="description">(when you ask it to put a post under someone else's name)</span></p>
			<?php foreach ( $ek_people as $ek_u ) : ?>
				<label style="display:block;margin:2px 0;"><input type="checkbox" name="enginekick_mcp_allowed_authors[]" value="<?php echo (int) $ek_u->ID; ?>"<?php checked( in_array( (int) $ek_u->ID, $ek_cur_extra, true ) ); ?>> <?php echo esc_html( $ek_u->display_name . ' (' . $ek_u->user_login . ')' ); ?></label>
			<?php endforeach; ?>
			<p><button type="submit" name="enginekick_mcp_authors" value="1" class="button button-primary">Save post author</button></p>
		</form>

		<?php
		$ek_ref = get_option( 'enginekick_mcp_refusals', array() );
		$ek_ref = is_array( $ek_ref ) ? $ek_ref : array();
		?>
		<?php
		$ek_h   = get_option( 'enginekick_mcp_health', array() );
		$ek_h   = is_array( $ek_h ) ? $ek_h : array();
		$ek_ok        = 0;
		$ek_refused_n = 0;   // a count — $ek_ref (below) is the refusal LIST
		foreach ( (array) ( ( isset( $ek_h['days'] ) ? $ek_h['days'] : array() ) ) as $ek_day ) {
			$ek_ok        += (int) ( ( isset( $ek_day['ok'] ) ? $ek_day['ok'] : 0 ) );
			$ek_refused_n += (int) ( ( isset( $ek_day['refused'] ) ? $ek_day['refused'] : 0 ) );
		}
		?>
		<h2>Connection health</h2>
		<p>This connector never expires: the connector URL stays valid until you generate a new one below, and nothing in this plugin disconnects Claude on a schedule.
			<?php if ( ! empty( $ek_h['last_ok'] ) ) : ?>
				<strong>Claude last connected <?php echo esc_html( human_time_diff( (int) $ek_h['last_ok'] ) ); ?> ago.</strong>
			<?php else : ?>
				<strong>No successful connection has been recorded yet</strong> (recording started with plugin 1.16).
			<?php endif; ?>
			Last 7 days: <strong><?php echo (int) $ek_ok; ?></strong> connections, <strong><?php echo (int) $ek_refused_n; ?></strong> refused.
			If Claude shows &ldquo;Reconnect&rdquo; and the list below is empty, the call never reached WordPress &mdash; look at the host&rsquo;s firewall, Cloudflare or a security plugin.</p>
		<?php
		if ( function_exists( 'enginekick_update_settings_box' ) ) {
			enginekick_update_settings_box();
		}
		?>

		<h2>Recent refused connections</h2>
		<?php if ( ! $ek_ref ) : ?>
			<p>None recorded. If Claude shows &ldquo;Reconnect&rdquo; for this site and nothing appears here after it tries again, the call never reached WordPress &mdash; look at the host&rsquo;s firewall, Cloudflare or a security plugin.</p>
		<?php else : ?>
			<p>Why the most recent calls to the connector were turned away. This is what &ldquo;Reconnect&rdquo; in Claude means for this site.</p>
			<table class="widefat striped" style="max-width:900px;margin-bottom:22px;"><thead><tr><th style="width:130px;">When</th><th style="width:140px;">From</th><th>Reason</th></tr></thead><tbody>
			<?php foreach ( $ek_ref as $ek_e ) : ?>
				<tr><td><?php echo esc_html( human_time_diff( (int) $ek_e['t'] ) . ' ago' ); ?></td><td><code><?php echo esc_html( (string) $ek_e['ip'] ); ?></code></td><td><?php echo wp_kses_post( enginekick_mcp_refusal_text( (string) $ek_e['reason'] ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<h2>Security &amp; access mode</h2>
		<p>The connector URL is a password: anyone who has it can act on your site within the mode below. Lock it down here.</p>
		<form method="post" style="margin:10px 0 22px;padding:14px 16px;background:#fff;border:1px solid #ccd0d4;max-width:760px;">
			<?php wp_nonce_field( 'enginekick_mcp_security' ); ?>
			<p><strong>Access mode</strong></p>
			<?php foreach ( $modes as $key => $label ) : ?>
				<label style="display:block;margin:4px 0;">
					<input type="radio" name="enginekick_mcp_mode" value="<?php echo esc_attr( $key ); ?>" <?php checked( $mode, $key ); ?> />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
			<p style="margin-top:14px;"><strong>Restrict to these IPs / CIDR ranges</strong> (one per line or comma-separated; leave blank to allow any IP). Applies to the MCP endpoint <em>and</em> the crawl/changes export endpoints.</p>
			<textarea name="enginekick_allowed_ips" rows="3" style="width:100%;font-family:monospace;" placeholder="e.g. 203.0.113.5&#10;198.51.100.0/24"><?php echo esc_textarea( $allow_ip ); ?></textarea>
			<p style="margin-top:14px;"><strong>Trusted proxies</strong> — only if this site sits behind a CDN (e.g. Cloudflare) or a load balancer: list <em>its</em> IP ranges so the allowlist, rate limits and audit log see the real visitor instead of the proxy. Leave blank otherwise. Never list ranges you do not control: a trusted proxy's forwarding header is believed.</p>
			<textarea name="enginekick_trusted_proxies" rows="3" style="width:100%;font-family:monospace;" placeholder="e.g. 173.245.48.0/20&#10;2400:cb00::/32"><?php echo esc_textarea( (string) get_option( 'enginekick_trusted_proxies', '' ) ); ?></textarea>
			<p><button type="submit" name="enginekick_mcp_security" value="1" class="button button-primary">Save security settings</button>
			<span style="margin-left:8px;color:#555;">Current mode: <code><?php echo esc_html( $mode ); ?></code></span></p>
		</form>

		<h2>Your connector URL</h2>
		<p><strong>Treat this URL like a password.</strong> Rotate it below if it may have leaked; the old URL stops working immediately.</p>
		<input type="text" readonly value="<?php echo $url; ?>" onclick="this.select();" style="width:100%;max-width:760px;padding:8px;font-family:monospace;" />

		<form method="post" style="margin-top:12px;">
			<?php wp_nonce_field( 'enginekick_mcp_regen' ); ?>
			<button type="submit" name="enginekick_mcp_regen" value="1" class="button"
				onclick="return confirm('Generate a new URL? The current one will stop working until you update it in Claude.');">
				Regenerate URL (rotate secret)
			</button>
		</form>

		<h2 style="margin-top:28px;">Connect it in Claude</h2>
		<ol>
			<li>In Claude, go to <strong>Customize → Connectors</strong> and click the <strong>＋</strong>.</li>
			<li>Choose <strong>Add custom connector</strong>, paste the URL above, and click <strong>Add</strong>. Leave OAuth fields blank.</li>
			<li>Open a chat (or Cowork), enable the connector from the tools menu, and try: <em>"List my 10 most recent posts."</em></li>
		</ol>

		<h2 style="margin-top:28px;">What Claude can do</h2>
		<ul style="list-style:disc;margin-left:20px;">
			<li><code>list_posts</code> / <code>get_post</code> — read every post (paginated).</li>
			<li><code>create_post</code> — create posts/pages (defaults to draft).</li>
			<li><code>update_post</code> — edit posts (cannot trash/delete).</li>
			<li><code>add_internal_links</code> — insert internal links into a post.</li>
			<li><code>list_media</code> / <code>get_media</code> — browse and read the image library.</li>
			<li><code>update_media</code> — fix alt text, captions, titles (great for SEO).</li>
			<li><code>upload_media_from_url</code> — add an image from a URL.</li>
			<li><code>set_featured_image</code> / <code>add_image_to_post</code> — set featured images and place images in posts.</li>
			<li><code>replace_in_post</code> — surgical edits (find a snippet, insert/replace) without resending the whole body.</li>
			<li><code>list_terms</code> / <code>get_site_info</code> — categories/tags and site basics.</li>
		</ul>

		<h2 style="margin-top:28px;">Recent MCP writes (audit log)</h2>
		<?php
		global $wpdb;
		$atable   = enginekick_mcp_audit_table();
		$missing  = enginekick_schema_missing();   // shared with admin_init: no extra metadata queries (V6 #11)
		$have_chg = ! in_array( 'column:changes', $missing, true );
		$cols     = 'ts, tool, object_type, object_id, remote_ip, before_status, after_status' . ( $have_chg ? ', changes' : '' );
		$arows    = ! in_array( 'table:enginekick_mcp_audit', $missing, true )
			? $wpdb->get_results( "SELECT $cols FROM $atable ORDER BY id DESC LIMIT 30", ARRAY_A )
			: array();
		if ( ! is_array( $arows ) ) {
			$arows = array();
		}
		if ( $arows ) {
			echo '<table class="widefat striped" style="max-width:1100px;"><thead><tr><th>When (UTC)</th><th>Tool</th><th>Object</th><th>What changed</th><th>IP</th></tr></thead><tbody>';
			foreach ( $arows as $r ) {
				$statuses = trim( (string) $r['before_status'] . ' → ' . (string) $r['after_status'], ' →' );
				// The "little details" — the human-readable change lines. Fall back to the status
				// transition (e.g. draft → publish) or the rejection reason carried in object_type.
				$detail = '';
				if ( ! empty( $r['changes'] ) ) {
					$lines = json_decode( (string) $r['changes'], true );
					if ( is_array( $lines ) && $lines ) {
						$detail = '<ul style="margin:2px 0;padding-left:16px;">';
						foreach ( $lines as $ln ) {
							$detail .= '<li>' . esc_html( (string) $ln ) . '</li>';
						}
						$detail .= '</ul>';
					}
				}
				if ( '' === $detail ) {
					if ( 0 === strpos( (string) $r['object_type'], 'rejected:' ) || in_array( $r['object_type'], array( 'error', 'exception' ), true ) ) {
						$detail = '<span style="color:#b32d2e;">' . esc_html( str_replace( 'rejected:', 'rejected — ', (string) $r['object_type'] ) ) . '</span>';
					} elseif ( '' !== $statuses ) {
						$detail = esc_html( $statuses );
					} else {
						$detail = '<span style="color:#777;">—</span>';
					}
				}
				echo '<tr><td style="white-space:nowrap;">' . esc_html( $r['ts'] ) . '</td><td><code>' . esc_html( $r['tool'] ) . '</code></td><td style="white-space:nowrap;">' . esc_html( $r['object_type'] . ' #' . $r['object_id'] ) . '</td><td style="font-size:12px;">' . $detail . '</td><td>' . esc_html( $r['remote_ip'] ) . '</td></tr>';
			}
			echo '</tbody></table>';
			echo '<p class="description">Every MCP write (success <em>and</em> failure) with the EXACT change — internal links added (with targets), featured/inline images set, title/status/alt-text edits, word-count deltas — plus tool, object and source IP. Separate from human admin edits (made as your own user). Scope: MCP content/media writes only. Ordinary DB rows (not tamper-evident); for that, ship them to append-only external storage.' . ( $have_chg ? '' : ' <strong>Reload this page once</strong> to finish adding the change-detail column, then new writes show the details.' ) . '</p>';
		} else {
			echo '<p class="description">No MCP writes recorded yet. Once Claude edits something, it appears here with the exact change (links, images, title, status), the tool, object, and source IP.</p>';
		}
		?>

		<h2 style="margin-top:28px;">If Claude can't connect</h2>
		<p>Start with the <strong>Connection status</strong> box at the top — it flags the exact gate that is failing. The three things that cause the recurring errors:</p>
		<ul style="list-style:disc;margin-left:20px;max-width:900px;">
			<li><strong>&ldquo;Reconnect / authentication required&rdquo; popup in Claude</strong> — usually the <em>IP allowlist</em> doesn&rsquo;t cover all of Claude&rsquo;s egress IPs (it rotates across <code>160.79.106.34&ndash;.39</code>). Requests from an uncovered IP get a 403 and Claude asks you to reconnect. Fix: use <strong>Allow Claude&rsquo;s IP range</strong> above, or clear the allowlist.</li>
			<li><strong><code>rejected:no_service</code> in the audit log</strong> — the least-privilege service account is missing or unmarked. This happens when a WAF/security plugin (e.g. Wordfence) blocks user creation during Claude&rsquo;s request. Fix: click <strong>Repair service account</strong> above (it creates the user as you, in wp-admin, where the WAF doesn&rsquo;t block it).</li>
			<li><strong>Endpoint unreachable at all</strong> — a security plugin or WAF is blocking <code>/wp-json/</code> or unauthenticated REST, or the site isn&rsquo;t on HTTPS. Paste the connector URL into a browser: a valid endpoint returns a small JSON error about a missing request, which means it&rsquo;s alive. If Wordfence is installed, allowlist <code>160.79.106.0/24</code> and exclude <code>/wp-json/enginekick-mcp/</code> from rate-limiting.</li>
		</ul>
	</div>
	<?php
}

} // end if ! defined( 'ENGINEKICK_MCP_VERSION' )

/* ------------------------------------------------------------------------- *
 * WordPress 5.0-5.6 compatibility (generated by tools/downlevel-legacy.php).
 * Backports of two functions WordPress added in 5.7, guarded so a newer core always wins.
 * ------------------------------------------------------------------------- */
if ( ! function_exists( 'is_post_status_viewable' ) ) {
	function is_post_status_viewable( $post_status ) {
		if ( is_scalar( $post_status ) ) {
			$post_status = get_post_status_object( $post_status );
			if ( ! $post_status ) {
				return false;
			}
		}
		if ( ! is_object( $post_status ) || $post_status->internal || $post_status->protected ) {
			return false;
		}
		return (bool) ( $post_status->publicly_queryable || ( $post_status->_builtin && $post_status->public ) );
	}
}
if ( ! function_exists( 'is_post_publicly_viewable' ) ) {
	function is_post_publicly_viewable( $post = null ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return false;
		}
		$post_type   = get_post_type( $post );
		$post_status = get_post_status( $post );
		return is_post_type_viewable( $post_type ) && is_post_status_viewable( $post_status );
	}
}
