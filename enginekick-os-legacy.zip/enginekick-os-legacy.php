<?php
/**
 * Plugin Name:       EngineKick OS (Legacy)
 * Description:        ONE plugin per site: crawler/AI-bot logging + content-change tracking, PULL model
 *                     (Northstar fetches from these authenticated REST endpoints; no Cloudflare tunnel
 *                     needed — nothing is auto-sent to EngineKick). Logs AI/search-bot hits, and
 *                     add/update/status-change/delete for the tracked post types only — posts and
 *                     pages by default (NOT orders, form entries or other custom post types, and NOT
 *                     settings, users, plugins or arbitrary WordPress actions). Logging runs on the
 *                     shutdown hook so it does not delay rendering, but it still holds a PHP worker
 *                     and costs database time. Deleting site content is NOT performed by this plugin.
 * Version:           1.16.1-legacy
 * Requires at least: 5.0
 * Requires PHP:      5.6
 * Author:            EngineKick
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       enginekick-os
 * Update URI:        false
 *
 * SETUP (wp-config.php), or it auto-generates a secret you can read in Settings → EngineKick:
 *   define('ENGINEKICK_SECRET', '<long-random-string>');   // the URL secret Northstar uses
 *   define('ENGINEKICK_CLIENT_SLUG', 'linkilo');           // which EngineKick client this site is
 *
 * Northstar pulls:
 *   GET /wp-json/enginekick/v1/<SECRET>/crawl-log?since=YYYY-MM-DD&limit=50000
 *   GET /wp-json/enginekick/v1/<SECRET>/changes?since=YYYY-MM-DD
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// DOUBLE-LOAD GUARD + CONTROLLED UPGRADE PATH (V5 #12, V5-ext #12). Copies of this plugin have shipped
// under different folder names with the same global function names, so two installed copies fataled
// with "Cannot redeclare enginekick_secret()". Detect another loaded copy by the CONSTANT (a 1.5+
// copy) OR the FUNCTION (a pre-1.5 copy has no constant — testing only the constant protected nothing
// against the older copy it was written for). A silent bail would leave the OLDER, unpatched copy in
// charge unnoticed, so this copy instead: (1) refuses its own activation with an explanation, which
// forces the old copy to be retired first, and (2) shows administrators a persistent notice naming the
// other copy's file. Closures only — a named function declared here would itself risk redeclaration.
//
// Known limit: if THIS copy loads first and an old pre-1.7 copy loads second, the old copy fatals on
// its own function declarations; nothing in this file can intercept that. The notice and activation
// block exist to stop sites reaching that state. Upgrade = deactivate + delete the old copy, then
// activate this one.
if ( defined( 'ENGINEKICK_CONNECTOR_LOADED' ) || function_exists( 'enginekick_secret' ) ) {
	$ek_other = 'another EngineKick copy';
	if ( function_exists( 'enginekick_secret' ) ) {
		try {
			$ek_ref   = new ReflectionFunction( 'enginekick_secret' );
			$ek_other = (string) $ek_ref->getFileName();
		} catch ( ReflectionException $e ) {
			$ek_other = 'another EngineKick copy';
		}
	}
	$ek_self = __FILE__;
	register_activation_hook( __FILE__, function () use ( $ek_other ) {
		wp_die(
			'<h1>EngineKick OS was not activated</h1><p>Another EngineKick copy is already active on this site:</p><p><code>'
				. esc_html( $ek_other ) . '</code></p><p>Deactivate <strong>and delete</strong> that copy on the Plugins screen first, then activate this one. Running two copies side by side leaves the older, unpatched code in charge.</p>',
			'EngineKick OS - duplicate copy',
			array( 'back_link' => true )
		);
	} );
	add_action( 'admin_notices', function () use ( $ek_other, $ek_self ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>Two EngineKick copies are installed.</strong> The copy in charge is <code>'
			. esc_html( $ek_other ) . '</code>; the copy at <code>' . esc_html( $ek_self )
			. '</code> is inactive until the other one is deactivated and deleted. Remove the older copy.</p></div>';
	} );
	return;
}
// EVERYTHING BELOW IS INSIDE THIS BLOCK, and that is what makes the guard above work. PHP binds a
// file's unconditional top-level function declarations when the file is COMPILED, before its first
// line runs. So (a) function_exists( 'enginekick_secret' ) was already true at the top of this very
// file and the 1.6 guard bailed on every load, leaving the plugin inert; and (b) a second copy
// fataled with "Cannot redeclare" at compile time, before any guard line could execute. Functions
// declared inside a block are bound only when the block runs. Same pattern as the MCP module.
if ( ! defined( 'ENGINEKICK_CONNECTOR_LOADED' ) ) {
define( 'ENGINEKICK_CONNECTOR_LOADED', '1.16.1-legacy' );

// Bundled MCP content server (lets Claude read/create/edit posts, links, media on this site). One
// plugin, two jobs: logging (below) + Claude content (the MCP module). The module is REQUIRED: it owns
// the shared security helpers (client IP, IP allowlist, atomic rate limiter). The previous standalone
// fallback duplicated those helpers here, never ran in the shipped package, and had drifted: its rate
// limiter still carried the bug fixed in V5-ext #9. An incomplete package now refuses to run.
if ( ! file_exists( __DIR__ . '/enginekick-mcp.php' ) ) {
	register_activation_hook( __FILE__, function () {
		wp_die( '<h1>EngineKick OS package is incomplete</h1><p><code>enginekick-mcp.php</code> is missing from the plugin folder. Reinstall from the official package.</p>', 'EngineKick OS', array( 'back_link' => true ) );
	} );
	add_action( 'admin_notices', function () {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p><strong>EngineKick OS is disabled:</strong> <code>enginekick-mcp.php</code> is missing from the plugin folder. Reinstall from the official package.</p></div>';
		}
	} );
	return;
}
require_once __DIR__ . '/enginekick-mcp.php';

define( 'ENGINEKICK_DB_VERSION', '5' );   // 5: changes.request_id, so audit detail belongs to one change

/* ---------------------------------------------------------------------------
 * Config helpers
 * ------------------------------------------------------------------------- */
function enginekick_secret() {
	if ( defined( 'ENGINEKICK_SECRET' ) && ENGINEKICK_SECRET ) { return (string) ENGINEKICK_SECRET; }
	$s = get_option( 'enginekick_secret' );
	if ( ! $s ) { $s = wp_generate_password( 40, false, false ); add_option( 'enginekick_secret', $s, '', false ); }   // not autoloaded
	return (string) $s;
}
function enginekick_slug() {
	if ( defined( 'ENGINEKICK_CLIENT_SLUG' ) && ENGINEKICK_CLIENT_SLUG ) { return (string) ENGINEKICK_CLIENT_SLUG; }
	return (string) get_option( 'enginekick_client_slug', '' );
}
function enginekick_crawl_table()   { global $wpdb; return $wpdb->prefix . 'enginekick_crawl'; }
/**
 * Redact credential-shaped path segments before a path is stored in the crawl log (V5-ext #3). Belt to
 * the REST-request exclusion: any segment of 24+ unbroken alphanumerics is treated as a secret (URL
 * slugs contain hyphens), and this site's own live secrets are removed outright wherever they appear.
 */
function enginekick_redact_path( $uri ) {
	$uri = (string) preg_replace( '#/[A-Za-z0-9]{24,}(?=/|$)#', '/[redacted]', (string) $uri );
	// A secret can only appear inside a run of 24+ alphanumerics; skip the (no longer autoloaded) option reads
	// for the ordinary paths every bot request carries.
	if ( ! preg_match( '/[A-Za-z0-9]{24,}/', $uri ) ) {
		return $uri;
	}
	foreach ( array( get_option( 'enginekick_mcp_token', '' ), get_option( 'enginekick_secret', '' ) ) as $sek ) {
		if ( is_string( $sek ) && strlen( $sek ) > 15 && false !== strpos( $uri, $sek ) ) {
			$uri = str_replace( $sek, '[redacted]', $uri );
		}
	}
	return $uri;
}
function enginekick_changes_table() { global $wpdb; return $wpdb->prefix . 'enginekick_changes'; }
/**
 * Crawl-log values come straight from anonymous visitors: any client can put markup in its User-Agent or in
 * the path it requests, and those rows are exported to Northstar and shown in the EngineKick dashboard
 * (pre-install #4). Clean them where they enter: percent-encode every path byte outside the URL-safe set
 * (so "<script>" is stored as "%3Cscript%3E"), and strip control characters, angle brackets, quotes and
 * backticks from User-Agents. Ordinary paths and real bot User-Agents are unchanged.
 */
function enginekick_clean_crawl_path( $path ) {
	return (string) preg_replace_callback( '#[^A-Za-z0-9\-._~!$&()*+,;=:@/%?]#', function ( $m ) { return rawurlencode( $m[0] ); }, (string) $path );
}
function enginekick_clean_crawl_ua( $ua ) {
	return (string) preg_replace( '/[\x00-\x1F\x7F<>"\'`]/', '', (string) $ua );
}

/* ---------------------------------------------------------------------------
 * Tables (created on activation; self-healed in admin only — never on the front end)
 * ------------------------------------------------------------------------- */
/**
 * Is the legacy secret-in-URL export auth allowed? (V6 #9)
 *
 * NEW installs default to header-only: a secret in a URL lands in access, proxy, CDN and browser logs.
 * An install that predates this release and never saved the setting keeps the old default (on), so a
 * puller that still uses the path form does not break on upgrade. The admin setting overrides both.
 */
function enginekick_legacy_path_auth_enabled() {
	$saved = get_option( 'enginekick_legacy_path_auth', null );
	if ( null !== $saved ) {
		return (bool) (int) $saved;
	}
	return false !== get_option( 'enginekick_db_version', false );   // pre-existing install: old default
}

function enginekick_install() {
	global $wpdb;
	// Pin the legacy-auth decision the first time this runs: on for a site that already had the plugin
	// (enginekick_db_version exists), off for a brand-new install.
	if ( null === get_option( 'enginekick_legacy_path_auth', null ) ) {
		add_option( 'enginekick_legacy_path_auth', false !== get_option( 'enginekick_db_version', false ) ? 1 : 0 );
	}
	if ( ! function_exists( 'dbDelta' ) ) { require_once ABSPATH . 'wp-admin/includes/upgrade.php'; }
	$cc = $wpdb->get_charset_collate();
	$crawl = enginekick_crawl_table();
	$chg   = enginekick_changes_table();
	dbDelta( "CREATE TABLE $crawl (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		ts DATETIME NOT NULL,
		ua VARCHAR(300) NOT NULL,
		url VARCHAR(512) NOT NULL,
		status SMALLINT NOT NULL DEFAULT 200,
		PRIMARY KEY (id),
		KEY ts (ts)
	) $cc;" );
	dbDelta( "CREATE TABLE $chg (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		ts DATETIME NOT NULL,
		post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
		url VARCHAR(512) NOT NULL,
		action VARCHAR(20) NOT NULL,
		modified DATETIME NULL,
		author VARCHAR(120) NULL,
		title VARCHAR(300) NULL,
		request_id VARCHAR(64) NOT NULL DEFAULT '',
		PRIMARY KEY (id),
		KEY ts (ts)
	) $cc;" );
	// The bundled MCP module owns the audit and rate tables; create them here too so a fresh activation
	// of the combined plugin has them immediately.
	enginekick_mcp_install_audit();
	// Run the MCP module's activation too: WordPress fires the activation hook only for the MAIN
	// plugin file, so the bundled enginekick-mcp.php's own register_activation_hook never fires. Call
	// it here so the token, secure-default mode, and the least-privilege service account are all set
	// up on activation. (The admin_init self-heal below covers sites already activated before this fix.)
	enginekick_mcp_activate();
	// Secrets are read only when needed, not loaded into memory on every request (pre-install hardening).
	// wp_set_option_autoload_values() is WordPress 6.4+; older versions get the equivalent direct update.
	if ( function_exists( 'wp_set_option_autoload_values' ) ) {
		wp_set_option_autoload_values( array( 'enginekick_secret' => false, 'enginekick_mcp_token' => false ) );
	} else {
		$wpdb->query( "UPDATE {$wpdb->options} SET autoload = 'no' WHERE option_name IN ('enginekick_secret','enginekick_mcp_token')" );
		wp_cache_delete( 'alloptions', 'options' );
	}
	// Record the version ONLY when this module's tables AND columns really exist (V6 #5, R8 F3); otherwise the
	// next admin page load retries instead of trusting a version saved after a failed CREATE or ALTER.
	$left = enginekick_connector_schema_missing( true );
	if ( ! $left ) {
		update_option( 'enginekick_db_version', ENGINEKICK_DB_VERSION );
	} else {
		error_log( 'EngineKick: change-log schema incomplete, will retry on the next admin page load: ' . implode( ', ', $left ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}
}
/**
 * Activation entry point. Multisite is refused outright (pre-install #8): it is untested, network activation
 * would create per-site tables only for the activating site, and uninstall would delete a network-wide user.
 */
/**
 * Minimum stack for THIS build. The legacy build (generated by tools/downlevel-legacy.php) carries a lower
 * pair, rewritten there — keep the two literals on these lines so the generator can find them.
 */
function enginekick_min_stack() {
	return array( 'php' => '5.6', 'wp' => '5.0' );
}
/**
 * Refuse activation on a stack this build cannot run on, and say which build to use instead. WordPress
 * enforces the Requires headers itself only from 5.2, and never for a plugin already active, so this is
 * the check that actually protects an old site.
 *
 * It cannot protect against installing this build on PHP below 7.0: PHP parses the whole file before any
 * of it runs, so the `??` operators alone are fatal there. That is precisely why the legacy build exists.
 */
function enginekick_stack_ok( &$why = null ) {
	global $wp_version;
	$min = enginekick_min_stack();
	if ( version_compare( PHP_VERSION, $min['php'], '<' ) ) {
		$why = 'This build of EngineKick OS needs PHP ' . $min['php'] . ' or newer; this site runs PHP ' . PHP_VERSION . '.';
		return false;
	}
	if ( version_compare( (string) $wp_version, $min['wp'], '<' ) ) {
		$why = 'This build of EngineKick OS needs WordPress ' . $min['wp'] . ' or newer; this site runs WordPress ' . $wp_version . '.';
		return false;
	}
	return true;
}
function enginekick_activate( $network_wide = false ) {
	$why = '';
	if ( ! enginekick_stack_ok( $why ) ) {
		wp_die(
			'<h1>EngineKick OS was not activated</h1><p>' . esc_html( $why ) . '</p>'
			. '<p>This site is older than even the legacy build supports. Update WordPress or PHP before installing EngineKick OS.</p>',
			'EngineKick OS - unsupported WordPress or PHP version',
			array( 'back_link' => true )
		);
	}
	if ( is_multisite() ) {
		wp_die(
			'<h1>EngineKick OS was not activated</h1><p>This plugin does not support WordPress multisite yet.</p>',
			'EngineKick OS - multisite not supported',
			array( 'back_link' => true )
		);
	}
	enginekick_install();
}
register_activation_hook( __FILE__, 'enginekick_activate' );
// Deactivation must fail closed (review V4 #3). WP fires the hook only for the MAIN plugin file, so
// call the bundled MCP module's deactivation from here: mode -> off + strip plugin-added caps.
register_deactivation_hook( __FILE__, 'enginekick_deactivate' );
function enginekick_deactivate() {
	enginekick_mcp_deactivate();
}
// Self-heal a missing/old table — but ONLY in the admin, where upgrade.php + dbDelta are safe to load.
// NEVER run dbDelta on a front-end request (it pulls in admin includes and can fatal the whole site).
// Front-end page loads stay lightweight; the REST endpoints null-guard, so a missing table is harmless.
add_action( 'admin_init', function () {
	// One shared schema lookup for both modules (was three SHOW TABLES on every admin page load).
	if ( get_option( 'enginekick_db_version' ) !== ENGINEKICK_DB_VERSION || enginekick_connector_schema_missing() ) {
		enginekick_install();
	}
} );


/* ---------------------------------------------------------------------------
 * Self-update: signed releases from EngineKick's own update source.
 *
 * Why: every fix used to mean uploading a zip to each site by hand, so sites ran months-old code. Now the
 * plugin checks a manifest at the update source, offers the new version in Plugins -> Updates like any
 * other plugin, and — when "update automatically" is on (the default) — installs it through WordPress's
 * own auto-updater within twelve hours of its release.
 *
 * Trust model: the manifest is SIGNED (Ed25519) with a key that never leaves the operator's machine; the
 * public half is below. The manifest names each package's SHA-256, which is checked after download and
 * before anything is installed. Both the manifest and the package must be fetched over https. A failed
 * signature, hash, or an older version means: nothing happens. No code runs from the update source;
 * WordPress's standard plugin upgrader installs the verified zip.
 * ------------------------------------------------------------------------- */
define( 'ENGINEKICK_UPDATE_PUBKEY', 'p094qtbCuRQSS6PWH3YKfDAcAquQuSR0ZtyIySeAY60=' );   // base64, Ed25519
if ( ! defined( 'ENGINEKICK_UPDATE_URL_DEFAULT' ) ) {
	// EngineKick's release files: a public repository that holds ONLY the signed manifest and the packages.
	define( 'ENGINEKICK_UPDATE_URL_DEFAULT', 'https://raw.githubusercontent.com/seorankserpllc/enginekick-updates/main/update.json' );
}

function enginekick_update_basename() {
	return plugin_basename( __FILE__ );                        // e.g. enginekick-os/enginekick-os.php
}
function enginekick_update_slug() {
	return dirname( enginekick_update_basename() );             // e.g. enginekick-os
}
function enginekick_update_url() {
	$u = trim( (string) get_option( 'enginekick_update_url', '' ) );
	// The site's own setting wins; otherwise the compiled-in default. A filter so a test can blank it.
	return (string) apply_filters( 'enginekick_update_source', '' !== $u ? $u : (string) ENGINEKICK_UPDATE_URL_DEFAULT );
}
function enginekick_update_auto_enabled() {
	return '0' !== (string) get_option( 'enginekick_update_auto', '1' );
}
function enginekick_update_can_verify() {
	return function_exists( 'sodium_crypto_sign_verify_detached' );
}
/** https only — unless a test harness says otherwise for its own local server. */
function enginekick_update_url_ok( $url ) {
	$scheme = strtolower( (string) wp_parse_url( (string) $url, PHP_URL_SCHEME ) );
	if ( 'https' === $scheme ) {
		return true;
	}
	return 'http' === $scheme && (bool) apply_filters( 'enginekick_update_allow_insecure', false, $url );
}

/**
 * Fetch and verify the manifest. Returns the decoded payload, or a WP_Error. Cached for six hours; a failure
 * is remembered for ten minutes so a broken source is not hammered on every admin page.
 */
function enginekick_update_manifest( $force = false ) {
	$url = enginekick_update_url();
	if ( '' === $url ) {
		return new WP_Error( 'no_source', 'No update source is configured.' );
	}
	if ( ! enginekick_update_can_verify() ) {
		return new WP_Error( 'no_sodium', 'This server cannot verify update signatures (no sodium support), so updates are not installed automatically.' );
	}
	if ( ! enginekick_update_url_ok( $url ) ) {
		return new WP_Error( 'insecure_source', 'The update source must be an https address.' );
	}
	$ck = 'enginekick_update_manifest';
	if ( ! $force ) {
		$cached = get_transient( $ck );
		if ( is_array( $cached ) && isset( $cached['payload'] ) ) {
			return $cached['payload'];
		}
		if ( is_array( $cached ) && isset( $cached['error'] ) ) {
			return new WP_Error( 'cached_error', (string) $cached['error'] );
		}
	}
	$fail = function ( $code, $msg ) use ( $ck ) {
		set_transient( $ck, array( 'error' => $msg ), 10 * MINUTE_IN_SECONDS );
		return new WP_Error( $code, $msg );
	};
	$resp = wp_remote_get( $url, array( 'timeout' => 15, 'redirection' => 2, 'sslverify' => true, 'headers' => array( 'Accept' => 'application/json' ) ) );
	if ( is_wp_error( $resp ) ) {
		return $fail( 'fetch_failed', 'Could not reach the update source: ' . $resp->get_error_message() );
	}
	if ( 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
		return $fail( 'fetch_failed', 'The update source answered HTTP ' . (int) wp_remote_retrieve_response_code( $resp ) . '.' );
	}
	$env = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
	if ( ! is_array( $env ) || empty( $env['payload'] ) || empty( $env['signature'] ) ) {
		return $fail( 'bad_manifest', 'The update source did not return a signed manifest.' );
	}
	$payload = base64_decode( (string) $env['payload'], true );
	$sig     = base64_decode( (string) $env['signature'], true );
	$pub     = base64_decode( (string) apply_filters( 'enginekick_update_public_key', ENGINEKICK_UPDATE_PUBKEY ), true );
	if ( false === $payload || false === $sig || false === $pub || 64 !== strlen( $sig ) || 32 !== strlen( $pub ) ) {
		return $fail( 'bad_manifest', 'The update manifest is malformed.' );
	}
	try {
		$valid = sodium_crypto_sign_verify_detached( $sig, $payload, $pub );
	} catch ( Exception $e ) {
		$valid = false;
	}
	if ( true !== $valid ) {
		return $fail( 'bad_signature', 'The update manifest is not signed by EngineKick. Nothing was installed.' );
	}
	$data = json_decode( $payload, true );
	if ( ! is_array( $data ) || empty( $data['builds'] ) || ! is_array( $data['builds'] ) ) {
		return $fail( 'bad_manifest', 'The signed manifest has no builds in it.' );
	}
	set_transient( $ck, array( 'payload' => $data ), 6 * HOUR_IN_SECONDS );
	return $data;
}

/** The build entry for THIS plugin directory if it is newer than what is installed, else null. */
function enginekick_update_available( $force = false ) {
	$data = enginekick_update_manifest( $force );
	if ( is_wp_error( $data ) ) {
		return null;
	}
	$slug = enginekick_update_slug();
	if ( empty( $data['builds'][ $slug ] ) || ! is_array( $data['builds'][ $slug ] ) ) {
		return null;
	}
	$b = $data['builds'][ $slug ];
	if ( empty( $b['version'] ) || empty( $b['package'] ) || empty( $b['sha256'] ) ) {
		return null;
	}
	$installed = preg_replace( '/-legacy$/', '', (string) ENGINEKICK_CONNECTOR_LOADED );
	$offered   = preg_replace( '/-legacy$/', '', (string) $b['version'] );
	if ( version_compare( $offered, $installed, '<=' ) ) {
		return null;
	}
	if ( ! enginekick_update_url_ok( $b['package'] ) ) {
		return null;
	}
	global $wp_version;
	if ( ! empty( $b['requires'] ) && version_compare( (string) $wp_version, (string) $b['requires'], '<' ) ) {
		return null;
	}
	if ( ! empty( $b['requires_php'] ) && version_compare( PHP_VERSION, (string) $b['requires_php'], '<' ) ) {
		return null;
	}
	return $b;
}

/**
 * Tell WordPress about the new version, so it appears in Plugins -> Updates and the auto-updater can run it.
 * Hooked on the transient being READ, not only on WordPress setting it: WordPress sets it only after its own
 * check against api.wordpress.org succeeds, and a host that cannot reach wordpress.org would otherwise never
 * see an EngineKick update. The manifest is cached, so the read hook costs nothing per page.
 */
function enginekick_update_inject( $transient ) {
	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}
	$b = enginekick_update_available();
	$basename = enginekick_update_basename();
	if ( $b ) {
		$item = (object) array(
			'id'           => 'enginekick/' . enginekick_update_slug(),
			'slug'         => enginekick_update_slug(),
			'plugin'       => $basename,
			'new_version'  => (string) $b['version'],
			'url'          => 'https://enginekick.com/',
			'package'      => (string) $b['package'],
			'requires'     => isset( $b['requires'] ) ? (string) $b['requires'] : '',
			'requires_php' => isset( $b['requires_php'] ) ? (string) $b['requires_php'] : '',
			'tested'       => isset( $b['tested'] ) ? (string) $b['tested'] : '',
			'icons'        => array(),
			'banners'      => array(),
		);
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $basename ] = $item;
		if ( isset( $transient->no_update[ $basename ] ) ) {
			unset( $transient->no_update[ $basename ] );
		}
	} elseif ( isset( $transient->response[ $basename ] ) ) {
		unset( $transient->response[ $basename ] );
	}
	return $transient;
}
add_filter( 'site_transient_update_plugins', 'enginekick_update_inject' );
add_filter( 'pre_set_site_transient_update_plugins', 'enginekick_update_inject' );

/** Download the package ourselves so its SHA-256 is checked against the signed manifest before install. */
add_filter( 'upgrader_pre_download', function ( $reply, $package, $upgrader, $hook_extra ) {
	if ( false !== $reply || ! is_array( $hook_extra ) || empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== enginekick_update_basename() ) {
		return $reply;
	}
	$b = enginekick_update_available();
	if ( ! $b || (string) $b['package'] !== (string) $package ) {
		return new WP_Error( 'enginekick_unknown_package', 'This package is not the one named in EngineKick\'s signed manifest, so it was not installed.' );
	}
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	$tmp = download_url( $package, 60 );
	if ( is_wp_error( $tmp ) ) {
		enginekick_update_note_failure( 'download failed: ' . $tmp->get_error_message() );
		return $tmp;
	}
	$hash = hash_file( 'sha256', $tmp );
	if ( ! hash_equals( strtolower( (string) $b['sha256'] ), strtolower( (string) $hash ) ) ) {
		@unlink( $tmp );
		enginekick_update_note_failure( 'the downloaded package did not match the signed manifest (checksum mismatch), so it was not installed' );
		return new WP_Error( 'enginekick_bad_package', 'The downloaded EngineKick package does not match the signed manifest (checksum mismatch), so it was not installed.' );
	}
	delete_option( 'enginekick_update_last_failure' );
	return $tmp;
}, 10, 4 );
/** Remember why the last update attempt failed, for the admin page (WordPress's own result plumbing loses it). */
function enginekick_update_note_failure( $why ) {
	update_option( 'enginekick_update_last_failure', array( 't' => time(), 'why' => (string) $why ), false );
}

/** The packages are flat (files at the zip root): give the extracted folder this plugin's directory name. */
add_filter( 'upgrader_source_selection', function ( $source, $remote_source, $upgrader, $hook_extra ) {
	global $wp_filesystem;
	if ( is_wp_error( $source ) || ! is_array( $hook_extra ) || empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== enginekick_update_basename() || ! $wp_filesystem ) {
		return $source;
	}
	$slug = enginekick_update_slug();
	$want = trailingslashit( $remote_source ) . $slug . '/';
	if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) {
		return $source;
	}
	if ( untrailingslashit( $source ) === untrailingslashit( $remote_source ) ) {
		// Flat package: the files sit at the top of the extracted folder. Put them in a folder with this
		// plugin's directory name, or WordPress would install them loose into wp-content/plugins/.
		if ( ! $wp_filesystem->mkdir( untrailingslashit( $want ) ) ) {
			return new WP_Error( 'enginekick_update_mkdir', 'Could not prepare the update folder.' );
		}
		foreach ( array_keys( (array) $wp_filesystem->dirlist( $source ) ) as $name ) {
			if ( $name === $slug ) {
				continue;
			}
			if ( ! $wp_filesystem->move( trailingslashit( $source ) . $name, $want . $name, true ) ) {
				return new WP_Error( 'enginekick_update_move', 'Could not arrange the update files.' );
			}
		}
		return $want;
	}
	// A single wrapper folder under another name: rename it.
	if ( $wp_filesystem->move( untrailingslashit( $source ), untrailingslashit( $want ), true ) ) {
		return $want;
	}
	return $source;
}, 10, 4 );

/** Install the verified update without anyone logging in (WordPress's own auto-updater, twice a day). */
add_filter( 'auto_update_plugin', function ( $update, $item ) {
	$plugin = is_object( $item ) ? ( ( isset( $item->plugin ) ? $item->plugin : '' ) ) : ( is_array( $item ) ? ( ( isset( $item['plugin'] ) ? $item['plugin'] : '' ) ) : '' );
	if ( $plugin === enginekick_update_basename() ) {
		return enginekick_update_auto_enabled() && '' !== enginekick_update_url();
	}
	return $update;
}, 10, 2 );

/** "View version details" in Plugins. */
add_filter( 'plugins_api', function ( $res, $action, $args ) {
	if ( 'plugin_information' !== $action || ! is_object( $args ) || ( ( isset( $args->slug ) ? $args->slug : '' ) ) !== enginekick_update_slug() ) {
		return $res;
	}
	$b = enginekick_update_available();
	return (object) array(
		'name'          => 'EngineKick OS',
		'slug'          => enginekick_update_slug(),
		'version'       => $b ? (string) $b['version'] : (string) ENGINEKICK_CONNECTOR_LOADED,
		'author'        => 'EngineKick',
		'homepage'      => 'https://enginekick.com/',
		'download_link' => $b ? (string) $b['package'] : '',
		'requires'      => $b && isset( $b['requires'] ) ? (string) $b['requires'] : '',
		'requires_php'  => $b && isset( $b['requires_php'] ) ? (string) $b['requires_php'] : '',
		'sections'      => array( 'description' => 'EngineKick OS connector. Releases are signed by EngineKick and verified before installation.' ),
	);
}, 10, 3 );

function enginekick_update_save_settings() {
	$url = isset( $_POST['enginekick_update_url'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['enginekick_update_url'] ) ) ) : '';
	if ( '' !== $url && ! enginekick_update_url_ok( $url ) ) {
		echo '<div class="notice notice-error"><p><strong>Update source not saved:</strong> it must be an https address.</p></div>';
	} else {
		update_option( 'enginekick_update_url', $url, false );
		update_option( 'enginekick_update_auto', empty( $_POST['enginekick_update_auto'] ) ? '0' : '1', false );
		delete_transient( 'enginekick_update_manifest' );
		delete_site_transient( 'update_plugins' );
		if ( function_exists( 'wp_clean_plugins_cache' ) ) {
			wp_clean_plugins_cache( true );
		}
		echo '<div class="notice notice-success is-dismissible"><p>Update settings saved and the update source checked again.</p></div>';
	}
}

/** Why WordPress's background updater will not run on this site, or '' when it will. */
function enginekick_update_auto_blocked_reason() {
	if ( function_exists( 'wp_is_file_mod_allowed' ) && ! wp_is_file_mod_allowed( 'automatic_updater' ) ) {
		return 'file changes are disallowed on this site (DISALLOW_FILE_MODS)';
	}
	$disabled = defined( 'AUTOMATIC_UPDATER_DISABLED' ) && AUTOMATIC_UPDATER_DISABLED;
	if ( apply_filters( 'automatic_updater_disabled', $disabled ) ) {
		return 'automatic updates are switched off on this site (AUTOMATIC_UPDATER_DISABLED, or a plugin)';
	}
	return '';
}
function enginekick_update_settings_box() {
	$src   = enginekick_update_url();
	$auto  = enginekick_update_auto_enabled();
	$block = enginekick_update_auto_blocked_reason();
	$man   = '' !== $src ? enginekick_update_manifest( ! empty( $_POST['enginekick_update_settings'] ) ) : null;
	$avail = '' !== $src ? enginekick_update_available() : null;
	?>
	<h2>Updates</h2>
	<form method="post" style="margin:10px 0 22px;padding:14px 16px;background:#fff;border:1px solid #ccd0d4;max-width:760px;">
		<?php wp_nonce_field( 'enginekick_update_settings' ); ?>
		<p>Installed: <strong>EngineKick OS <?php echo esc_html( ENGINEKICK_CONNECTOR_LOADED ); ?></strong>
			<?php if ( '' === $src ) : ?>
				&mdash; <span style="color:#996b00;font-weight:600;">no update source configured, so this site will not receive fixes on its own.</span>
			<?php elseif ( is_wp_error( $man ) ) : ?>
				&mdash; <span style="color:#b32d2e;font-weight:600;">update check failed:</span> <?php echo esc_html( $man->get_error_message() ); ?>
			<?php elseif ( $avail ) : ?>
				&mdash; <span style="color:#1a7f37;font-weight:600;">version <?php echo esc_html( (string) $avail['version'] ); ?> is available</span><?php echo ( $auto && '' === $block ) ? ' and will install automatically within 12 hours (or now from Plugins &rarr; Updates).' : '. Install it from Plugins &rarr; Updates.'; ?>
			<?php else : ?>
				&mdash; <span style="color:#1a7f37;font-weight:600;">up to date.</span>
			<?php endif; ?>
		</p>
		<p><label for="enginekick_update_url"><strong>Update source</strong> (https address of EngineKick's signed release manifest)</label><br>
			<input type="url" id="enginekick_update_url" name="enginekick_update_url" value="<?php echo esc_attr( (string) get_option( 'enginekick_update_url', '' ) ); ?>" placeholder="<?php echo esc_attr( ENGINEKICK_UPDATE_URL_DEFAULT ); ?>" style="width:100%;max-width:640px;"></p>
		<p><label><input type="checkbox" name="enginekick_update_auto" value="1"<?php checked( $auto ); ?>> Install EngineKick updates automatically (signed releases only; WordPress installs them in the background)</label></p>
		<?php $ek_lf = get_option( 'enginekick_update_last_failure' ); if ( is_array( $ek_lf ) && ! empty( $ek_lf['why'] ) ) : ?>
			<p style="color:#b32d2e;"><strong>Last update attempt failed</strong> (<?php echo esc_html( human_time_diff( (int) $ek_lf['t'] ) ); ?> ago): <?php echo esc_html( (string) $ek_lf['why'] ); ?>. WordPress will try again on its next check.</p>
		<?php endif; ?>
		<?php if ( '' !== $block ) : ?>
			<p style="color:#996b00;"><strong>Updates will not install on their own here:</strong> <?php echo esc_html( $block ); ?>. They still appear in Plugins &rarr; Updates, where one click installs the verified package.</p>
		<?php endif; ?>
		<?php if ( ! enginekick_update_can_verify() ) : ?>
			<p style="color:#b32d2e;">This server has no sodium support, so release signatures cannot be verified here and updates are not installed automatically.</p>
		<?php endif; ?>
		<p><button type="submit" name="enginekick_update_settings" value="1" class="button">Save and check now</button></p>
	</form>
	<?php
}

/* ---------------------------------------------------------------------------
 * Crawler logger — record AI/search-bot hits (+ 1% human sample). Pass-through:
 * runs on shutdown, after the page is sent; never blocks the visitor.
 * ------------------------------------------------------------------------- */
add_action( 'shutdown', function () {
	if ( is_admin() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
	if ( ! (int) get_option( 'enginekick_crawl_enabled', 1 ) ) { return; }   // configurable master switch
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( enginekick_clean_crawl_ua( (string) $_SERVER['HTTP_USER_AGENT'] ), 0, 300 ) : '';
	if ( $ua === '' ) { return; }
	$is_bot = preg_match( '/bot|crawl|spider|slurp|gpt|claude|perplexity|anthropic|openai|cohere|bytespider|ccbot|google|oai-|bing|yandex|baidu|applebot|amazonbot|meta-external|duckduck|petalbot|timpibot|youbot|diffbot/i', $ua );
	if ( ! $is_bot ) {
		if ( (int) get_option( 'enginekick_crawl_bots_only', 1 ) ) { return; }   // bot-only mode (conservative default ON)
		$sample = (int) get_option( 'enginekick_crawl_human_sample', 0 );        // % of humans to log (default 0 = none)
		if ( $sample <= 0 || wp_rand( 1, 100 ) > $sample ) { return; }
	}
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	if ( '' === $path ) { $path = '/'; }
	// Exclude admin/API/cron AND sensitive auth/preview routes (review V4 #5): never log credentials,
	// password-reset keys, login attempts, XML-RPC, or nonce-bearing preview URLs.
	$lp = strtolower( $path );
	// REST requests must never be logged — the MCP endpoint carries its token IN THE PATH, and the
	// old test (a `/wp-json` PREFIX match) missed it on any site installed in a subdirectory or using
	// a custom REST prefix. `/blog/wp-json/enginekick-mcp/v1/<token>` sailed straight through and the
	// credential landed in the crawl table, which is then exported over /crawl-log — handing an
	// export-secret holder the MCP write credential (V5-ext #3).
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) { return; }
	$rest_prefix = function_exists( 'rest_get_url_prefix' ) ? trim( (string) rest_get_url_prefix(), '/' ) : 'wp-json';
	if ( '' !== $rest_prefix && ( strpos( $lp, '/' . strtolower( $rest_prefix ) . '/' ) !== false
		|| substr( $lp, - ( strlen( $rest_prefix ) + 1 ) ) === '/' . strtolower( $rest_prefix ) ) ) {
		return;
	}
	if ( strpos( $lp, '/wp-json' ) !== false || isset( $_GET['rest_route'] ) ) { return; }   // ?rest_route= permalink fallback
	if ( strpos( $lp, '/wp-admin' ) === 0 || strpos( $lp, '/wp-cron' ) !== false
		|| strpos( $lp, '/wp-login.php' ) === 0 || strpos( $lp, '/xmlrpc.php' ) === 0 || strpos( $lp, 'wp-signup' ) !== false ) {
		return;
	}
	if ( isset( $_GET['preview'] ) || isset( $_GET['_wpnonce'] ) || isset( $_GET['key'] ) || isset( $_GET['token'] ) ) { return; }
	// Store the PATH ONLY by default — query strings can carry search terms, campaign IDs, reset keys
	// or emails. An admin can opt into logging the query string (enginekick_crawl_log_query) if needed.
	$uri = $path;
	if ( (int) get_option( 'enginekick_crawl_log_query', 0 ) ) {
		$qs = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '', PHP_URL_QUERY );
		if ( '' !== $qs ) { $uri = $path . '?' . $qs; }
	}
	$uri = enginekick_redact_path( enginekick_clean_crawl_path( $uri ) );   // clean first; redaction markers are added after

	// Global per-minute write cap: under a bot flood, drop beyond the cap so the DB can't be saturated.
	$cap = (int) get_option( 'enginekick_crawl_cap_per_min', 300 );
	if ( $cap > 0 ) {
		// Atomic (V5-ext #9): the old get -> add -> set transient sequence let concurrent bot hits all
		// read the same count and all pass. Charge-then-check on the shared atomic counter instead.
		$n = enginekick_counter_hit( 'crawl_global_per_minute', 60 );
		if ( false === $n ) {
			// Degraded until the rate table exists (next admin page load): soft throttle.
			$n = (int) get_transient( 'ek_crawl_min' ) + 1;
			set_transient( 'ek_crawl_min', $n, 60 );
		}
		if ( $n > $cap ) { return; }
	}
	global $wpdb;
	$wpdb->insert( enginekick_crawl_table(), array(
		'ts'     => gmdate( 'Y-m-d H:i:s' ),
		'ua'     => $ua,
		'url'    => substr( $uri, 0, 512 ),
		'status' => function_exists( 'http_response_code' ) ? (int) http_response_code() : 200,
	), array( '%s', '%s', '%s', '%d' ) );
	// Occasional prune so the table never grows unbounded (no cron needed). Retention configurable.
	// BOUNDED: delete at most 500 rows per pass (a small indexed batch) so a big backlog can't create
	// a load spike during a visitor's shutdown request — it just trims a little more often instead.
	if ( wp_rand( 1, 300 ) === 1 ) {
		$days = max( 7, (int) get_option( 'enginekick_crawl_retention_days', 120 ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . enginekick_crawl_table() . ' WHERE ts < %s ORDER BY id ASC LIMIT 500', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}, 99 );

/* ---------------------------------------------------------------------------
 * Change tracking — add / update / publish / delete, by anyone (incl. devs)
 * ------------------------------------------------------------------------- */
// Which post types change-tracking records. ALLOWLIST, not blocklist (review V5 #5): the old
// blocklist meant every custom post type on the site was logged with its TITLE and author — so on a
// WooCommerce store, a forms plugin, a CRM or a membership plugin, customer names, emails and order
// references were written to the changes table and then exported through /wp-json/enginekick/v1/
// changes. Editorial types only, unless the operator widens it in Settings → EngineKick.
function enginekick_tracked_post_types() {
	$raw   = trim( (string) get_option( 'enginekick_changes_post_types', '' ) );
	$types = $raw ? preg_split( '/[\s,]+/', $raw ) : array( 'post', 'page' );
	$out   = array();
	foreach ( (array) $types as $t ) {
		$t = sanitize_key( $t );
		if ( '' !== $t && ! in_array( $t, $out, true ) ) { $out[] = $t; }
	}
	if ( ! $out ) { $out = array( 'post', 'page' ); }
	/** Filter the post types whose changes are tracked and exported. */
	return (array) apply_filters( 'enginekick_tracked_post_types', $out );
}

function enginekick_record_change( $post_id, $action ) {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) { return; }
	$post = get_post( $post_id );
	if ( ! $post || ! in_array( $post->post_type, enginekick_tracked_post_types(), true ) ) { return; }
	global $wpdb;
	$author = '';
	$uid = get_current_user_id();
	if ( $uid ) { $u = get_userdata( $uid ); $author = $u ? $u->user_login : (string) $uid; }
	// While the schema version is stale (a migration that has not completed, R8 F3), look before inserting:
	// a site whose request_id column is missing still gets its change records, without that column. Healthy
	// sites skip the check entirely.
	if ( get_option( 'enginekick_db_version' ) !== ENGINEKICK_DB_VERSION && in_array( 'column:changes.request_id', enginekick_connector_schema_missing(), true ) ) {
		$inserted = $wpdb->insert( enginekick_changes_table(), array(
			'ts'       => gmdate( 'Y-m-d H:i:s' ),
			'post_id'  => (int) $post_id,
			'url'      => substr( (string) get_permalink( $post_id ), 0, 512 ),
			'action'   => $action,
			'modified' => $post->post_modified_gmt ?: null,
			'author'   => substr( $author, 0, 120 ),
			'title'    => substr( (string) get_the_title( $post_id ), 0, 300 ),
		), array( '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) );
		if ( false === $inserted ) {
			error_log( 'EngineKick: could not record the ' . $action . ' change for post #' . (int) $post_id . ': ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
		return;
	}
	$inserted = $wpdb->insert( enginekick_changes_table(), array(
		'ts'       => gmdate( 'Y-m-d H:i:s' ),
		'post_id'  => (int) $post_id,
		'url'      => substr( (string) get_permalink( $post_id ), 0, 512 ),
		'action'   => $action,
		'modified' => $post->post_modified_gmt ?: null,
		'author'   => substr( $author, 0, 120 ),
		'title'    => substr( (string) get_the_title( $post_id ), 0, 300 ),
		// Which MCP request produced this change, if any (V7 #4). Human edits store '', so the export can tell
		// them apart instead of attaching the same accumulated MCP detail to every row for the post.
		'request_id' => ( function_exists( 'enginekick_mcp_is_active_request' ) && enginekick_mcp_is_active_request() ) ? enginekick_mcp_request_id() : '',
	), array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' ) );
	if ( false === $inserted && false !== stripos( (string) $wpdb->last_error, 'request_id' ) ) {
		// The request_id column is missing (an upgrade whose ALTER failed, R8 F3): keep the change record without
		// it rather than lose it; the next admin page load repairs the column.
		$inserted = $wpdb->insert( enginekick_changes_table(), array(
			'ts'       => gmdate( 'Y-m-d H:i:s' ),
			'post_id'  => (int) $post_id,
			'url'      => substr( (string) get_permalink( $post_id ), 0, 512 ),
			'action'   => $action,
			'modified' => $post->post_modified_gmt ?: null,
			'author'   => substr( $author, 0, 120 ),
			'title'    => substr( (string) get_the_title( $post_id ), 0, 300 ),
		), array( '%s', '%d', '%s', '%s', '%s', '%s', '%s' ) );
	}
	if ( false === $inserted ) {
		// A save hook cannot fail the editor's save, but a lost change record must not be silent (V6 #4).
		error_log( 'EngineKick: could not record the ' . $action . ' change for post #' . (int) $post_id . ': ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}
	// Bounded retention (review V4 #6): occasionally trim old rows in a small indexed batch so the
	// changes table can't grow for the life of the install. Runs in admin context (save_post), not on
	// visitor requests, so there is no front-end load impact.
	if ( wp_rand( 1, 50 ) === 1 ) {
		$days = max( 30, (int) get_option( 'enginekick_changes_retention_days', 365 ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . enginekick_changes_table() . ' WHERE ts < %s ORDER BY id ASC LIMIT 500', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}
}
// Created or edited (skip autosave; treat first publish via transition below).
add_action( 'save_post', function ( $post_id, $post, $update ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	enginekick_record_change( $post_id, $update ? 'updated' : 'added' );
}, 20, 3 );
// Status transitions (e.g. draft -> publish).
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( $new === $old ) { return; }
	if ( $new === 'publish' ) { enginekick_record_change( $post->ID, 'published' ); }
	elseif ( $new === 'trash' ) { enginekick_record_change( $post->ID, 'deleted' ); }
}, 20, 3 );
// Hard delete.
add_action( 'before_delete_post', function ( $post_id ) { enginekick_record_change( $post_id, 'deleted' ); }, 20, 1 );

/* ---------------------------------------------------------------------------
 * REST endpoints (secret-in-URL; Northstar pulls these)
 * ------------------------------------------------------------------------- */
// Auth for the pull/export endpoints. PREFERS a header so the secret stays OUT of the URL (and thus
// out of access/proxy/CDN logs) — review v2 #2. Accepts `Authorization: Bearer <secret>` or
// `X-EngineKick-Secret: <secret>`; falls back to the legacy secret-in-path for old callers. (The MCP
// endpoint can't use headers — the Claude custom-connector UI requires an authless URL.)
function enginekick_check_auth( $request ) {
	$want = enginekick_secret();
	if ( ! $want ) { return false; }
	$auth = (string) $request->get_header( 'authorization' );
	if ( 0 === stripos( $auth, 'bearer ' ) ) {
		$tok = trim( substr( $auth, 7 ) );
		if ( '' !== $tok && hash_equals( $want, $tok ) ) { return true; }
	}
	$xh = (string) $request->get_header( 'X-EngineKick-Secret' );
	if ( '' !== $xh && hash_equals( $want, $xh ) ) { return true; }
	// Legacy: secret in the URL path. Header auth is the default; the path form can be DISABLED by the
	// operator (review v3 #3) so credentials never land in access logs.
	if ( enginekick_legacy_path_auth_enabled() ) {
		$given = (string) $request['secret'];
		if ( '' !== $given && hash_equals( $want, $given ) ) { return true; }
	}
	return false;
}
/**
 * permission_callback for every export endpoint: auth (header or legacy path) + IP allowlist + rate limit.
 *
 * WordPress expects the real check here rather than '__return_true' plus a check inside the callback, so a
 * refused request never reaches the handler at all. Returns true, or a WP_Error carrying the status code.
 */
/**
 * An export whose query failed answers 500 with a stable message (the database error goes to the server log,
 * not to the caller), so a puller never mistakes a broken table for "nothing happened" (R8 F3).
 */
function enginekick_export_failed( $what, $detail ) {
	error_log( 'EngineKick: the ' . $what . ' export failed: ' . $detail ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	return new WP_Error( 'export_failed', 'The ' . $what . ' could not be read on this site. An administrator should open any wp-admin page (which repairs the tables) and check the server error log.', array( 'status' => 500 ) );
}
function enginekick_export_permission( $request ) {
	if ( ! enginekick_check_auth( $request ) ) {
		return new WP_Error( 'forbidden', 'A valid EngineKick export secret is required.', array( 'status' => 403 ) );
	}
	if ( ! enginekick_ip_allowed() ) {
		return new WP_Error( 'forbidden_ip', 'This IP address is not allowed to reach the EngineKick endpoints.', array( 'status' => 403 ) );
	}
	if ( ! enginekick_rate_ok( 'export', 30, 60 ) ) {
		return new WP_Error( 'rate_limited', 'Too many export requests; try again shortly.', array( 'status' => 429 ) );
	}
	return true;
}
/**
 * Never let a shared cache store an EngineKick response (pre-install #1). WordPress sends no-cache headers
 * only for logged-in users, and the exports authenticate with a secret header, not a login. So an
 * authenticated crawl-log / changes / audit response went out with no Cache-Control at all and
 * "Vary: Origin" only. A host or CDN that caches /wp-json/ GETs could then serve logs, post titles, author
 * logins and audit IPs to anyone, or cache a 403 and silently break the pullers.
 */
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	$route = (string) $request->get_route();
	if ( ( 0 === strpos( $route, '/enginekick/v1' ) || 0 === strpos( $route, '/enginekick-mcp/v1' ) ) && $response instanceof WP_HTTP_Response ) {
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0, private' );
		$response->header( 'Pragma', 'no-cache' );
		$response->header( 'Expires', 'Wed, 11 Jan 1984 05:00:00 GMT' );
		$response->header( 'Vary', 'Authorization, X-EngineKick-Secret, Origin' );
	}
	return $response;
}, 10, 3 );

add_action( 'rest_api_init', function () {
	// Callbacks are shared between the header-auth (secret-free path) routes — the DEFAULT — and the
	// legacy secret-in-path routes (review v3 #3). The gate authenticates by header first.
	$cb_crawl = function ( $request ) {
		global $wpdb;
		$since     = sanitize_text_field( (string) $request->get_param( 'since' ) );
		$limit     = min( 2000, max( 1, (int) ( $request->get_param( 'limit' ) ?: 1000 ) ) );
		$before_id = (int) $request->get_param( 'before_id' );
		$where = array(); $args = array();
		if ( preg_match( '/^\\d{4}-\\d{2}-\\d{2}$/', $since ) ) { $where[] = 'ts >= %s'; $args[] = $since . ' 00:00:00'; }
		if ( $before_id > 0 ) { $where[] = 'id < %d'; $args[] = $before_id; }
		$wsql = $where ? ( 'WHERE ' . implode( ' AND ', $where ) ) : '';
		$args[] = $limit;
		$sql = "SELECT id, ts, ua, url, status FROM " . enginekick_crawl_table() . " $wsql ORDER BY id DESC LIMIT %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
		if ( '' !== $wpdb->last_error ) { return enginekick_export_failed( 'crawl log', $wpdb->last_error ); }   // R8 F3
		if ( ! is_array( $rows ) ) { $rows = array(); }
		$next = ( count( $rows ) === $limit && $rows ) ? (int) $rows[ count( $rows ) - 1 ]['id'] : 0;
		return array( 'site' => home_url(), 'slug' => enginekick_slug(), 'count' => count( $rows ), 'rows' => $rows, 'next_before_id' => $next );
	};
	$cb_changes = function ( $request ) {
		global $wpdb;
		$since     = sanitize_text_field( (string) $request->get_param( 'since' ) );
		$limit     = min( 5000, max( 1, (int) ( $request->get_param( 'limit' ) ?: 2000 ) ) );
		$before_id = (int) $request->get_param( 'before_id' );
		$where = array(); $args = array();
		if ( preg_match( '/^\\d{4}-\\d{2}-\\d{2}$/', $since ) ) { $where[] = 'ts >= %s'; $args[] = $since . ' 00:00:00'; }
		if ( $before_id > 0 ) { $where[] = 'id < %d'; $args[] = $before_id; }
		$wsql = $where ? ( 'WHERE ' . implode( ' AND ', $where ) ) : '';
		$args[] = $limit;
		// A half-migrated table is reported, not exported as "nothing changed" (R8 F3).
		if ( enginekick_connector_schema_missing() ) {
			return enginekick_export_failed( 'change log', 'schema incomplete: ' . implode( ', ', enginekick_connector_schema_missing() ) );
		}
		$sql = "SELECT id, ts, post_id, url, action, modified, author, title, request_id FROM " . enginekick_changes_table() . " $wsql ORDER BY id DESC LIMIT %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
		if ( '' !== $wpdb->last_error ) { return enginekick_export_failed( 'change log', $wpdb->last_error ); }
		if ( ! is_array( $rows ) ) { $rows = array(); }
		// Attach the field-level detail (internal links added, image set, title change…) the MCP recorded at
		// write time. Correlated by REQUEST ID, not by post id (V7 #4): keyed by post, one MCP edit's detail was
		// copied onto every change row for that post, including later human edits, and two MCP edits were
		// indistinguishable. A row with no request id is a human edit and carries no detail.
		$rids = array();
		foreach ( $rows as $r ) {
			if ( ! empty( $r['request_id'] ) ) { $rids[ (string) $r['request_id'] ] = true; }
		}
		$detail = array();
		if ( $rids && ! array_intersect( enginekick_schema_missing(), array( 'table:enginekick_mcp_audit', 'column:changes', 'column:request_id' ) ) ) {
			$atable = enginekick_mcp_audit_table();
			$in     = implode( ',', array_fill( 0, count( $rids ), '%s' ) );
			$arows  = $wpdb->get_results( $wpdb->prepare(
				"SELECT request_id, object_id, changes FROM $atable WHERE object_type='post' AND outcome IN ('ok','partial') AND changes<>'' AND request_id IN ($in) ORDER BY id ASC LIMIT 5000",
				array_keys( $rids ) ), ARRAY_A );
			foreach ( (array) $arows as $ar ) {
				$key   = (string) $ar['request_id'] . '|' . (int) $ar['object_id'];
				$lines = json_decode( (string) $ar['changes'], true );
				if ( ! is_array( $lines ) ) { continue; }
				if ( ! isset( $detail[ $key ] ) ) { $detail[ $key ] = array(); }
				foreach ( $lines as $ln ) {
					$ln = (string) $ln;
					if ( '' !== $ln && ! in_array( $ln, $detail[ $key ], true ) && count( $detail[ $key ] ) < 15 ) {
						$detail[ $key ][] = $ln;
					}
				}
			}
		}
		foreach ( $rows as &$r ) {
			$key                = (string) ( ( isset( $r['request_id'] ) ? $r['request_id'] : '' ) ) . '|' . (int) $r['post_id'];
			$r['field_changes'] = ( ! empty( $r['request_id'] ) && isset( $detail[ $key ] ) ) ? $detail[ $key ] : array();
		}
		unset( $r );
		$next = ( count( $rows ) === $limit && $rows ) ? (int) $rows[ count( $rows ) - 1 ]['id'] : 0;
		return array( 'site' => home_url(), 'slug' => enginekick_slug(), 'count' => count( $rows ), 'changes' => $rows, 'next_before_id' => $next );
	};
	$cb_audit = function ( $request ) {
		global $wpdb;
		$table = enginekick_mcp_audit_table();
		if ( in_array( 'table:enginekick_mcp_audit', enginekick_schema_missing(), true ) ) { return array( 'available' => false, 'rows' => array() ); }
		$since     = sanitize_text_field( (string) $request->get_param( 'since' ) );
		$limit     = min( 2000, max( 1, (int) ( $request->get_param( 'limit' ) ?: 1000 ) ) );
		$before_id = (int) $request->get_param( 'before_id' );
		$where = array(); $args = array();
		if ( preg_match( '/^\\d{4}-\\d{2}-\\d{2}$/', $since ) ) { $where[] = 'ts >= %s'; $args[] = $since . ' 00:00:00'; }
		if ( $before_id > 0 ) { $where[] = 'id < %d'; $args[] = $before_id; }
		$wsql = $where ? ( 'WHERE ' . implode( ' AND ', $where ) ) : '';
		$args[] = $limit;
		$sql = "SELECT * FROM $table $wsql ORDER BY id DESC LIMIT %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
		if ( '' !== $wpdb->last_error ) { return enginekick_export_failed( 'audit log', $wpdb->last_error ); }
		if ( ! is_array( $rows ) ) { $rows = array(); }
		$next = ( count( $rows ) === $limit && $rows ) ? (int) $rows[ count( $rows ) - 1 ]['id'] : 0;
		return array( 'available' => true, 'site' => home_url(), 'slug' => enginekick_slug(), 'count' => count( $rows ), 'rows' => $rows, 'next_before_id' => $next );
	};
	// DEFAULT: secret-free routes (auth via Authorization: Bearer / X-EngineKick-Secret header).
	register_rest_route( 'enginekick/v1', '/crawl-log', array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_crawl ) );
	register_rest_route( 'enginekick/v1', '/changes',   array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_changes ) );
	register_rest_route( 'enginekick/v1', '/mcp-audit', array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_audit ) );
	// LEGACY: secret-in-path routes (kept for old callers; disable via enginekick_legacy_path_auth).
	register_rest_route( 'enginekick/v1', '/(?P<secret>[^/]+)/crawl-log', array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_crawl ) );
	register_rest_route( 'enginekick/v1', '/(?P<secret>[^/]+)/changes',   array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_changes ) );
	register_rest_route( 'enginekick/v1', '/(?P<secret>[^/]+)/mcp-audit', array( 'methods' => 'GET', 'permission_callback' => 'enginekick_export_permission', 'callback' => $cb_audit ) );
} );

/* ---------------------------------------------------------------------------
 * Tiny settings page so the operator can read the secret + set the slug
 * ------------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( 'EngineKick', 'EngineKick', 'manage_options', 'enginekick', function () {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		if ( isset( $_POST['enginekick_slug_save'] ) && check_admin_referer( 'enginekick_save' ) ) {
			update_option( 'enginekick_client_slug', sanitize_title( wp_unslash( (string) $_POST['enginekick_client_slug'] ) ) );
		}
		if ( isset( $_POST['enginekick_crawl_save'] ) && check_admin_referer( 'enginekick_crawl' ) ) {
			update_option( 'enginekick_crawl_enabled', isset( $_POST['enginekick_crawl_enabled'] ) ? 1 : 0 );
			update_option( 'enginekick_crawl_bots_only', isset( $_POST['enginekick_crawl_bots_only'] ) ? 1 : 0 );
			update_option( 'enginekick_crawl_human_sample', max( 0, min( 100, (int) ( ( isset( $_POST['enginekick_crawl_human_sample'] ) ? $_POST['enginekick_crawl_human_sample'] : 1 ) ) ) ) );
			update_option( 'enginekick_crawl_cap_per_min', max( 0, (int) ( ( isset( $_POST['enginekick_crawl_cap_per_min'] ) ? $_POST['enginekick_crawl_cap_per_min'] : 300 ) ) ) );
			update_option( 'enginekick_crawl_retention_days', max( 7, (int) ( ( isset( $_POST['enginekick_crawl_retention_days'] ) ? $_POST['enginekick_crawl_retention_days'] : 120 ) ) ) );
			$pt_raw = sanitize_text_field( wp_unslash( ( isset( $_POST['enginekick_changes_post_types'] ) ? $_POST['enginekick_changes_post_types'] : '' ) ) );
			$pt_out = array();
			foreach ( preg_split( '/[\s,]+/', $pt_raw ) as $t ) {
				$t = sanitize_key( $t );
				if ( '' !== $t && ! in_array( $t, $pt_out, true ) ) { $pt_out[] = $t; }
			}
			update_option( 'enginekick_changes_post_types', implode( ',', $pt_out ? $pt_out : array( 'post', 'page' ) ) );
			update_option( 'enginekick_legacy_path_auth', isset( $_POST['enginekick_legacy_path_auth'] ) ? 1 : 0 );
			$ips = enginekick_sanitize_allowed_ips( wp_unslash( ( isset( $_POST['enginekick_allowed_ips'] ) ? $_POST['enginekick_allowed_ips'] : '' ) ) );
			if ( is_wp_error( $ips ) ) {   // all entries invalid — keep the previous restriction (V5-ext #10)
				$ek_ips_error = $ips->get_error_message();
			} else {
				update_option( 'enginekick_allowed_ips', $ips );
			}
		}
		$secret = enginekick_secret();
		$slug   = enginekick_slug();
		$hbase  = esc_url( home_url( '/wp-json/enginekick/v1' ) );   // header-auth base — no secret in the URL
		$legacy = (int) enginekick_legacy_path_auth_enabled();
		global $wpdb;
		// Row counts are informational, so they are cached for 10 minutes instead of scanning both
		// telemetry tables on every render (V6 #11: COUNT(*) cost grows with retained volume).
		$counts = get_transient( 'enginekick_table_counts' );
		if ( ! is_array( $counts ) ) {
			$missing = enginekick_schema_missing();
			$counts  = array(
				'crawl'   => in_array( 'table:enginekick_crawl', $missing, true ) ? 0 : (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . enginekick_crawl_table() ),
				'changes' => in_array( 'table:enginekick_changes', $missing, true ) ? 0 : (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . enginekick_changes_table() ),
			);
			set_transient( 'enginekick_table_counts', $counts, 10 * MINUTE_IN_SECONDS );
		}
		$crawl_rows = $counts['crawl'];
		$chg_rows   = $counts['changes'];
		echo '<div class="wrap"><h1>EngineKick OS Connector</h1>';
		if ( ! empty( $ek_ips_error ) ) {
			echo '<div class="notice notice-error"><p><strong>IP restriction not saved:</strong> ' . esc_html( $ek_ips_error ) . '</p></div>';
		}
		echo '<p><b>Client slug:</b></p><form method="post">';
		wp_nonce_field( 'enginekick_save' );
		echo '<input name="enginekick_client_slug" value="' . esc_attr( $slug ) . '" class="regular-text" /> ';
		echo '<input type="submit" name="enginekick_slug_save" class="button button-primary" value="Save" /></form>';
		echo '<h2 style="margin-top:20px">Pull URLs for Northstar</h2>';
		echo '<p><b>Recommended — header auth (no secret in the URL):</b></p>';
		echo '<p><code>' . $hbase . '/crawl-log?since=YYYY-MM-DD</code><br><code>' . $hbase . '/changes?since=YYYY-MM-DD</code><br><code>' . $hbase . '/mcp-audit?since=YYYY-MM-DD</code></p>';
		echo '<p>Send the secret in the request header (keeps it out of access/proxy/CDN logs):</p>';
		echo '<p><code>Authorization: Bearer ' . esc_html( $secret ) . '</code></p>';
		echo '<p class="description">Northstar sends this header automatically. Keep the secret private; rotate it by defining ENGINEKICK_SECRET in wp-config.php. Responses page in bounded chunks — follow <code>next_before_id</code>.</p>';
		if ( $legacy ) {
			echo '<p class="description" style="color:#8a6d00">⚠ Legacy secret-in-URL auth is ENABLED (<code>…/v1/&lt;secret&gt;/crawl-log</code> still works) for backward compatibility. It leaks the secret into logs — turn it OFF below once every puller uses the header.</p>';
		}

		// Crawl logging + access controls.
		$ce = (int) get_option( 'enginekick_crawl_enabled', 1 );
		$cb = (int) get_option( 'enginekick_crawl_bots_only', 1 );
		$cs = (int) get_option( 'enginekick_crawl_human_sample', 0 );
		$cc = (int) get_option( 'enginekick_crawl_cap_per_min', 300 );
		$cr = (int) get_option( 'enginekick_crawl_retention_days', 120 );
		$ai = esc_textarea( (string) get_option( 'enginekick_allowed_ips', '' ) );
		echo '<h2 style="margin-top:26px">Crawler logging &amp; access</h2>';
		echo '<p class="description">Crawl-log table: <b>' . number_format( $crawl_rows ) . '</b> rows &middot; changes table: <b>' . number_format( $chg_rows ) . '</b> rows (counted at most every 10 minutes).</p>';
		echo '<form method="post" style="max-width:640px;background:#fff;border:1px solid #ccd0d4;padding:14px 16px">';
		wp_nonce_field( 'enginekick_crawl' );
		echo '<p><label><input type="checkbox" name="enginekick_crawl_enabled" value="1" ' . checked( $ce, 1, false ) . '> Log bot crawl hits (uncheck to disable logging entirely — the pull endpoints keep working)</label></p>';
		echo '<p><label><input type="checkbox" name="enginekick_crawl_bots_only" value="1" ' . checked( $cb, 1, false ) . '> Bots only (never log human visitors)</label></p>';
		echo '<p><label>Human sampling %: <input type="number" name="enginekick_crawl_human_sample" value="' . $cs . '" min="0" max="100" style="width:70px"> (0 = log no humans)</label></p>';
		echo '<p><label>Per-minute write cap: <input type="number" name="enginekick_crawl_cap_per_min" value="' . $cc . '" min="0" style="width:90px"> (0 = uncapped; drops extra writes under a bot flood)</label></p>';
		echo '<p><label>Retention (days): <input type="number" name="enginekick_crawl_retention_days" value="' . $cr . '" min="7" style="width:90px"></label></p>';
		// R8 F13: say what the setting really does. Old rows are removed during normal site traffic, at most 500 at
		// a time; there is no scheduled sweep, so an idle site (or one with logging off) keeps rows longer.
		echo '<p class="description" style="max-width:640px;">Rows older than this are removed during normal site activity, up to 500 at a time. It is best effort, not a deadline: on a quiet site, or with logging switched off, old rows can stay longer. To clear a backlog now, lower the number and browse the site for a few minutes, or empty the <code>' . esc_html( enginekick_crawl_table() ) . '</code> table in your database tool.</p>';
		$cpt = esc_attr( implode( ', ', enginekick_tracked_post_types() ) );
		echo '<hr><p><label><b>Track content changes for these post types</b> (comma separated):</label><br>';
		echo '<input name="enginekick_changes_post_types" value="' . $cpt . '" class="regular-text" style="font-family:monospace"></p>';
		echo '<p class="description">Editorial types only by default. Adding a type that holds customer data &mdash; WooCommerce orders, form entries, membership or CRM records &mdash; sends its <b>titles and author names</b> to EngineKick in the changes export. Leave this as <code>post, page</code> unless you have a reason.</p>';
		echo '<p><label><b>Restrict all EngineKick endpoints to these IPs / CIDRs</b> (one per line/comma; blank = any IP):</label><br><textarea name="enginekick_allowed_ips" rows="3" style="width:100%;font-family:monospace">' . $ai . '</textarea></p>';
		echo '<hr><p><label><input type="checkbox" name="enginekick_legacy_path_auth" value="1" ' . checked( $legacy, 1, false ) . '> Allow legacy secret-in-URL auth (leave OFF unless a puller still needs it — the header form is preferred)</label></p>';
		echo '<p><input type="submit" name="enginekick_crawl_save" class="button button-primary" value="Save logging &amp; access"></p>';
		echo '</form></div>';
	} );
} );

} // end if ! defined( 'ENGINEKICK_CONNECTOR_LOADED' )
