<?php
/**
 * EngineKick OS — uninstall cleanup (review V4 #3, V5 F1, V5-ext #11).
 *
 * Runs ONLY when the plugin is DELETED from wp-admin (not on deactivate). Behaviour:
 *  - Does NOTHING if another active plugin identifies itself as EngineKick. Options, tables, the
 *    service account and its role are shared by every EngineKick copy, so deleting one copy must not
 *    pull that state out from under a copy that is still running (V5-ext #11).
 *  - Removes every enginekick_* option, INCLUDING the MCP token and mode — so a later reinstall starts
 *    fail-closed (mode off, a fresh token) and can never silently restore a previous publish endpoint
 *    or reuse the old credential URL.
 *  - Deletes the service user ONLY if this plugin created it (enginekick_service_owned, set at creation
 *    and nowhere else), and ONLY after REASSIGNING its posts to an administrator. An account that was merely
 *    adopted keeps its posts and gets back exactly the roles it had before adoption. wp_delete_user() with
 *    no reassign target hard-deletes every post the user authored, bypassing trash (V5 F1).
 *  - Removes the EngineKick Service role and drops the custom tables (audit, changes, crawl, rate). The
 *    tables are operational telemetry, not compliance evidence — export them first if you need them.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// 0) Shared-consumer check (V5-ext #11). Every EngineKick build names itself "EngineKick ..." in its
//    plugin header; match on that prefix so older or standalone builds count too.
$ek_active = (array) get_option( 'active_plugins', array() );
if ( is_multisite() ) {
	$ek_active = array_merge( $ek_active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
}
foreach ( array_unique( $ek_active ) as $ek_plugin ) {
	if ( (string) WP_UNINSTALL_PLUGIN === (string) $ek_plugin ) {
		continue;
	}
	$ek_file = WP_PLUGIN_DIR . '/' . $ek_plugin;
	if ( ! is_readable( $ek_file ) ) {
		continue;
	}
	$ek_head = get_file_data( $ek_file, array( 'name' => 'Plugin Name' ) );
	if ( 0 === stripos( trim( (string) $ek_head['name'] ), 'EngineKick' ) ) {
		return;   // another active EngineKick copy still depends on the shared state — leave it all in place
	}
}

// 1) Options + secrets — delete all enginekick_* options (covers token, mode, allowlist, crawl config,
//    retention, db version, service flag, export secret).
$like  = $wpdb->esc_like( 'enginekick_' ) . '%';
$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );
foreach ( (array) $names as $o ) {
	delete_option( $o );
}

// 2) Service user. Its posts are REASSIGNED to an administrator, never deleted.
$svc = get_user_by( 'login', 'enginekick-service' );
if ( $svc && ! user_can( $svc, 'manage_options' ) && ! user_can( $svc, 'edit_users' ) ) {
	$owned = ( '1' === get_user_meta( $svc->ID, 'enginekick_service_owned', true ) );
	if ( $owned ) {
		$admins   = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID', 'orderby' => 'ID', 'order' => 'ASC' ) );
		$reassign = ! empty( $admins ) ? (int) $admins[0] : 0;
		if ( $reassign && $reassign !== (int) $svc->ID ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $svc->ID, $reassign );
			$svc = null;
		}
		// No administrator to inherit the content: keep the account. An orphaned account with an
		// unusable password is a far smaller problem than silently destroying every post it wrote.
	}
	if ( $svc ) {
		// Kept account (adopted, or owned with nobody to inherit its posts). Remove our markers so a
		// reinstall does not treat it as ours. An adopted account gets back the roles recorded at
		// adoption time; an account we created never had any, so it is left with none (it cannot act).
		if ( in_array( 'enginekick_service', (array) $svc->roles, true ) ) {
			// Put back exactly the roles the account had before adoption (V7 #8). Assigning stock Editor
			// could ADD privileges it never held — including unfiltered_html on single-site — and drop a
			// custom or narrowed role. With nothing recorded, the plugin's own role is simply removed.
			$prior = array_filter( array_map( 'trim', explode( ',', (string) get_user_meta( $svc->ID, 'enginekick_prior_roles', true ) ) ) );
			$svc->remove_role( 'enginekick_service' );
			foreach ( $prior as $role_name ) {
				if ( get_role( $role_name ) ) {
					$svc->add_role( $role_name );
				}
			}
		}
		delete_user_meta( $svc->ID, 'enginekick_service' );
		delete_user_meta( $svc->ID, 'enginekick_service_owned' );
		delete_user_meta( $svc->ID, 'enginekick_prior_roles' );
	}
}

// 2b) Remembered old addresses (post meta written when the connector changes a URL). Without the plugin
//     nothing reads them; WordPress's own _wp_old_slug keeps redirecting renamed POSTS regardless.
delete_metadata( 'post', 0, '_enginekick_old_path', '', true );

// 3) The dedicated service role. Ours by name, never a stock WordPress role, and no longer assigned.
remove_role( 'enginekick_service' );

// 4) Custom tables — drop them (identifiers are internal, prefixed; safe to interpolate).
foreach ( array( 'enginekick_mcp_audit', 'enginekick_changes', 'enginekick_crawl', 'enginekick_rate' ) as $t ) {
	$tbl = $wpdb->prefix . $t;
	$wpdb->query( "DROP TABLE IF EXISTS `$tbl`" );
}
